-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: 192.168.68.121    Database: bcp
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `daily_status`
--

DROP TABLE IF EXISTS `daily_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `project_id` int NOT NULL,
  `team_size` int NOT NULL,
  `updates` varchar(4000) NOT NULL,
  `challenges` varchar(4000) NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_time` datetime NOT NULL,
  `updated_by` varchar(200) NOT NULL,
  `updated_time` datetime NOT NULL,
  `status` varchar(45) NOT NULL,
  `location_id` int DEFAULT NULL,
  `deliverable_of_day` varchar(255) DEFAULT NULL,
  `hiring_update` varchar(255) DEFAULT NULL,
  `milestone` varchar(255) DEFAULT NULL,
  `mitigation_plan` varchar(255) DEFAULT NULL,
  `wfh_challenge` varchar(255) DEFAULT NULL,
  `wfh_mitigation_plan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_daily_date_proj_loc` (`date`,`project_id`),
  KEY `fk_daily_project_idx` (`project_id`),
  CONSTRAINT `fk_daily_project` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_status`
--

LOCK TABLES `daily_status` WRITE;
/*!40000 ALTER TABLE `daily_status` DISABLE KEYS */;
INSERT INTO `daily_status` VALUES (31,'2020-04-17',40,0,'test','Test','Test','2020-04-17 20:42:13','TEST','2020-04-17 20:42:13','red',1,'Test','Test','Test',NULL,'Test','Test'),(32,'2020-04-16',91,0,'test','TEST','Test','2020-04-18 12:14:07','TEST','2020-04-18 12:14:07','amber',2,'TEST','In Progress','TEST',NULL,'TEST','TEST'),(33,'2020-04-16',92,0,'test','TEST','Test','2020-04-18 12:15:10','TEST','2020-04-18 12:15:10','green',2,'TEST','TEST','TEST',NULL,'TEST','TEST');
/*!40000 ALTER TABLE `daily_status` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-18 20:31:01
