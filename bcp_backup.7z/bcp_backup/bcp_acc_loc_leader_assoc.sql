-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: 192.168.68.121    Database: bcp
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acc_loc_leader_assoc`
--

DROP TABLE IF EXISTS `acc_loc_leader_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acc_loc_leader_assoc` (
  `id` int NOT NULL,
  `account_id` int DEFAULT NULL,
  `leader_id` int DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9qy8cxfytno6qn94ojy6jx6b7` (`leader_id`),
  KEY `FKf9hjk6adxqhalamchkw6ut9yf` (`location_id`),
  KEY `FKdqwxq1cotudgt7clkmnxke555` (`project_id`),
  KEY `FK6nmo5phxir1m3fydimouoy0rv` (`account_id`),
  CONSTRAINT `FK6nmo5phxir1m3fydimouoy0rv` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK9qy8cxfytno6qn94ojy6jx6b7` FOREIGN KEY (`leader_id`) REFERENCES `leader` (`id`),
  CONSTRAINT `FKdqwxq1cotudgt7clkmnxke555` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`),
  CONSTRAINT `FKf9hjk6adxqhalamchkw6ut9yf` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acc_loc_leader_assoc`
--

LOCK TABLES `acc_loc_leader_assoc` WRITE;
/*!40000 ALTER TABLE `acc_loc_leader_assoc` DISABLE KEYS */;
INSERT INTO `acc_loc_leader_assoc` VALUES (1,1,1,3,NULL),(2,1,9,1,NULL),(3,2,11,1,NULL),(4,2,11,2,NULL),(5,3,12,4,NULL),(6,4,10,2,NULL),(7,5,11,1,NULL),(8,6,18,2,NULL),(9,7,22,1,NULL),(10,8,18,2,NULL),(11,9,29,2,NULL),(12,10,5,2,NULL),(13,12,4,3,NULL),(14,12,14,4,NULL),(15,12,19,1,NULL),(16,13,12,1,NULL),(17,14,29,2,NULL),(18,15,7,2,NULL),(19,16,29,2,NULL),(20,17,29,2,NULL),(21,18,17,2,NULL),(22,19,18,2,NULL),(23,20,11,1,NULL),(24,21,6,1,NULL),(25,21,29,2,NULL),(26,22,3,1,NULL),(27,22,27,1,NULL),(28,23,12,1,NULL),(29,24,12,1,NULL);
/*!40000 ALTER TABLE `acc_loc_leader_assoc` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-18 20:30:59
