package com.altimetrik.bcp.model;

public enum AttendanceType {
	ACCOUNT,LOCATION
}
