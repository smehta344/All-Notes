var urlForServer='../';//local server
var userInfoMap = new Map();

