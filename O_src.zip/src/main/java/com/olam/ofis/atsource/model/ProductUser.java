/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.olam.ofis.atsource.util.AtSourceConstants;

@Entity

@Table(schema= AtSourceConstants.MASTER_SCHEMA,name="product_user",catalog=AtSourceConstants.MASTER_SCHEMA)
public class ProductUser implements Serializable {
	
	public ProductUser() {
		// default constructor
	}
	
	private static final long serialVersionUID = 617174943837845059L;
	
	@Column(name="id")
	private Long productUserId;
	
	@Id
	@Column(name="product_id")
	private Long productId;
	
	@Column(name="user_id")
	private Long userId;
	
	@Column(name="created_at")
	private Date createdAt;
	
	@Column(name="updated_at")
	private Date updatedAt;
	
	@OneToMany
	@JoinColumn(name="id")
	private List<Product> products;

	public Long getProductUserId() {
		return productUserId;
	}

	public void setProductUserId(Long productUserId) {
		this.productUserId = productUserId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	

}
