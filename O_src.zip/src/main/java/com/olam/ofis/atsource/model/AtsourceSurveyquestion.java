/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the atsource_surveyquestion database table.
 * 
 */
@Entity
@Table(name = "atsource_surveyquestion")
public class AtsourceSurveyquestion implements Serializable {
	
	public AtsourceSurveyquestion() {
		// default constructor
	}
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	private Byte active;

	@Column(name = "app_id")
	private Integer appId;

	@Column(name = "km_code")
	private String kmCode;

	@Column(name = "created_at")
	private Date createdAt;

	@Column(name = "created_by")
	private BigInteger createdBy;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "datatype_id")
	private DataType datatypeId;

	@Lob
	@Column(name = "display_configuration")
	private String displayConfiguration;

	@Column(name = "display_type")
	private String displayType;

	@Column(name = "position")
	private Integer position;

	@Lob
	private String question;

	@Lob
	@Column(name = "question_es")
	private String questionEs;

	@Lob
	@Column(name = "question_fr")
	private String questionFr;

	@Lob
	@Column(name = "question_id")
	private String questionId;

	@Lob
	@Column(name = "question_lo")
	private String questionLo;

	@Lob
	@Column(name = "question_pt")
	private String questionPt;

	@Lob
	@Column(name = "question_th")
	private String questionTh;

	@Lob
	@Column(name = "question_tr")
	private String questionTr;

	@Lob
	@Column(name = "question_vi")
	private String questionVi;
	
	@Column(name = "min_value")
	private Long minValue;
	
	@Column(name = "max_value")
	private Long maxValue;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "submodule_id")
	private SubModule submoduleId;

	@Column(name = "updated_at")
	private Date updatedAt;

	@Column(name = "updated_by")
	private BigInteger updatedBy;

	// bi-directional many-to-one association to AtsourceSurveyanswer
	@OneToMany(mappedBy = "atsourceSurveyquestion")
	private List<AtSourceSurveyAnswer> atsourceSurveyanswers;

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Byte getActive() {
		return this.active;
	}

	public void setActive(Byte active) {
		this.active = active;
	}

	public Integer getAppId() {
		return this.appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public String getKmCode() {
		return this.kmCode;
	}

	public void setKmCode(String kmCode) {
		this.kmCode = kmCode;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public BigInteger getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(BigInteger createdBy) {
		this.createdBy = createdBy;
	}

	public DataType getDatatypeId() {
		return this.datatypeId;
	}

	public void setDatatypeId(DataType datatypeId) {
		this.datatypeId = datatypeId;
	}

	public String getDisplayConfiguration() {
		return this.displayConfiguration;
	}

	public void setDisplayConfiguration(String displayConfiguration) {
		this.displayConfiguration = displayConfiguration;
	}

	public String getDisplayType() {
		return this.displayType;
	}

	public void setDisplayType(String displayType) {
		this.displayType = displayType;
	}

	public Integer getPosition() {
		return this.position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	public String getQuestion() {
		return this.question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getQuestionEs() {
		return this.questionEs;
	}

	public void setQuestionEs(String questionEs) {
		this.questionEs = questionEs;
	}

	public String getQuestionFr() {
		return this.questionFr;
	}

	public void setQuestionFr(String questionFr) {
		this.questionFr = questionFr;
	}

	public String getQuestionId() {
		return this.questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getQuestionLo() {
		return this.questionLo;
	}

	public void setQuestionLo(String questionLo) {
		this.questionLo = questionLo;
	}

	public String getQuestionPt() {
		return this.questionPt;
	}

	public void setQuestionPt(String questionPt) {
		this.questionPt = questionPt;
	}

	public String getQuestionTh() {
		return this.questionTh;
	}

	public void setQuestionTh(String questionTh) {
		this.questionTh = questionTh;
	}

	public String getQuestionTr() {
		return this.questionTr;
	}

	public void setQuestionTr(String questionTr) {
		this.questionTr = questionTr;
	}

	public String getQuestionVi() {
		return this.questionVi;
	}

	public void setQuestionVi(String questionVi) {
		this.questionVi = questionVi;
	}

	public SubModule getSubmoduleId() {
		return this.submoduleId;
	}

	public void setSubmoduleId(SubModule submoduleId) {
		this.submoduleId = submoduleId;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public BigInteger getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(BigInteger updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Long getMinValue() {
		return minValue;
	}

	public void setMinValue(Long minValue) {
		this.minValue = minValue;
	}

	public Long getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(Long maxValue) {
		this.maxValue = maxValue;
	}

	public List<AtSourceSurveyAnswer> getAtsourceSurveyanswers() {
		return this.atsourceSurveyanswers;
	}

	public void setAtsourceSurveyanswers(List<AtSourceSurveyAnswer> atsourceSurveyanswers) {
		this.atsourceSurveyanswers = atsourceSurveyanswers;
	}

	public AtSourceSurveyAnswer addAtsourceSurveyanswer(AtSourceSurveyAnswer atsourceSurveyanswer) {
		getAtsourceSurveyanswers().add(atsourceSurveyanswer);
		atsourceSurveyanswer.setAtsourceSurveyquestion(this);

		return atsourceSurveyanswer;
	}

	public AtSourceSurveyAnswer removeAtsourceSurveyanswer(AtSourceSurveyAnswer atsourceSurveyanswer) {
		getAtsourceSurveyanswers().remove(atsourceSurveyanswer);
		atsourceSurveyanswer.setAtsourceSurveyquestion(null);

		return atsourceSurveyanswer;
	}

}
