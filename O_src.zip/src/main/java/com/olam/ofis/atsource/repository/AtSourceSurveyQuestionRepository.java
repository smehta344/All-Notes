/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.olam.ofis.atsource.model.AtsourceSurveyquestion;

public interface AtSourceSurveyQuestionRepository extends JpaRepository<AtsourceSurveyquestion, Integer> {

	@Query("SELECT q FROM AtsourceSurveyquestion q")
	Page<AtsourceSurveyquestion> findAllActiveQuestions(Pageable pageable);

	@Query("select q from AtsourceSurveyquestion q where q.id = :questionId")
	AtsourceSurveyquestion getQuestionById(@Param("questionId") Integer questionId);

	@Query("SELECT q FROM AtsourceSurveyquestion q WHERE q.active = 1")
	List<AtsourceSurveyquestion> findByActive();

	@Query(value = "select * from ofisatsource.atsource_surveyquestion where "
			+ "replace(display_configuration, ' ', '') like :key", nativeQuery = true)
	List<AtsourceSurveyquestion> findSubQuestionsByParentId(@Param("key") String key);

	@Query("select q from AtsourceModuleAssignment as ma join SubModule sm on ma.moduleId = sm.moduleId.id "
			+ "join AtsourceSurveyquestion q on q.submoduleId=sm.id and q.active = 1 and sm.active=true "
			+ "group by q.id order by sm.id, q.position")
	List<AtsourceSurveyquestion> findAtsourceQuestionsBySubmodule();

	@Query("SELECT a as atsourceQuestionResult, s as subModuleResult, d as dataTypeResult "
			+ " FROM AtsourceSurveyquestion as a " +
			" join SubModule s on a.submoduleId.id = s.id " +
			" join DataType d on a.datatypeId.id = d.id ")
	Page<AtsourceSurveyquestionQueryResult> findAllQuestionsResult(Pageable pageable);

	@Query("select q from AtsourceModuleAssignment as ma join SubModule sm on ma.moduleId = sm.moduleId.id "
			+ "join AtsourceSurveyquestion q on q.submoduleId=sm.id group by q.id order by sm.id, q.position")
	List<AtsourceSurveyquestion> findAtsourceQuestionsBySubmoduleId();

	AtsourceSurveyquestion findByKmCode(String code);
	
	@Query("Select kmCode from AtsourceSurveyquestion where kmCode in (:ids)") 
	  public List<String> getKmIds(@Param("ids")List<String> ids);
}
