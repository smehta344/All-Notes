/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.olam.ofis.atsource.util.AtSourceConstants;

@Entity
@Table(schema = AtSourceConstants.MASTER_SCHEMA, name = "country", catalog = AtSourceConstants.MASTER_SCHEMA)
public class Country implements Serializable {

	public Country() {
		// default constructor
	}
	
	private static final long serialVersionUID = -4513154542125L;

	@Id
	@Column(name = "country_id")
	private Long countryId;

	@Column(name = "country_code")
	private String countryCode;

	@Column(name = "country_name")
	private String countryName;

	@Column(name = "dialling_code")
	private String diallingCode;

	@Column(name = "olam_country")
	private String olamCountry;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "active")
	private Boolean active;

	@Column(name = "centre_lat")
	private String centreLat;

	@Column(name = "centre_lng")
	private String centreLng;

	@Column(name = "sms_originator_id")
	private String smsOriginatorId;

	@Column(name = "created_at")
	private Date createdTs;

	@Column(name = "updated_at")
	private Date updatedTs;

	@Column(name = "app_id")
	private Integer appId;

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getDiallingCode() {
		return diallingCode;
	}

	public void setDiallingCode(String diallingCode) {
		this.diallingCode = diallingCode;
	}

	public String getOlamCountry() {
		return olamCountry;
	}

	public void setOlamCountry(String olamCountry) {
		this.olamCountry = olamCountry;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getCentreLat() {
		return centreLat;
	}

	public void setCentreLat(String centreLat) {
		this.centreLat = centreLat;
	}

	public String getCentreLng() {
		return centreLng;
	}

	public void setCentreLng(String centreLng) {
		this.centreLng = centreLng;
	}

	public String getSmsOriginatorId() {
		return smsOriginatorId;
	}

	public void setSmsOriginatorId(String smsOriginatorId) {
		this.smsOriginatorId = smsOriginatorId;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public Date getUpdatedTs() {
		return updatedTs;
	}

	public void setUpdatedTs(Date updatedTs) {
		this.updatedTs = updatedTs;
	}

}
