/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import org.hibernate.annotations.NamedNativeQuery;
import org.hibernate.annotations.Type;

import com.olam.ofis.atsource.util.AtSourceConstants;

@Entity
@Table(name = "atsource_moduleassignments", 
	schema = AtSourceConstants.ATSOURCE_SCHEMA, catalog = AtSourceConstants.ATSOURCE_SCHEMA)

@SqlResultSetMapping(name = "atsourceModuleAssignmentUniqueData", classes = 
		@ConstructorResult(targetClass = AtsourceModuleAssignmentData.class, columns = {
		@ColumnResult(name = "moduleId"), @ColumnResult(name = "moduleassignmentId"), 
		@ColumnResult(name = "moduleAssignmentType"),
		@ColumnResult(name = "recurrenceFrequency"),
		@ColumnResult(name = "recurrenceType"), @ColumnResult(name = "disabledMonths"),
		@ColumnResult(name = "appId"), @ColumnResult(name = "active") }))

@NamedNativeQuery(name = "atsourceModuleAssignmentUniqueData", query = "SELECT DISTINCT module_id as moduleId,"
	+ " group_concat(moduleassignment_id) as moduleassignmentId, moduleassignment_type as moduleAssignmentType, "
	+ "recurrence_frequency as recurrenceFrequency, recurrence_type as recurrenceType, disabled_months as disabledMonths,"
	+ " app_id as appId, active as active FROM ofisatsource.atsource_moduleassignments ", resultClass = 
	AtsourceModuleAssignmentData.class, resultSetMapping = "atsourceModuleAssignmentUniqueData")
public class AtsourceModuleAssignment implements Serializable {

	public AtsourceModuleAssignment() {
		//default constructor
	}
	
	private static final long serialVersionUID = -4542121081283L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "module_id")
	private Module moduleId;

	@Column(name = "moduleassignment_id")
	private Integer moduleAssignmentId;

	@Column(name = "moduleassignment_type")
	private String moduleAssignmentType;

	@Column(name = "recurrence_frequency")
	private Integer recurrenceFrequency;

	@Column(name = "recurrence_type")
	private String recurrenceType;

	@Column(name = "disabled_months")
	private String disabledMonths;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "active")
	private Boolean active;

	@Column(name = "created_at")
	private Date createdAt;

	@Column(name = "updated_at")
	private Date updatedAt;

	@Column(name = "app_id")
	private Integer appId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Module getModuleId() {
		return moduleId;
	}

	public void setModuleId(Module moduleId) {
		this.moduleId = moduleId;
	}

	public Integer getModuleAssignmentId() {
		return moduleAssignmentId;
	}

	public void setModuleAssignmentId(Integer moduleAssignmentId) {
		this.moduleAssignmentId = moduleAssignmentId;
	}

	public String getModuleAssignmentType() {
		return moduleAssignmentType;
	}

	public void setModuleAssignmentType(String moduleAssignmentType) {
		this.moduleAssignmentType = moduleAssignmentType;
	}

	public Integer getRecurrenceFrequency() {
		return recurrenceFrequency;
	}

	public void setRecurrenceFrequency(Integer recurrenceFrequency) {
		this.recurrenceFrequency = recurrenceFrequency;
	}

	public String getRecurrenceType() {
		return recurrenceType;
	}

	public void setRecurrenceType(String recurrenceType) {
		this.recurrenceType = recurrenceType;
	}

	public String getDisabledMonths() {
		return disabledMonths;
	}

	public void setDisabledMonths(String disabledMonths) {
		this.disabledMonths = disabledMonths;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}
}
