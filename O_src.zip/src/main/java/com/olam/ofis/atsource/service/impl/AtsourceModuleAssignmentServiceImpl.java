/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.olam.ofis.atsource.dto.AtsourceModuleAssignmentDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.SubModuleDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.exception.ErrorCode;
import com.olam.ofis.atsource.model.AtsourceModuleAssignment;
import com.olam.ofis.atsource.model.AtsourceModuleAssignmentData;
import com.olam.ofis.atsource.model.Country;
import com.olam.ofis.atsource.model.District;
import com.olam.ofis.atsource.model.FarmerGroup;
import com.olam.ofis.atsource.model.Module;
import com.olam.ofis.atsource.model.Partner;
import com.olam.ofis.atsource.model.Place;
import com.olam.ofis.atsource.model.Product;
import com.olam.ofis.atsource.model.Programme;
import com.olam.ofis.atsource.model.Region;
import com.olam.ofis.atsource.model.Section;
import com.olam.ofis.atsource.model.SubModule;
import com.olam.ofis.atsource.repository.AtsourceModuleAssignmentRepository;
import com.olam.ofis.atsource.repository.CountryRepository;
import com.olam.ofis.atsource.repository.DistrictRepository;
import com.olam.ofis.atsource.repository.FarmerGroupRepository;
import com.olam.ofis.atsource.repository.ModuleRepository;
import com.olam.ofis.atsource.repository.PartnerRepository;
import com.olam.ofis.atsource.repository.PlaceRepository;
import com.olam.ofis.atsource.repository.ProductRepository;
import com.olam.ofis.atsource.repository.ProgrammeRepository;
import com.olam.ofis.atsource.repository.RegionRepository;
import com.olam.ofis.atsource.repository.SectionRepository;
import com.olam.ofis.atsource.repository.SubModuleRepository;
import com.olam.ofis.atsource.service.AtsourceModuleAssignmentService;
import com.olam.ofis.atsource.util.AtSourceConstants;
import com.olam.ofis.atsource.util.CommonUtil;

@Service
public class AtsourceModuleAssignmentServiceImpl implements AtsourceModuleAssignmentService {

	private static final Logger logger = LoggerFactory.getLogger(AtsourceModuleAssignmentServiceImpl.class);
	
	@Autowired
	private AtsourceModuleAssignmentRepository atsourceModuleAssignmentRepository;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private PartnerRepository partnerRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ProgrammeRepository programmeRepository;

	@Autowired
	private SectionRepository sectionRepository;

	@Autowired
	private FarmerGroupRepository farmerGroupRepository;

	@Autowired
	private RegionRepository regionRepository;

	@Autowired
	private DistrictRepository districtRepository;

	@Autowired
	private PlaceRepository placeRepository;

	@Autowired
	private ModuleRepository moduleRepository;

	@Autowired
	private SubModuleRepository subModuleRepository;

	/**
	 * {@inheritDoc}
	 * @throws CustomValidationException 
	 */
	@Override
	@Transactional
	public MessageDto saveModuleAssignment(AtsourceModuleAssignmentDto atsourceModuleAssignmentDto) 
			throws CustomValidationException{
		if(atsourceModuleAssignmentDto.getAtsource() != null && !atsourceModuleAssignmentDto.getAtsource()) {
			atsourceModuleAssignmentRepository.deleteAll();
			MessageDto messageDto = new MessageDto();
			messageDto.setMessage(AtSourceConstants.ATSOURCE_ASSIGNMENTS_DELETED);
			return messageDto;
		} else {
			validateSaveModuleAssignmentDto(atsourceModuleAssignmentDto);
			String[] assignmentIds = atsourceModuleAssignmentDto.getModuleAssignmentId().split(",");
			checkForInvalidAssignmentIds(atsourceModuleAssignmentDto, assignmentIds);
			try {
				List<AtsourceModuleAssignment> atsourceModuleAssignments = atsourceModuleAssignmentRepository.findAll();
				if (!atsourceModuleAssignments.isEmpty()) {
					atsourceModuleAssignmentRepository.deleteAll();
				}
				Arrays.stream(assignmentIds).forEach(assignmentId -> {
					AtsourceModuleAssignment atsourceModuleAssignment = atsourceModuleAssignmentDto
							.convertDtoToModel(atsourceModuleAssignmentDto);
					atsourceModuleAssignment.setModuleAssignmentId(Integer.valueOf(assignmentId));
					if (atsourceModuleAssignment.getActive() == null) {
						atsourceModuleAssignment.setActive(false);
					}
					if (atsourceModuleAssignment.getCreatedAt() == null) {
						atsourceModuleAssignment.setCreatedAt(new Date());
					}
					atsourceModuleAssignment.setUpdatedAt(new Date());
					atsourceModuleAssignmentRepository.save(atsourceModuleAssignment);
				});
				MessageDto messageDto = new MessageDto();
				messageDto.setMessage("Success");
				return messageDto;
			} catch (Exception e) {
				logger.error("saveModuleAssignment: ", e);
				throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2008);
			}
		}
	}

	/**
	 * Validating input for saving module assignment
	 *
	 * @param atsourceModuleAssignmentDto
	 * @throws CustomValidationException
	 */
	private void validateSaveModuleAssignmentDto(AtsourceModuleAssignmentDto atsourceModuleAssignmentDto)
			throws CustomValidationException {
		if (atsourceModuleAssignmentDto.getModuleId() == null) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2010);
		}
		Module module = moduleRepository.findById(atsourceModuleAssignmentDto.getModuleId()).orElse(null);
		if (module == null) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2011);
		}
		if (!module.getActive()) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2012);
		}
	}

	/**
	 * To check if there are any invalid assignment ids for the respective
	 * assignment type
	 *
	 * @param atsourceModuleAssignmentDto
	 * @param assignmentIds
	 * @throws Exception
	 */
	private void checkForInvalidAssignmentIds(AtsourceModuleAssignmentDto atsourceModuleAssignmentDto,
			String[] assignmentIds) throws CustomValidationException {
		List<String> invalidAssignmentIds = new ArrayList<>();
		List<String> inactiveAssignmentIds = new ArrayList<>();
		String category = atsourceModuleAssignmentDto.getModuleAssignmentType();
		
		checkCategoryInvalidAssignments(invalidAssignmentIds,inactiveAssignmentIds, category, assignmentIds);
		
		if (!invalidAssignmentIds.isEmpty()) {
			throw new CustomValidationException("One or more Module Assignment Ids not valid: " + invalidAssignmentIds);
		} else if (!inactiveAssignmentIds.isEmpty()) {
			throw new CustomValidationException("One or more Module Assignment Ids not active: " + inactiveAssignmentIds);
		}
	}

	private void checkCategoryInvalidAssignments(List<String> invalidAssignmentIds, List<String> inactiveAssignmentIds,
					String category, String[] assignmentIds) throws CustomValidationException {
		category = category.trim();
		switch (category) {
		case AtSourceConstants.COUNTRY:
			for (String assignmentId : assignmentIds) {
				Country country = countryRepository.findById(Long.valueOf(assignmentId)).orElse(null);
				if (country == null) {
					invalidAssignmentIds.add(assignmentId);
				} else if (!country.getActive()) {
					inactiveAssignmentIds.add(assignmentId);
				}
			}
			break;
		case AtSourceConstants.PARTNER:
			for (String assignmentId : assignmentIds) {
				Partner partner = partnerRepository.findById(Long.valueOf(assignmentId)).orElse(null);
				if (partner == null) {
					invalidAssignmentIds.add(assignmentId);
				} else if (!partner.getActive()) {
					inactiveAssignmentIds.add(assignmentId);
				}
			}
			break;
		case AtSourceConstants.PRODUCT:
			for (String assignmentId : assignmentIds) {
				Product product = productRepository.findById(Long.valueOf(assignmentId)).orElse(null);
				if (product == null) {
					invalidAssignmentIds.add(assignmentId);
				} else if (!product.getActive()) {
					inactiveAssignmentIds.add(assignmentId);
				}
			}
			break;
		case AtSourceConstants.PROGRAMME:
			for (String assignmentId : assignmentIds) {
				Programme programme = programmeRepository.findById(Long.valueOf(assignmentId)).orElse(null);
				if (programme == null) {
					invalidAssignmentIds.add(assignmentId);
				} else if (!programme.getActive()) {
					inactiveAssignmentIds.add(assignmentId);
				}
			}
			break;
		case AtSourceConstants.SECTION:
			for (String assignmentId : assignmentIds) {
				Section section = sectionRepository.findById(Long.valueOf(assignmentId)).orElse(null);
				if (section == null) {
					invalidAssignmentIds.add(assignmentId);
				} else if (!section.getActive()) {
					inactiveAssignmentIds.add(assignmentId);
				}
			}
			break;
		case AtSourceConstants.FARMERGROUP:
			for (String assignmentId : assignmentIds) {
				FarmerGroup farmerGroup = farmerGroupRepository.findById(Long.valueOf(assignmentId))
						.orElse(null);
				if (farmerGroup == null) {
					invalidAssignmentIds.add(assignmentId);
				} else if (!farmerGroup.getActive()) {
					inactiveAssignmentIds.add(assignmentId);
				}
			}
			break;
		case AtSourceConstants.REGION:
			for (String assignmentId : assignmentIds) {
				Region region = regionRepository.findById(Long.valueOf(assignmentId)).orElse(null);
				if (region == null) {
					invalidAssignmentIds.add(assignmentId);
				} else if (!region.getIsActive()) {
					inactiveAssignmentIds.add(assignmentId);
				}
			}
			break;
		case AtSourceConstants.DISTRICT:
			for (String assignmentId : assignmentIds) {
				District district = districtRepository.findById(Long.valueOf(assignmentId)).orElse(null);
				if (district == null) {
					invalidAssignmentIds.add(assignmentId);
				} else if (!district.getIsActive()) {
					inactiveAssignmentIds.add(assignmentId);
				}
			}
			break;
		case AtSourceConstants.PLACE:
			for (String assignmentId : assignmentIds) {
				Place place = placeRepository.findById(Long.valueOf(assignmentId)).orElse(null);
				if (place == null) {
					invalidAssignmentIds.add(assignmentId);
				} else if (!place.getActive()) {
					inactiveAssignmentIds.add(assignmentId);
				}
			}
			break;
		default:
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2017);
		}
	}
	
	@Override
	public AtsourceModuleAssignmentDto getModuleAssignment(Integer moduleId) throws CustomValidationException {
		AtsourceModuleAssignmentDto assignmentDto = null;
		List<AtsourceModuleAssignmentData> uniqueAssignmentDatas = atsourceModuleAssignmentRepository
				.findAllUniqueData();
		if (CommonUtil.isNotNull(uniqueAssignmentDatas, moduleId)) {

			Optional<AtsourceModuleAssignmentData> uniqueAssignmentData = uniqueAssignmentDatas.stream()
					.filter(obj -> moduleId.equals(obj.getModuleId())).findFirst();

			if (uniqueAssignmentData.isPresent()) {
				assignmentDto = modelMapper.map(uniqueAssignmentData.get(), AtsourceModuleAssignmentDto.class);
				assignmentDto.setAtsource(true);
			}
		} else {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2009);
		}
		return assignmentDto;
	}

	public AtsourceModuleAssignment getAtSourceModule() {
		return atsourceModuleAssignmentRepository.findAll().get(0);
	}

	@Override
	public List<SubModuleDto> getAllSubmodulesByModuleId(Integer moduleId) throws CustomValidationException {
		List<SubModule> subModuleList = subModuleRepository.getAllSubmodulesByModuleId(moduleId);
		if(null != subModuleList && !subModuleList.isEmpty()) {
			return modelMapper.map(subModuleRepository.getAllSubmodulesByModuleId(moduleId),
					new TypeToken<List<SubModuleDto>>() {}.getType());
		} else {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2011);
		}
	}

	@Override
	public List<AtsourceModuleAssignmentDto> getAllModuleAssignment() throws CustomValidationException {
		List<AtsourceModuleAssignmentDto> modules = new ArrayList<>();
		AtsourceModuleAssignmentDto assignmentDto = null;
		List<AtsourceModuleAssignmentData> uniqueAssignmentDatas = atsourceModuleAssignmentRepository
				.findAllUniqueData();
		if (CommonUtil.isNotNull(uniqueAssignmentDatas)) {
			for (AtsourceModuleAssignmentData assignmentData : uniqueAssignmentDatas) {
				assignmentDto = modelMapper.map(assignmentData, AtsourceModuleAssignmentDto.class);
				assignmentDto.setAtsource(true);
				modules.add(assignmentDto);
			}
		} else {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2009);
		}
		return modules;
	}

}
