/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.service;

import java.util.List;

import com.olam.ofis.atsource.dto.AtsourceSurveyReviewDto;
import com.olam.ofis.atsource.dto.FarmerGroupProjectionDto;
import com.olam.ofis.atsource.dto.FarmerModuleProjectionDto;
import com.olam.ofis.atsource.dto.KmFarmerGroupIdDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.util.PaginationResult;

public interface AtSourceSurveyReviewService {

	/**
	 * <p>
	 * Used to save the survey review response from Atsource
	 * </p>
	 *
	 * @param surveyReviewDto - List of {@link AtsourceSurveyReviewDto}
	 * @param userId          - User Id
	 * @return MessageDto
	 * @throws CustomValidationException
	 */
	MessageDto saveAtsourceSurveyReviewResponses(AtsourceSurveyReviewDto surveyReviewDto, Long userId)
			throws CustomValidationException;

	/**
	 * <p>
	 * Used to update the survey review response from Atsource
	 * </p>
	 *
	 * @param surveyReviewDto - List of {@link AtsourceSurveyReviewDto}
	 * @param userId          - User Id
	 * @return MessageDto
	 * @throws CustomValidationException
	 */
	MessageDto updateAtsourceSurveyReviewResponses(Long reviewId, AtsourceSurveyReviewDto surveyReviewDto, Long userId)
			throws CustomValidationException;

	/**
	 * <p>
	 * To get all the KM Codes for survey review
	 * </p>
	 *
	 * @return List<String>
	 */
	List<String> getAllKmCodes();

	/**
	 * <p>
	 * To save the survey review based on kmId and Farmer Group Id
	 * </p>
	 *
	 * @param kmFarmerGroupIdDto
	 * @param userId
	 * @return
	 * @throws CustomValidationException
	 */
	MessageDto saveSurveyReviewByKmIdAndFgId(KmFarmerGroupIdDto kmFarmerGroupIdDto, Long userId)
			throws CustomValidationException;

	/**
	 * <p>
	 * To submit the survey review based on kmId and Farmer Group Id
	 * </p>
	 *
	 * @param kmFarmerGroupIdDto
	 * @param userId
	 * @return
	 * @throws CustomValidationException
	 */
	MessageDto submitSurveyReviewByKmIdAndFgId(KmFarmerGroupIdDto kmFarmerGroupIdDto, Long userId)
			throws CustomValidationException;

	/**
	 * <p>
	 * returns farmer group id and name for particular km id
	 * </p>
	 * 
	 * @param kmId
	 * @param userId
	 * @return List<FarmerGroupProjectionDto>
	 * @throws CustomValidationException
	 */
	List<FarmerGroupProjectionDto> getAllFarmerGroupsByKmId(String kmId, Long userId)
			throws CustomValidationException;

	/**
	 * returns farmer name ,module name and last submitted date for particular km id
	 * 
	 * @param kmId
	 * @param farmerGroupId
	 * @return PaginationResult<FarmerModuleProjectionDto>
	 * @throws CustomValidationException
	 */
	PaginationResult<FarmerModuleProjectionDto> getFarmerModule(String kmId, String farmerGroupId, Integer page,
			Integer size, String sort, String direction) throws CustomValidationException;

	List<AtsourceSurveyReviewDto> categorizeAndSaveAtSourceReviews(List<AtsourceSurveyReviewDto> atsourceSurveyReviewDtoList, Long userId,int appId, String token) throws CustomValidationException;
}
