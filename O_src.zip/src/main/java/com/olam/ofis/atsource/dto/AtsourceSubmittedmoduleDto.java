/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import com.olam.ofis.atsource.model.Status;

public class AtsourceSubmittedmoduleDto implements Serializable {
	
	private static final long serialVersionUID = -2226467473696337568L;
	
	public AtsourceSubmittedmoduleDto() {
		//default constructor
	}

	private Integer id;

	private Integer moduleId;

	private Integer farmerGroupId;

	private Status status;

	private Integer versionNumber;
	
	private Integer appId;

	private Date createdAt;

	private BigInteger createdBy;

	private Date rejectedDate;

	private Date submittedDate;

	private Date approvedDate;

	private Date updatedAt;

	private BigInteger updatedBy;

	private List<AtSourceSurveyAnswerDto> surveyAnswers;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public Integer getFarmerGroupId() {
		return farmerGroupId;
	}

	public void setFarmerGroupId(Integer farmerGroupId) {
		this.farmerGroupId = farmerGroupId;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Integer getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(Integer versionNumber) {
		this.versionNumber = versionNumber;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public BigInteger getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(BigInteger createdBy) {
		this.createdBy = createdBy;
	}

	public Date getRejectedDate() {
		return rejectedDate;
	}

	public void setRejectedDate(Date rejectedDate) {
		this.rejectedDate = rejectedDate;
	}

	public Date getSubmittedDate() {
		return submittedDate;
	}

	public void setSubmittedDate(Date submittedDate) {
		this.submittedDate = submittedDate;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public BigInteger getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(BigInteger updatedBy) {
		this.updatedBy = updatedBy;
	}

	public List<AtSourceSurveyAnswerDto> getSurveyAnswers() {
		return surveyAnswers;
	}

	public void setSurveyAnswers(List<AtSourceSurveyAnswerDto> surveyAnswers) {
		this.surveyAnswers = surveyAnswers;
	}
	
	

}
