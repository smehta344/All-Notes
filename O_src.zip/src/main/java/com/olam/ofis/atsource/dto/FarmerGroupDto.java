/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.dto;

/**
 * Created by Ideas2it-Karthick on 3/4/19.
 */
public class FarmerGroupDto {

	public FarmerGroupDto() {
		// default constructor
	}
	
	private Long farmerGroupId;
	private String farmerGroupName;
	private String code;

	public Long getFarmerGroupId() {
		return farmerGroupId;
	}

	public void setFarmerGroupId(Long farmerGroupId) {
		this.farmerGroupId = farmerGroupId;
	}

	public String getFarmerGroupName() {
		return farmerGroupName;
	}

	public void setFarmerGroupName(String farmerGroupName) {
		this.farmerGroupName = farmerGroupName;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	

}
