/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.olam.ofis.atsource.dto.FarmerGroupResult;
import com.olam.ofis.atsource.model.District;

public interface DistrictRepository extends JpaRepository<District, Serializable> {

	@Query("SELECT fg.farmerGroupId as farmerGroupId,fg.name as name FROM District as district "
			+ "join Region as region on region.id = district.regionId and district.id in :moduleAssignmentIds "
			+ "join Country as country on region.countryId=country.countryId "
			+ "join FarmerGroup as fg on fg.countryId = country.countryId group by fg.farmerGroupId")
	List<FarmerGroupResult> getFarmerGroupsByDistrictIds(@Param("moduleAssignmentIds") List<Long> moduleAssignmentIds);
}
