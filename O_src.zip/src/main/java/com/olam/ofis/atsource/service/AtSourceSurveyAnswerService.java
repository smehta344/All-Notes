/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.service;

import java.util.List;

import com.olam.ofis.atsource.dto.AtSourceQuestionDto;
import com.olam.ofis.atsource.dto.AtSourceSurveyAnswerDto;
import com.olam.ofis.atsource.dto.AtsourceSubmittedmoduleDto;
import com.olam.ofis.atsource.dto.AtsourceSurveyResponseDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.ModuleDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.model.FarmerGroup;
import com.olam.ofis.atsource.util.PaginationResult;

public interface AtSourceSurveyAnswerService {

	/**
	 * <p>
	 * Used to get all atsource survey answers.
	 * </p>
	 * 
	 * @return atSourceSurveyAnswersList
	 */
	List<AtSourceSurveyAnswerDto> findAll();

	/**
	 * <p>
	 * Used to get survey answers by id.
	 * </p>
	 * 
	 * @param id - Get atsource survey answers given id.
	 * @return atSourceSurveyAnswer - If id present then surveyAnswer or null.
	 * @throws CustomValidationException
	 */
	AtSourceSurveyAnswerDto findById(Long id) throws CustomValidationException;

	/**
	 * <p>
	 * Used to create atSource survey answers while save or submitting a module.
	 * </p>
	 *
	 * @param atsourceSubmittedmoduleDto
	 * @param userId                     - Based on userId
	 * @return
	 */
	AtsourceSubmittedmoduleDto createAnswer(AtsourceSubmittedmoduleDto atsourceSubmittedmoduleDto, Long userId)
			throws CustomValidationException;

	/**
	 * <p>
	 * Used to create atSource survey answers while save or submitting a module.
	 * </p>
	 *
	 * @param atsourceSubmittedmoduleDto
	 * @param userId                     - Based on userId
	 * @return
	 */
	AtsourceSubmittedmoduleDto updateAnswer(Long id, AtsourceSubmittedmoduleDto atsourceSubmittedmoduleDto, Long userId)
			throws CustomValidationException;

	/**
	 * <p>
	 * Used to get paginated atsource survey answers.
	 * </p>
	 * 
	 * @param pageNo    - Get given page number records.
	 * @param size      - Total number of records per page.
	 * @param orderBy   - Based on given field orderBy is working
	 * @param direction - asc or desc.
	 * @return
	 */
	PaginationResult<AtSourceSurveyAnswerDto> getPaginatedSurveyAnswers(Integer pageNo, Integer size, String orderBy,
			String direction);

	/**
	 * Get all farmer groups based on module assignments
	 *
	 * @return
	 * @param userId
	 */
	ModuleDto getFarmerGroups(Long userId) throws CustomValidationException;

	/**
	 * <p>
	 * Used to get all atsource survey questions.
	 * </p>
	 * 
	 * @return surveyQuestionList
	 * @throws CustomValidationException
	 */
	List<AtSourceQuestionDto> getAtSourceSurveyQuestions() throws CustomValidationException;

	/**
	 * <p>
	 * Used to get survey answers by farmer group id.
	 * </p>
	 * 
	 * @param farmerGroupId - Get survey answers by farmer group id.
	 * @return surveyAnswers
	 * @throws CustomValidationException - If survey answers not present then throws
	 *                                   exception
	 */
	List<AtSourceSurveyAnswerDto> getSurveyAnswersByFarmerGroupId(Integer farmerGroupId)
			throws CustomValidationException;

	/**
	 * <p>
	 * Used to get survey answers by farmer group id.
	 * </p>
	 *
	 * @param id - Get atsource survey answers given farmer group id.
	 * @return atSourceSurveyAnswer
	 * @throws CustomValidationException
	 */
	AtsourceSubmittedmoduleDto findByFarmerGroupId(Long id) throws CustomValidationException;

	/**
	 * <p>
	 * Used to save the farmer group survey response from Atsource
	 * </p>
	 *
	 * @param response - List of {@link AtsourceSurveyResponseDto}
	 * @param userId   - User Id
	 * @return MessageDto
	 * @throws CustomValidationException
	 */
	MessageDto saveAtsourceSurveyResponses(List<AtsourceSurveyResponseDto> responses, Long userId)
			throws CustomValidationException;
	
	
	public List<FarmerGroup> getFgByDataVisibility(Long userId);
}
