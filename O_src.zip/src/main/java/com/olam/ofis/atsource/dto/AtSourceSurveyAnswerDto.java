/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.dto;

import java.math.BigDecimal;
import java.util.Date;

public class AtSourceSurveyAnswerDto extends BaseDTO {

	private static final long serialVersionUID = 1298408767236202323L;

	private Integer id;

	private Integer questionId;

	private Integer farmerGroupId;

	private Integer submittedmoduleId;

	private Boolean answerBoolean;

	private Date answerDate;

	private BigDecimal answerDecimal;

	private Integer answerInt;

	private String answerText;

	private Boolean edited;

	private String answer;

	public AtSourceSurveyAnswerDto() {
		//Default Constructor
	}

	public Integer getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}

	public Integer getFarmerGroupId() {
		return farmerGroupId;
	}

	public void setFarmerGroupId(Integer farmerGroupId) {
		this.farmerGroupId = farmerGroupId;
	}

	public Integer getSubmittedmoduleId() {
		return submittedmoduleId;
	}

	public void setSubmittedmoduleId(Integer submittedmoduleId) {
		this.submittedmoduleId = submittedmoduleId;
	}

	public Boolean getAnswerBoolean() {
		return answerBoolean;
	}

	public void setAnswerBoolean(Boolean answerBoolean) {
		this.answerBoolean = answerBoolean;
	}

	public Date getAnswerDate() {
		return answerDate;
	}

	public void setAnswerDate(Date answerDate) {
		this.answerDate = answerDate;
	}

	public BigDecimal getAnswerDecimal() {
		return answerDecimal;
	}

	public void setAnswerDecimal(BigDecimal answerDecimal) {
		this.answerDecimal = answerDecimal;
	}

	public Integer getAnswerInt() {
		return answerInt;
	}

	public void setAnswerInt(Integer answerInt) {
		this.answerInt = answerInt;
	}

	public String getAnswerText() {
		return answerText;
	}

	public void setAnswerText(String answerText) {
		this.answerText = answerText;
	}

	public Boolean getEdited() { return edited; }

	public void setEdited(Boolean edited) { this.edited = edited; }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
}
