/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.olam.ofis.atsource.util.AtSourceConstants;

@Entity
@Table(schema = AtSourceConstants.MASTER_SCHEMA, name = "products", catalog = AtSourceConstants.MASTER_SCHEMA)
public class Product implements Serializable {

	public Product() {
		// default constructor
	}
	
	private static final long serialVersionUID = -4513154542121041L;

	@Id
	@Column(name = "id")
	private Long productId;

	@Column(name = "name")
	private String productName;

	@Column(name = "name_fr")
	private String productNameFr;

	@Column(name = "name_es")
	private String productNameEs;

	@Column(name = "name_pt")
	private String productNamePt;

	@Column(name = "name_tr")
	private String productNameTr;

	@Column(name = "name_vi")
	private String productNameVi;

	@Column(name = "name_th")
	private String productNameTh;

	@Column(name = "name_lo")
	private String productNameLo;

	@Column(name = "name_id")
	private String productNameId;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "active")
	private Boolean active;

	@Column(name = "created_at")
	private Date createdTs;

	@Column(name = "updated_at")
	private Date updatedTs;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductNameFr() {
		return productNameFr;
	}

	public void setProductNameFr(String productNameFr) {
		this.productNameFr = productNameFr;
	}

	public String getProductNameEs() {
		return productNameEs;
	}

	public void setProductNameEs(String productNameEs) {
		this.productNameEs = productNameEs;
	}

	public String getProductNamePt() {
		return productNamePt;
	}

	public void setProductNamePt(String productNamePt) {
		this.productNamePt = productNamePt;
	}

	public String getProductNameTr() {
		return productNameTr;
	}

	public void setProductNameTr(String productNameTr) {
		this.productNameTr = productNameTr;
	}

	public String getProductNameVi() {
		return productNameVi;
	}

	public void setProductNameVi(String productNameVi) {
		this.productNameVi = productNameVi;
	}

	public String getProductNameTh() {
		return productNameTh;
	}

	public void setProductNameTh(String productNameTh) {
		this.productNameTh = productNameTh;
	}

	public String getProductNameLo() {
		return productNameLo;
	}

	public void setProductNameLo(String productNameLo) {
		this.productNameLo = productNameLo;
	}

	public String getProductNameId() {
		return productNameId;
	}

	public void setProductNameId(String productNameId) {
		this.productNameId = productNameId;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public Date getUpdatedTs() {
		return updatedTs;
	}

	public void setUpdatedTs(Date updatedTs) {
		this.updatedTs = updatedTs;
	}

}
