/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.service.impl;

import java.lang.reflect.Type;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.hibernate.exception.ConstraintViolationException;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.olam.ofis.atsource.dto.AtSourceQuestionDto;
import com.olam.ofis.atsource.dto.AtSourceQuestionMinMaxDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.SubModuleDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.exception.ErrorCode;
import com.olam.ofis.atsource.model.AtsourceModuleAssignment;
import com.olam.ofis.atsource.model.AtsourceSurveyquestion;
import com.olam.ofis.atsource.repository.AtSourceSurveyQuestionRepository;
import com.olam.ofis.atsource.repository.AtsourceSurveyquestionQueryResult;
import com.olam.ofis.atsource.service.AtSourceQuestionsService;
import com.olam.ofis.atsource.service.AtsourceModuleAssignmentService;
import com.olam.ofis.atsource.util.AtSourceConstants;
import com.olam.ofis.atsource.util.CommonUtil;
import com.olam.ofis.atsource.util.PaginationResult;

@Service
public class AtSourceQuestionsServiceImpl implements AtSourceQuestionsService {

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	AtSourceSurveyQuestionRepository atSourceSurveyQuestionRepository;
	@Autowired
	AtsourceModuleAssignmentService atsourceModuleAssignmentService;

	/**
	 * Fetch all active questions
	 *
	 * @param pageNo
	 * @param size
	 * @param orderBy
	 * @param direction
	 *
	 */
	public PaginationResult<AtSourceQuestionDto> getAllAtsourceQuestions(Integer pageNo, Integer size, String orderBy,
			String direction) {
		orderBy = setOrderByColumns(orderBy);
		Pageable pageable = CommonUtil.getPageRequest(pageNo, size, orderBy, direction);
		Page<AtsourceSurveyquestionQueryResult> atsourceSurveyquestions = atSourceSurveyQuestionRepository
				.findAllQuestionsResult(pageable);
		return convertPageToPaginationResult(atsourceSurveyquestions);
	}

	private String setOrderByColumns(String orderBy) {
		switch (orderBy) {
			case "submoduleName":
				orderBy = "s.name";
				break;
			case "dataTypeName":
				orderBy = "d.id";
				break;
			default:
				break;
		}
		return orderBy;
	}

	/**
	 * Save atsource survey question
	 *
	 * @param userId
	 * @param atSourceQuestionDto
	 *
	 */
	@Override
	public MessageDto saveQuestion(Long userId, AtSourceQuestionDto atSourceQuestionDto)
			throws CustomValidationException {
		MessageDto messageDto = new MessageDto();
		try {
			AtsourceSurveyquestion saveAtsourceSurveyquestion = convertToModel(atSourceQuestionDto);
			if (null != saveAtsourceSurveyquestion) {
				if(CommonUtil.isNull(atSourceQuestionDto.getKmCode())) {
					throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2034);
				}
				setQuestionsData(userId, atSourceQuestionDto, saveAtsourceSurveyquestion);
				atSourceSurveyQuestionRepository.save(saveAtsourceSurveyquestion);
				messageDto.setMessage(AtSourceConstants.SUCCESS);
			}
		} catch(DataIntegrityViolationException e) {
			ConstraintViolationException d = (ConstraintViolationException) e.getCause();
			if ( d.getConstraintName().contains( "km_code_UNIQUE" ) ) {
				throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2035, e);
			}
		}
		return messageDto;
	}


	private AtsourceSurveyquestion convertToModel(AtSourceQuestionDto atSourceQuestionDto) {
		if (CommonUtil.isNotNull(atSourceQuestionDto)) {
			return modelMapper.map(atSourceQuestionDto, AtsourceSurveyquestion.class);
		}
		return null;
	}

	/**
	 * Fetch question by question Id
	 *
	 * @param questionId
	 *
	 */
	@Override
	public AtSourceQuestionDto getQuestionById(Integer questionId) {
		AtSourceQuestionDto atSourceQuestionDto = new AtSourceQuestionDto();
		AtsourceSurveyquestion atsourceSurveyquestion = atSourceSurveyQuestionRepository.getQuestionById(questionId);
		if (CommonUtil.isNotNull(atsourceSurveyquestion)) {
			Type listType = new TypeToken<AtSourceQuestionDto>() {
			}.getType();
			atSourceQuestionDto = modelMapper.map(atsourceSurveyquestion, listType);
		}
		return atSourceQuestionDto;
	}

	/**
	 * Get pagination result from result
	 *
	 * @param page
	 *
	 */
	private PaginationResult<AtSourceQuestionDto> convertPageToPaginationResult(
			Page<AtsourceSurveyquestionQueryResult> page) {
		PaginationResult<AtSourceQuestionDto> paginationResult = new PaginationResult<>();
		paginationResult.setContent(page.getContent().stream().map(this::convertToDto).collect(Collectors.toList()));
		paginationResult.setSize(page.getSize());
		paginationResult.setTotalPages(page.getTotalPages());
		paginationResult.setPageNumber(page.getPageable().getPageNumber() + 1);
		paginationResult.setTotalCount(page.getTotalElements());
		return paginationResult;
	}

	private AtSourceQuestionDto convertToDto(AtsourceSurveyquestionQueryResult atsourceSurveyquestionQueryResult) {
		AtSourceQuestionDto atSourceQuestionDto = new AtSourceQuestionDto();
		// question details
		atSourceQuestionDto.setId(atsourceSurveyquestionQueryResult.getAtsourceQuestionResult().getId());
		atSourceQuestionDto.setPosition(atsourceSurveyquestionQueryResult.getAtsourceQuestionResult().getPosition());
		atSourceQuestionDto.setQuestion(atsourceSurveyquestionQueryResult.getAtsourceQuestionResult().getQuestion());
		atSourceQuestionDto.setAppId(atsourceSurveyquestionQueryResult.getAtsourceQuestionResult().getAppId());
		atSourceQuestionDto.setActive(atsourceSurveyquestionQueryResult.getAtsourceQuestionResult().getActive());
		atSourceQuestionDto.setKmCode(atsourceSurveyquestionQueryResult.getAtsourceQuestionResult().getKmCode());
		atSourceQuestionDto.setMaxValue(atsourceSurveyquestionQueryResult.getAtsourceQuestionResult().getMaxValue());
		atSourceQuestionDto.setMinValue(atsourceSurveyquestionQueryResult.getAtsourceQuestionResult().getMinValue());

		// submodule details
		atSourceQuestionDto.setSubmoduleName(atsourceSurveyquestionQueryResult.getSubModuleResult().getName());

		// data type details
		atSourceQuestionDto.setDataTypeName(atsourceSurveyquestionQueryResult.getDataTypeResult().getName());
		return atSourceQuestionDto;
	}

	private void setQuestionsData(Long userId, AtSourceQuestionDto atSourceQuestionDto,
								  AtsourceSurveyquestion saveAtsourceSurveyquestion) {
		setDefaultQuestionValue(atSourceQuestionDto, saveAtsourceSurveyquestion);
		
		if (atSourceQuestionDto.getId() == null) {
			saveAtsourceSurveyquestion.setCreatedAt(new Date());
			saveAtsourceSurveyquestion.setUpdatedAt(new Date());
			saveAtsourceSurveyquestion.setCreatedBy(BigInteger.valueOf(userId));
		} else {
			Optional<AtsourceSurveyquestion> atsourceSurveyquestionsOptional = atSourceSurveyQuestionRepository
					.findById(atSourceQuestionDto.getId());
			if (atsourceSurveyquestionsOptional.isPresent()) {
				AtsourceSurveyquestion atsourceSurveyquestion = atsourceSurveyquestionsOptional.get();
				saveAtsourceSurveyquestion.setCreatedAt(atsourceSurveyquestion.getCreatedAt());
				saveAtsourceSurveyquestion.setUpdatedAt(new Date());
				saveAtsourceSurveyquestion.setCreatedBy(atsourceSurveyquestion.getCreatedBy());
				saveAtsourceSurveyquestion.setUpdatedBy(BigInteger.valueOf(userId));
			}
		}
	}
	
	private void setDefaultQuestionValue(AtSourceQuestionDto atSourceQuestionDto,
			  AtsourceSurveyquestion saveAtsourceSurveyquestion) {
		saveAtsourceSurveyquestion
		.setQuestionFr(atSourceQuestionDto.getQuestionFr() != null ? atSourceQuestionDto.getQuestionFr()
				: atSourceQuestionDto.getQuestion());
		saveAtsourceSurveyquestion
				.setQuestionEs(atSourceQuestionDto.getQuestionEs() != null ? atSourceQuestionDto.getQuestionEs()
						: atSourceQuestionDto.getQuestion());
		saveAtsourceSurveyquestion
				.setQuestionId(atSourceQuestionDto.getQuestionId() != null ? atSourceQuestionDto.getQuestionId()
						: atSourceQuestionDto.getQuestion());
		saveAtsourceSurveyquestion
				.setQuestionPt(atSourceQuestionDto.getQuestionPt() != null ? atSourceQuestionDto.getQuestionPt()
						: atSourceQuestionDto.getQuestion());
		saveAtsourceSurveyquestion
				.setQuestionTr(atSourceQuestionDto.getQuestionTr() != null ? atSourceQuestionDto.getQuestionTr()
						: atSourceQuestionDto.getQuestion());
		saveAtsourceSurveyquestion
				.setQuestionLo(atSourceQuestionDto.getQuestionLo() != null ? atSourceQuestionDto.getQuestionLo()
						: atSourceQuestionDto.getQuestion());
		saveAtsourceSurveyquestion
				.setQuestionVi(atSourceQuestionDto.getQuestionVi() != null ? atSourceQuestionDto.getQuestionVi()
						: atSourceQuestionDto.getQuestion());
		saveAtsourceSurveyquestion
				.setQuestionTh(atSourceQuestionDto.getQuestionTh() != null ? atSourceQuestionDto.getQuestionTh()
						: atSourceQuestionDto.getQuestion());
		saveAtsourceSurveyquestion
				.setActive(atSourceQuestionDto.getActive() == null ? 0 : atSourceQuestionDto.getActive());
		saveAtsourceSurveyquestion.setKmCode(atSourceQuestionDto.getKmCode());
	}

	@Override
	public List<SubModuleDto> getAllSubModules() throws CustomValidationException {
		AtsourceModuleAssignment atsourceModuleAssignment = atsourceModuleAssignmentService.getAtSourceModule();
		return atsourceModuleAssignmentService
				.getAllSubmodulesByModuleId(atsourceModuleAssignment.getModuleId().getId());
	}

	@Override
	public List<AtsourceSurveyquestion> getAtSourceQuestions() throws CustomValidationException {
		return atSourceSurveyQuestionRepository.findAtsourceQuestionsBySubmodule();
	}

	/**
	 * Update atsource survey question min max values
	 *
	 * @param userId
	 * @param atSourceQuestionDto
	 *
	 */
	@Override
	public MessageDto updateQuestionMinMaxValues(Long userId, AtSourceQuestionDto atSourceQuestionDto)
			throws CustomValidationException {
		MessageDto messageDto = new MessageDto();
		if(atSourceQuestionDto!=null && atSourceQuestionDto.getAtSourceQuestionMinMaxDto()!=null) {
			AtSourceQuestionMinMaxDto minMaxDto = atSourceQuestionDto.getAtSourceQuestionMinMaxDto();
			if (minMaxDto.getKmCode() == null) {
				throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2028);
			}
			if (minMaxDto.getMinValue() == null && minMaxDto.getMaxValue() == null) {
				throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2030);
			}
			AtsourceSurveyquestion atsourceSurveyquestion = atSourceSurveyQuestionRepository.
					findByKmCode(minMaxDto.getKmCode());
			if (CommonUtil.isNull(atsourceSurveyquestion)) {
				throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2029);
			}
			try {
				if (minMaxDto.getMinValue() != null) {
					atsourceSurveyquestion.setMinValue(minMaxDto.getMinValue());
				}
				if (minMaxDto.getMaxValue() != null) {
					atsourceSurveyquestion.setMaxValue(minMaxDto.getMaxValue());
				}
				atsourceSurveyquestion.setUpdatedAt(new Date());
				atsourceSurveyquestion.setUpdatedBy(BigInteger.valueOf(userId));
				atSourceSurveyQuestionRepository.save(atsourceSurveyquestion);
				messageDto.setMessage(AtSourceConstants.SUCCESS);
			} catch (Exception e) {
				throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2015, e);
			}

		}
		return messageDto;
	}
}
