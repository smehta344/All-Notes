/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.dto;


import java.util.List;

/**
 * Created by Ideas2it-Karthick on 12/4/19.
 */
public class ModuleDto {

	public ModuleDto() {
		// default constructor
	}
	
    private Integer moduleId;
    private String moduleName;
    private List<FarmerGroupDto> farmerGroupDtoList;
    private List<SubModuleResullt> subModuleDtoList;

    public Integer getModuleId() {
        return moduleId;
    }

    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public List<SubModuleResullt> getSubModuleDtoList() {
        return subModuleDtoList;
    }

    public void setSubModuleDtoList(List<SubModuleResullt> subModuleDtoList) {
        this.subModuleDtoList = subModuleDtoList;
    }

    public List<FarmerGroupDto> getFarmerGroupDtoList() {
        return farmerGroupDtoList;
    }

    public void setFarmerGroupDtoList(List<FarmerGroupDto> farmerGroupDtoList) {
        this.farmerGroupDtoList = farmerGroupDtoList;
    }
}
