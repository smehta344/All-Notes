/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.util;

import org.apache.commons.lang3.time.StopWatch;
import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Interceptor for methods annotated with {@link OlamScfLog}
 */
public class MethodInterceptor {

	private static final String TIME = "TIME";
	private static final String METHOD = "METHOD";

	public Object logTime(ProceedingJoinPoint pjp) throws Throwable {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		Logger logger = LoggerFactory.getLogger(pjp.getTarget().getClass());
		String methodSignature = pjp.getSignature().toShortString();
		logger.trace("Entering {}", methodSignature);
		try {
			return pjp.proceed();
		} finally {
			stopWatch.stop();
			if (logger.isDebugEnabled()) {
				StringBuilder buffer = new StringBuilder();
				buffer.append(METHOD).append('=').append(methodSignature);
				buffer.append(", ").append(TIME).append('=').append(stopWatch.getTime());
				logger.debug(buffer.toString());
			}
		}
	}

	/**
	 * Interceptor method for
	 * 
	 * @param pjp
	 * @param agitLog
	 * @return return value of the method intercepted
	 * @throws Throwable
	 */
	public Object invoke(ProceedingJoinPoint pjp, OlamOfisLog olamFpsLog) throws Throwable {
		StopWatch stopWatch = new StopWatch(); 
		stopWatch.start();
		Object returnVal = null;
		try {
			returnVal = pjp.proceed(); 
			return returnVal;
		} catch (Exception e) {
			returnVal = e.getClass().getName() + ": " + e.getMessage();
			throw e;
		} finally {
			invokeFinally(pjp, olamFpsLog, stopWatch, returnVal);
		}
	}
	
	/**
	 * 
	 * @param pjp
	 * @param olamFpsLog
	 * @param stopWatch
	 * @param returnVal
	 */
	private void invokeFinally(ProceedingJoinPoint pjp, OlamOfisLog olamFpsLog, StopWatch stopWatch, Object returnVal) {
		stopWatch.stop();
		long time = stopWatch.getTime();
		Logger logger = LoggerFactory.getLogger(pjp.getTarget().getClass());

		boolean debug = olamFpsLog.debug();
		boolean exceededThreshold = olamFpsLog.threshold() < time;
		if ((debug && logger.isDebugEnabled()) || (!debug && logger.isInfoEnabled()) || exceededThreshold) {
			String methodSignature = pjp.getSignature().toShortString();
			Object[] args = pjp.getArgs();

			StringBuilder buffer = new StringBuilder();
			buffer.append(METHOD).append('=').append(methodSignature);

			String value = olamFpsLog.value();
			if (!value.isEmpty()) {
				buffer.append(", ").append(" API=").append(value);
			}

			if (olamFpsLog.time() || exceededThreshold) {
				buffer.append(", ").append(TIME).append('=').append(time);
			}
			boolean agitLogArgs = olamFpsLog.args();
			
			agitLogArgBuffer(agitLogArgs, buffer, args, olamFpsLog, returnVal);

			if (exceededThreshold) {
				logger.warn(buffer.toString());
			} else if (debug) {
				logger.debug(buffer.toString());
			} else {
				logger.info(buffer.toString());
			}
		}
	}
	
	private void agitLogArgBuffer(boolean agitLogArgs, StringBuilder buffer, Object[] args,
			OlamOfisLog olamFpsLog, Object returnVal) {
		if (agitLogArgs && args.length > 0) {
			for (int argIndex = 0; argIndex < args.length; argIndex++) {
				buffer.append(", ").append('a').append(argIndex).append('=').append(args[argIndex]);
			}
		}
		if (olamFpsLog.returnValue()) {
			buffer.append(", ").append("RETURN").append('=').append(returnVal);
		}
	}

}
