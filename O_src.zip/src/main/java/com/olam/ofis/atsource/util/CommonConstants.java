/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.util;

public final class CommonConstants {

	private CommonConstants() {
	}

	public static final String BEGIN = "Begin";
	public static final String END = "End";
	public static final String TRUE = "true";
	public static final String YEARS = "YEARS";
	public static final String MONTH = "MONTH";
	public static final String DAY = "DAY";
	public static final String DATE = "DATE";
	public static final String WEEK = "WEEK";
	public static final String SURVEY_JSON_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String SURVEY_MONGO_JSON_DATE_FORMAT = "yyyy-MM-dd";
	public static final String TEN_DIGITS_DECIMAL_FORMAT = "#.##########";
	public static final String CURRENT_TIMESTAMP_DATE_FORMAT = "yyyy.MM.dd.HH.mm.ss";

	public static final String YES = "Yes";

	public static final String NO = "No";

	public static final String YES_SINGLE_QUOTES = "'Yes'";

	public static final String NO_SINGLE_QUOTES = "'No'";

	public static final String DISPLAY_TYPE = "Yes/No";

	public static final String CONDITIONAL_CHECK_PREFIX = "[###]";

	public static final String CLEAN_WATER_SUPPLY = "Clean Water Supply";
	public static final String HEALTH_CENTRE = "Health Centre";
	public static final String BUYING_CENTRE = "Buying Centre";
	public static final String SCHOOL = "School";

	public static final String MASTER_SCHEMA = "master";

	public static final String SURVEY_SCHEMA = "survey";

	public static final String FARMER_SCHEMA = "farmer";

	public static final String AUTHORIZATION = "Authorization";

	// TT Mobile App Suffix
	public static final String TT_MOBILE_CLIENT = "2";
	public static final String TT_MOBILE_SFX = "_1";

	// Application Types
	public static final int APPLICATIONTYPE_OFIS = 1;
	public static final int APPLICATIONTYPE_OT = 2;
	public static final int APPLICATIONTYPE_OD = 3;
	public static final int APPLICATIONTYPE_FSP = 4;
	public static final String STRING_DESC = "desc";

}
