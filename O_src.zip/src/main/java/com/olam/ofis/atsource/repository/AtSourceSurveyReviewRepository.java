/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.olam.ofis.atsource.dto.FarmerGroupProjectionDto;
import com.olam.ofis.atsource.dto.FarmerModuleProjectionDto;
import com.olam.ofis.atsource.model.AtsourceSurveyReview;

@Repository
public interface AtSourceSurveyReviewRepository extends JpaRepository<AtsourceSurveyReview, Integer> {

	/**
	 * <p>
	 * return the list of farmer group id and name for the user with country data
	 * visibility for particular km id
	 * </p>
	 * 
	 * @param kmId
	 * @param userId
	 * @return List<FarmerGroupProjectionDto>
	 */
	@Query(value = " select distinct fg.farmer_group_id as farmerGroupId,fg.name as farmerGroupName "
			+ " from master.farmergroups fg join master.country_user cu on fg.country_id=cu.country_id "
			+ " join ofisatsource.atsource_surveyreview asr on fg.farmer_group_id=asr.farmer_group_id "
			+ " where cu.user_id= :userId and asr.status in (2,3) and asr.km_id= :kmId ", nativeQuery = true)
	List<FarmerGroupProjectionDto> findAllFarmerGroupForCountryByKmId(String kmId, Long userId);

	/**
	 * <p>
	 * return the list of farmer group id and name for the user with farmer group
	 * data visibility for particular km id
	 * </p>
	 * 
	 * @param kmId
	 * @param userId
	 * @return List<FarmerGroupProjectionDto>
	 */
	@Query(value = " select distinct fg.farmer_group_id as farmerGroupId, fg.name as farmerGroupName "
			+ "from master.farmergroup_user fgu "
			+ " join master.farmergroups fg on fg.farmer_group_id = fgu.farmergroup_id "
			+ " join ofisatsource.atsource_surveyreview asr on fgu.farmergroup_id=asr.farmer_group_id "
			+ "  where asr.km_id= :kmId and fgu.user_id= :userId and asr.status in (2,3) ", nativeQuery = true)
	List<FarmerGroupProjectionDto> findAllFarmerGroupForFgByKmId(String kmId, Long userId);

	/**
	 * <p>
	 * return the list of farmer group id and name for the user with partner data
	 * visibility for particular km id
	 * </p>
	 * 
	 * @param kmId
	 * @param userId
	 * @return List<FarmerGroupProjectionDto>
	 */
	@Query(value = " select distinct fg.farmer_group_id as farmerGroupId,fg.name as farmerGroupName "
			+ "from master.partner_user pu join master.farmergroups fg "
			+ " on pu.partner_id=fg.partner_id "
			+ " join ofisatsource.atsource_surveyreview asr on fg.farmer_group_id=asr.farmer_group_id "
			+ " where pu.user_id= :userId and asr.km_id= :kmId and asr.status in (2,3) ", nativeQuery = true)
	List<FarmerGroupProjectionDto> findAllFarmerGroupForPartnerByKmId(String kmId, Long userId);

	/**
	 * <p>
	 * returns farmer name , module name and module's last submitted date for the
	 * particular km id and farmer group id
	 * </p>
	 * 
	 * @param kmId
	 * @param farmerGroupId
	 * @return List<FarmerGroupProjectionDto>
	 */

	@Query(value = " SELECT farmerId,farmerName,moduleId,moduleName,submittedModuleId,submissionDate,questionId FROM " 
			+ " ( SELECT f.id AS farmerId,trim(f.farmer_name) AS farmerName,m.id AS moduleId, "
			+ " trim(m.name) AS moduleName,max(sm.id) AS submittedModuleId,max(trim(sm.submission_date)) AS submissionDate, "
			+ " kmq.question_id AS questionId FROM ofisatsource.atsource_surveyreview asr JOIN  "
			+ " survey.km_questionmapping kmq ON kmq.km_id = asr.km_id JOIN  "
			+ " farmer.farmer f ON f.farmer_group_id = asr.farmer_group_id JOIN  "
			+ " master.farmergroups fg on fg.farmer_group_id=f.farmer_group_id JOIN "
			+ " survey.modules m ON m.id = kmq.module_id JOIN "
			+ " survey.submittedmodules sm ON m.id = sm.module_id AND f.id = sm.farmer_id "
			+ " WHERE asr.km_id = :kmId AND asr.farmer_group_id = :farmerGroupId AND kmq.km_module = 'SURVEY' "
			+ " AND fg.active=1 AND fg.app_id=1 AND f.app_id=1 " + " AND f.is_active=1 "
			+ " GROUP BY f.id , m.id ) s ", countQuery = " SELECT count(f.id) "
					+ "  FROM  ofisatsource.atsource_surveyreview asr JOIN  "
					+ " survey.km_questionmapping kmq ON kmq.km_id = asr.km_id JOIN  "
					+ " farmer.farmer f ON f.farmer_group_id = asr.farmer_group_id JOIN  "
					+ " master.farmergroups fg on fg.farmer_group_id=f.farmer_group_id JOIN "
					+ " survey.modules m ON m.id = kmq.module_id JOIN "
					+ " survey.submittedmodules sm ON m.id = sm.module_id AND f.id = sm.farmer_id "
					+ " WHERE asr.km_id = :kmId AND asr.farmer_group_id = :farmerGroupId AND kmq.km_module = 'SURVEY' "
					+ " AND fg.active=1 AND fg.app_id=1 AND f.app_id=1 " + " AND f.is_active=1 "
					+ " GROUP BY f.id , m.id ", nativeQuery = true)
	Page<FarmerModuleProjectionDto> getFarmerModule(@Param("kmId") String kmId, 
					@Param("farmerGroupId") String farmerGroupId, Pageable pageable);

	@Query("Select distinct r.kmId from AtsourceSurveyReview r where r.status not in (1,3)")
	List<String> getAllKmCodes();

	AtsourceSurveyReview findByKmIdAndFarmerGroupId(String kmId, Integer farmerGroupId);
	
	
	@Query(value = "SELECT ar.farmer_group_id as farmerGroupId, fg.name as farmerGroupName " + 
			"FROM ofisatsource.atsource_surveyreview ar JOIN master.farmergroups fg ON "
			+ " fg.farmer_group_id = ar.farmer_group_id " + 
			"WHERE ar.km_id = :kmId AND fg.active = 1 AND fg.app_id = 1 ",nativeQuery = true )
	List<FarmerGroupProjectionDto> getAtSourceSurveyReviewFarmerGroups(@Param("kmId") String kmId);

}
