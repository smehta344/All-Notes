/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.olam.ofis.atsource.client.ITrainingPillarClient;
import com.olam.ofis.atsource.dto.AtsourceSurveyResponseDto;
import com.olam.ofis.atsource.dto.AtsourceSurveyReviewDto;
import com.olam.ofis.atsource.dto.FarmerGroupProjectionDto;
import com.olam.ofis.atsource.dto.FarmerModuleProjectionDto;
import com.olam.ofis.atsource.dto.KmFarmerGroupIdDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.exception.ErrorCode;
import com.olam.ofis.atsource.model.AtsourceSurveyReview;
import com.olam.ofis.atsource.model.FarmerGroup;
import com.olam.ofis.atsource.model.Status;
import com.olam.ofis.atsource.repository.AtSourceSurveyQuestionRepository;
import com.olam.ofis.atsource.repository.AtSourceSurveyReviewRepository;
import com.olam.ofis.atsource.repository.KmQuestionmappingRepository;
import com.olam.ofis.atsource.repository.TrainingPillarRepository;
import com.olam.ofis.atsource.service.AtSourceSurveyAnswerService;
import com.olam.ofis.atsource.service.AtSourceSurveyReviewService;
import com.olam.ofis.atsource.util.AtSourceConstants;
import com.olam.ofis.atsource.util.CommonUtil;
import com.olam.ofis.atsource.util.PaginationResult;

@Service
public class AtSourceSurveyReviewServiceImpl implements AtSourceSurveyReviewService {

	private static final Logger logger = LoggerFactory.getLogger(AtSourceSurveyReviewServiceImpl.class);

	@Autowired
	private AtSourceSurveyReviewRepository atSourceSurveyReviewRepository;

	@Autowired 
	TrainingPillarRepository trainingPillarRepository;
	
	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private AtSourceSurveyAnswerService atSourceSurveyAnswerService;

	@Autowired
	AtSourceSurveyQuestionRepository atSourceSurveyQuestionRepository;
	
	@Autowired
	KmQuestionmappingRepository kmQuestionmappingRepository;
	
	@Autowired
	ITrainingPillarClient iTrainingPillarClient;
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public MessageDto saveAtsourceSurveyReviewResponses(AtsourceSurveyReviewDto surveyReviewDto, Long userId)
			throws CustomValidationException {
		AtsourceSurveyReview existingSurveyReview = atSourceSurveyReviewRepository
				.findByKmIdAndFarmerGroupId(surveyReviewDto.getKmId(), surveyReviewDto.getFarmerGroupId());
		if (null != existingSurveyReview) {
			if (existingSurveyReview.getStatus().equals(Status.APPROVED)) {
				throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2040);
			} else if (existingSurveyReview.getStatus().equals(Status.REJECTED)) {
				throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2043);
			}
			existingSurveyReview.setStatus(surveyReviewDto.getStatus());
			return saveAtsourceSurveyReview(existingSurveyReview, userId);
		} else {
			AtsourceSurveyReview surveyReview = modelMapper.map(surveyReviewDto, AtsourceSurveyReview.class);
			surveyReview.setCreatedAt(new Date());
			surveyReview.setCreatedBy(userId);
			return saveAtsourceSurveyReview(surveyReview, userId);
		}
	}

	private MessageDto saveAtsourceSurveyReview(AtsourceSurveyReview surveyReview, Long userId) {
		if (surveyReview.getStatus().equals(Status.REJECTED)) {
			surveyReview.setRejectedDate(new Date());
		}
		surveyReview.setAppId(AtSourceConstants.APPLICATIONTYPE_OFIS);
		surveyReview.setUpdatedAt(new Date());
		surveyReview.setUpdatedBy(userId);
		atSourceSurveyReviewRepository.save(surveyReview);
		return new MessageDto(AtSourceConstants.SUCCESS);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public MessageDto updateAtsourceSurveyReviewResponses(Long reviewId, AtsourceSurveyReviewDto surveyReviewDto,
			Long userId) throws CustomValidationException {
		if (null == surveyReviewDto.getId()) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2037);
		}
		if (surveyReviewDto.getId().equals(reviewId)) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2038);
		}
		Optional<AtsourceSurveyReview> existingSurveyReview = atSourceSurveyReviewRepository
				.findById(surveyReviewDto.getId().intValue());
		if (!existingSurveyReview.isPresent()) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2039);
		} else if (existingSurveyReview.get().getStatus().equals(Status.APPROVED)) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2040);
		}
		try {
			AtsourceSurveyReview surveyReview = modelMapper.map(surveyReviewDto, AtsourceSurveyReview.class);
			if (surveyReview.getStatus().equals(Status.REJECTED)) {
				surveyReview.setRejectedDate(new Date());
			} else if (surveyReview.getStatus().equals(Status.SAVED)) {
				surveyReview.setSavedDate(new Date());
			} else if (surveyReview.getStatus().equals(Status.SUBMTTED)) {
				surveyReview.setSubmittedDate(new Date());
			}
			surveyReview.setUpdatedAt(new Date());
			atSourceSurveyReviewRepository.save(surveyReview);
			return new MessageDto(AtSourceConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Error while saving survey review: ", e);
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2036);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<String> getAllKmCodes() {
		return atSourceSurveyReviewRepository.getAllKmCodes();
	}

	public List<FarmerGroupProjectionDto> getAllFarmerGroupsByKmId(String kmId, Long userId)
			throws CustomValidationException {
		if (userId == null) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2006);
		}
		List<FarmerGroupProjectionDto> farmerGroupDto = new ArrayList<>();
		List<FarmerGroupProjectionDto> farmerGroupTmpDto =  atSourceSurveyReviewRepository.
						getAtSourceSurveyReviewFarmerGroups(kmId);
		
		if(CommonUtil.isNotNull(farmerGroupTmpDto)) {
			
			List<FarmerGroup> farmerGroupList = atSourceSurveyAnswerService.getFgByDataVisibility(userId);
			
			farmerGroupDto = farmerGroupTmpDto.stream().filter(
					obj->farmerGroupList.stream().anyMatch(
							fgGrp->fgGrp.getFarmerGroupId().equals(Long.parseLong(obj.getFarmerGroupId())))
					).collect(Collectors.toList());
		}

		return farmerGroupDto;
	}

	public PaginationResult<FarmerModuleProjectionDto> getFarmerModule(String kmId, String farmerGroupId, Integer page,
			Integer size,String sort,String direction) throws CustomValidationException {
		String orderBy = getMySQLOrderBy(sort);
		Pageable pageable = PageRequest.of(page - 1, size, Direction.fromString(direction), orderBy);
		Page<FarmerModuleProjectionDto> farmerModulePage = 
				atSourceSurveyReviewRepository.getFarmerModule(kmId, farmerGroupId,pageable);
		return convertPageToPaginationResult(farmerModulePage);
	}
	
	private String getMySQLOrderBy(String sort) {
		String orderBy = "";
		switch (sort) {
		case "moduleName":
			orderBy = "s.moduleName";
			break;
		case "farmerName":
			orderBy = "s.farmerName";
			break;
		case "submissionDate":
			orderBy = "s.submissionDate";
			break;
		default:
			orderBy = sort;
		}
		return orderBy;
	}
	
	private PaginationResult<FarmerModuleProjectionDto> convertPageToPaginationResult(
											Page<FarmerModuleProjectionDto> page) {
		PaginationResult<FarmerModuleProjectionDto> paginationResult = new PaginationResult<>();
		paginationResult.setPageNumber(page.getPageable().getPageNumber() + 1);
		paginationResult.setContent(page.getContent());
		paginationResult.setTotalPages(page.getTotalPages());
		paginationResult.setSize(page.getSize());
		paginationResult.setTotalCount(page.getTotalElements());
		return paginationResult;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public MessageDto saveSurveyReviewByKmIdAndFgId(KmFarmerGroupIdDto kmFarmerGroupIdDto, Long userId)
			throws CustomValidationException {
		return updateSurveyReviewStatus(kmFarmerGroupIdDto, userId, Status.SAVED);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public MessageDto submitSurveyReviewByKmIdAndFgId(KmFarmerGroupIdDto kmFarmerGroupIdDto, Long userId)
			throws CustomValidationException {
		return updateSurveyReviewStatus(kmFarmerGroupIdDto, userId, Status.SUBMTTED);
	}

	private MessageDto updateSurveyReviewStatus(KmFarmerGroupIdDto kmFarmerGroupIdDto, Long userId, Status status)
			throws CustomValidationException {
		AtsourceSurveyReview existingSurveyReview = atSourceSurveyReviewRepository
				.findByKmIdAndFarmerGroupId(kmFarmerGroupIdDto.getKmId(), kmFarmerGroupIdDto.getFarmerGroupId());
		if (null == existingSurveyReview) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2041);
		} else if (existingSurveyReview.getStatus().equals(Status.APPROVED)) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2040);
		} else if (existingSurveyReview.getStatus().equals(Status.SUBMTTED)) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2042);
		}
		existingSurveyReview.setStatus(status);
		if (status.equals(Status.SUBMTTED)) {
			existingSurveyReview.setSubmittedDate(new Date());
		} else if (status.equals(Status.SAVED)) {
			existingSurveyReview.setSavedDate(new Date());
		}
		existingSurveyReview.setUpdatedAt(new Date());
		existingSurveyReview.setUpdatedBy(userId);
		atSourceSurveyReviewRepository.save(existingSurveyReview);
		return new MessageDto(AtSourceConstants.SUCCESS);
	}
	
	/***
	 * 
	 * @param atsourceSurveyReviewDtoList
	 * @throws CustomValidationException 
	 */
	@Override
	public List<AtsourceSurveyReviewDto> categorizeAndSaveAtSourceReviews(
			List<AtsourceSurveyReviewDto> atsourceSurveyReviewDtoList,Long userId,int appId, String token) 
			throws CustomValidationException {
		List<String> kmIds = atsourceSurveyReviewDtoList.stream().map(AtsourceSurveyReviewDto::getKmId)
									.collect(Collectors.toList());
		List<String> trainingPillarIds = trainingPillarRepository.getKmIds(kmIds);
		
		if(!trainingPillarIds.isEmpty()) {
			List<AtsourceSurveyReviewDto> trainingReviewList = atsourceSurveyReviewDtoList.stream()
					.filter(dto ->trainingPillarIds.contains(dto.getKmId())).collect(Collectors.toList());
			
			/* Training Pillar client Call */
			iTrainingPillarClient.saveTrainingPillarSurveyReview(trainingReviewList, appId, token);
			logger.info("No. Of TrainingPillarSurview reviews updated "+trainingReviewList.size());
		}
		
		/* BU Survey service call */
		List<String> BUSurveysList = atSourceSurveyQuestionRepository.getKmIds(kmIds);
		if(!BUSurveysList.isEmpty()) {
			List<AtsourceSurveyResponseDto> surveyReviewList = atsourceSurveyReviewDtoList.stream()
					.filter(dto ->BUSurveysList.contains(dto.getKmId()))
					.map(s -> new AtsourceSurveyResponseDto(s.getFarmerGroupId(),s.getSubmittedModuleId(),s.getStatus()))
					.collect(Collectors.toList());
			 atSourceSurveyAnswerService.saveAtsourceSurveyResponses(surveyReviewList, userId);
			logger.info("No. Of BUSurveySurview reviews updated "+surveyReviewList.size());
		}
		/* Enumerator Survey service call */
		List<String> enSurveyList = kmQuestionmappingRepository.getKmIds(kmIds);
		if(!enSurveyList.isEmpty()) {
			List<AtsourceSurveyReviewDto> esReviewList = atsourceSurveyReviewDtoList.stream()
															.filter(dto ->enSurveyList.contains(dto.getKmId()))
															.collect(Collectors.toList());
			for(AtsourceSurveyReviewDto sr: esReviewList) {
				saveAtsourceSurveyReviewResponses(sr, userId);
			}
			logger.info("No. Of EnumeratorSurview reviews updated "+esReviewList.size());
		}
		return atsourceSurveyReviewDtoList;
	}
	
}
