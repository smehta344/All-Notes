/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */
package com.olam.ofis.atsource.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

public class AtSourceQuestionDto implements Serializable {

	private static final long serialVersionUID = -2266797016614164930L;

	private Integer id;

	private Byte active;

	private Integer appId;

	private String kmCode;

	private Date createdAt;

	private BigInteger createdBy;

	private Integer datatypeId;

	private Byte deletedFlag;

	private String displayConfiguration;

	private String displayType;

	private Byte isSubsetQuestionsRequired;

	private Integer position;

	private String question;

	private String questionEs;

	private String questionFr;

	private String questionId;

	private String questionLo;

	private String questionPt;

	private String questionTh;

	private String questionTr;

	private String questionVi;

	private String storageColumn;

	private String storageModel;

	private Integer submoduleId;

	private Date updatedAt;

	private BigInteger updatedBy;

	private List<AtsourceSurveyLookupvalueDto> lookupValues;

	private String submoduleName;

	private String dataTypeName;

	private Long minValue;

	private Long maxValue;

	private List<Integer> subQuestionIds;

	private AtSourceQuestionMinMaxDto atSourceQuestionMinMaxDto;

	public AtSourceQuestionDto() {
		// default constructor
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Byte getActive() {
		return active;
	}

	public void setActive(Byte active) {
		this.active = active;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public String getKmCode() {
		return kmCode;
	}

	public void setKmCode(String kmCode) {
		this.kmCode = kmCode;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public BigInteger getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(BigInteger createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getDatatypeId() {
		return datatypeId;
	}

	public void setDatatypeId(Integer datatypeId) {
		this.datatypeId = datatypeId;
	}

	public Byte getDeletedFlag() {
		return deletedFlag;
	}

	public void setDeletedFlag(Byte deletedFlag) {
		this.deletedFlag = deletedFlag;
	}

	public String getDisplayConfiguration() {
		return displayConfiguration;
	}

	public void setDisplayConfiguration(String displayConfiguration) {
		this.displayConfiguration = displayConfiguration;
	}

	public String getDisplayType() {
		return displayType;
	}

	public void setDisplayType(String displayType) {
		this.displayType = displayType;
	}

	public Byte getIsSubsetQuestionsRequired() {
		return isSubsetQuestionsRequired;
	}

	public void setIsSubsetQuestionsRequired(Byte isSubsetQuestionsRequired) {
		this.isSubsetQuestionsRequired = isSubsetQuestionsRequired;
	}

	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getQuestionEs() {
		return questionEs;
	}

	public void setQuestionEs(String questionEs) {
		this.questionEs = questionEs;
	}

	public String getQuestionFr() {
		return questionFr;
	}

	public void setQuestionFr(String questionFr) {
		this.questionFr = questionFr;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getQuestionLo() {
		return questionLo;
	}

	public void setQuestionLo(String questionLo) {
		this.questionLo = questionLo;
	}

	public String getQuestionPt() {
		return questionPt;
	}

	public void setQuestionPt(String questionPt) {
		this.questionPt = questionPt;
	}

	public String getQuestionTh() {
		return questionTh;
	}

	public void setQuestionTh(String questionTh) {
		this.questionTh = questionTh;
	}

	public String getQuestionTr() {
		return questionTr;
	}

	public void setQuestionTr(String questionTr) {
		this.questionTr = questionTr;
	}

	public String getQuestionVi() {
		return questionVi;
	}

	public void setQuestionVi(String questionVi) {
		this.questionVi = questionVi;
	}

	public String getStorageColumn() {
		return storageColumn;
	}

	public void setStorageColumn(String storageColumn) {
		this.storageColumn = storageColumn;
	}

	public String getStorageModel() {
		return storageModel;
	}

	public void setStorageModel(String storageModel) {
		this.storageModel = storageModel;
	}

	public Integer getSubmoduleId() {
		return submoduleId;
	}

	public void setSubmoduleId(Integer submoduleId) {
		this.submoduleId = submoduleId;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public BigInteger getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(BigInteger updatedBy) {
		this.updatedBy = updatedBy;
	}

	public List<AtsourceSurveyLookupvalueDto> getLookupValues() {
		return lookupValues;
	}

	public void setLookupValues(List<AtsourceSurveyLookupvalueDto> lookupValues) {
		this.lookupValues = lookupValues;
	}

	public String getSubmoduleName() {
		return submoduleName;
	}

	public void setSubmoduleName(String submoduleName) {
		this.submoduleName = submoduleName;
	}

	public String getDataTypeName() {
		return dataTypeName;
	}

	public void setDataTypeName(String dataTypeName) {
		this.dataTypeName = dataTypeName;
	}

	public Long getMinValue() {
		return minValue;
	}

	public void setMinValue(Long minValue) {
		this.minValue = minValue;
	}

	public Long getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(Long maxValue) {
		this.maxValue = maxValue;
	}

	public List<Integer> getSubQuestionIds() {
		return subQuestionIds;
	}

	public void setSubQuestionIds(List<Integer> subQuestionIds) {
		this.subQuestionIds = subQuestionIds;
	}

	public AtSourceQuestionMinMaxDto getAtSourceQuestionMinMaxDto() {
		return atSourceQuestionMinMaxDto;
	}

	public void setAtSourceQuestionMinMaxDto(AtSourceQuestionMinMaxDto atSourceQuestionMinMaxDto) {
		this.atSourceQuestionMinMaxDto = atSourceQuestionMinMaxDto;
	}

}
