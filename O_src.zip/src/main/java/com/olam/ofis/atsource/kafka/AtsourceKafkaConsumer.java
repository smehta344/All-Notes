/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */

package com.olam.ofis.atsource.kafka;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.olam.ofis.atsource.dto.AtSourceQuestionDto;
import com.olam.ofis.atsource.dto.AtSourceQuestionMinMaxDto;
import com.olam.ofis.atsource.dto.AtsourceAuthRespDTO;
import com.olam.ofis.atsource.dto.AtsourceAuthorizationDTO;
import com.olam.ofis.atsource.dto.AtsourceSurveyReviewDto;
import com.olam.ofis.atsource.model.Status;
import com.olam.ofis.atsource.service.AtSourceQuestionsService;
import com.olam.ofis.atsource.service.AtSourceSurveyReviewService;

@Service
@PropertySource("classpath:application-local.properties")
public class AtsourceKafkaConsumer {

	static final Logger logger = LoggerFactory.getLogger(AtsourceKafkaConsumer.class);

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private AtSourceQuestionsService atSourceQuestionsService;

	@Autowired
	private AtSourceSurveyReviewService atSourceSurveyReviewService;

	@Value("${ofis-authorization-username}")
	private String ofisAuthUserName;

	@Value("${ofis-authorization-password}")
	private String ofisAuthUserPwd;

	@Value("${ofis-authenticate-url}")
	private String authenticateUrl;

	public static final String APP_ID = "App-Id";

	RestTemplate restTemplate = new RestTemplate();
	HttpHeaders headers = new HttpHeaders();
	JsonParser jsonParser = new JsonParser();

	@KafkaListener(topics = "topic.atsource.dev.ofis", containerFactory = "kafkaListenerContainerFactory")
	public void atSourceSurveyReviewConsumer(String payload) {
		logger.info("Data " + payload + " recieved from the topic");

		// Reading data from payload
		try {
			AtsourceAuthRespDTO authorize = authorizeOfisSystem();
			String token = authorize.getAccessToken();
			Long userId = getUserId(token);
			StringToObject obj = mapper.readValue(payload, StringToObject.class);
			logger.info("Reading data from payload " + obj);
			if (obj.getReferenceKey().equalsIgnoreCase("km_update")) {
				AtSourceQuestionDto atSourceQuestionDto = new AtSourceQuestionDto();
				AtSourceQuestionMinMaxDto atSourceQuestionMinMaxDto = null;

				JsonElement jsonElement = (JsonElement) jsonParser.parse(obj.getData());
				JsonObject jsonObject = jsonElement.getAsJsonObject();

				atSourceQuestionMinMaxDto = new AtSourceQuestionMinMaxDto();

				if (null != jsonObject.get("kmCode")) {
					atSourceQuestionMinMaxDto.setKmCode(jsonObject.get("kmCode").getAsString());
				}
				if (null != jsonObject.get("maxValue")) {
					atSourceQuestionMinMaxDto.setMinValue(((JsonElement) jsonObject.get("maxValue")).getAsLong());
				}
				if (null != jsonObject.get("minValue")) {
					atSourceQuestionMinMaxDto.setMaxValue(((JsonElement) jsonObject.get("minValue")).getAsLong());
				}

				if (null != atSourceQuestionMinMaxDto) {
					atSourceQuestionDto.setAtSourceQuestionMinMaxDto(atSourceQuestionMinMaxDto);
					atSourceQuestionsService.updateQuestionMinMaxValues(userId, atSourceQuestionDto);
					logger.info("Data " + atSourceQuestionMinMaxDto + " updated");
				}

			} else if (obj.getReferenceKey().equalsIgnoreCase("approve_reject")) {
				List<AtsourceSurveyReviewDto> atsourceSurveyReviewDtos = new ArrayList<>();
				AtsourceSurveyReviewDto atsourceSurveyReviewDto = null;

				JsonElement jsonElement = (JsonElement) jsonParser.parse(obj.getData());
				JsonArray asJsonArray = jsonElement.getAsJsonArray();

				for (JsonElement jsonElements : asJsonArray) {
					JsonObject jsonObject = jsonElements.getAsJsonObject();
					atsourceSurveyReviewDto = new AtsourceSurveyReviewDto();
					if (null != jsonObject.get("id")) {
						atsourceSurveyReviewDto.setId(jsonObject.get("id").getAsLong());
					}
					if (null != jsonObject.get("kmId")) {
						atsourceSurveyReviewDto.setKmId(jsonObject.get("kmId").getAsString());
					}
					if (null != jsonObject.get("farmerGroupId")) {
						atsourceSurveyReviewDto.setFarmerGroupId(jsonObject.get("farmerGroupId").getAsInt());
					}
					if (null != jsonObject.get("status")) {
						String asString = jsonObject.get("status").getAsString();
						int value = Integer.parseInt(asString);
						Status status = Status.fromCode(value);
						atsourceSurveyReviewDto.setStatus(status);
					}

					if (null != jsonObject.get("versionNumber")) {
						atsourceSurveyReviewDto.setVersionNumber(jsonObject.get("versionNumber").getAsInt());
					}
					Date date = new Date();
					if (null != date) {
						atsourceSurveyReviewDto.setUpdatedAt(date);
					}
					if (null != jsonObject.get("createdBy")) {
						atsourceSurveyReviewDto.setCreatedBy(jsonObject.get("createdBy").getAsLong());
					}
					if (null != jsonObject.get("updatedBy")) {
						atsourceSurveyReviewDto.setUpdatedBy(jsonObject.get("updatedBy").getAsLong());
					}

					if (null != jsonObject.get("submittedModuleId")) {
						atsourceSurveyReviewDto.setSubmittedModuleId(jsonObject.get("submittedModuleId").getAsInt());
					}
					atsourceSurveyReviewDtos.add(atsourceSurveyReviewDto);
				}
				if (null != atsourceSurveyReviewDtos) {
					atSourceSurveyReviewService.categorizeAndSaveAtSourceReviews(atsourceSurveyReviewDtos, userId, 1,
							token);
					logger.info("Data " + atsourceSurveyReviewDtos + " updated");
				}
			}
		} catch (Exception e) {
			logger.debug(String.format("Exception occurred in while parsing json data. %s", e.getMessage()));
		}
	}

	public AtsourceAuthRespDTO authorizeOfisSystem() throws Exception {
		AtsourceAuthorizationDTO atsourceAuthorizationDTO = new AtsourceAuthorizationDTO();

		atsourceAuthorizationDTO.setUserName(ofisAuthUserName);
		atsourceAuthorizationDTO.setPassword(ofisAuthUserPwd);
		atsourceAuthorizationDTO.setUserDetailsRequired(true);
		atsourceAuthorizationDTO.setLanguage("en");

		HttpComponentsClientHttpRequestFactory requestFactory = getRequestFactory();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(APP_ID, "1");

		HttpEntity<AtsourceAuthorizationDTO> httpEntityObj = new HttpEntity<>(atsourceAuthorizationDTO, headers);
		ResponseEntity<String> response = (new RestTemplate(requestFactory)).exchange(authenticateUrl, HttpMethod.POST,
				httpEntityObj, String.class, new Object[0]);

		try {
			return (AtsourceAuthRespDTO) this.mapper.readValue((String) response.getBody(), AtsourceAuthRespDTO.class);
		} catch (IOException e) {
			logger.error("Error While converting OFIS Authorization object to Atsource system :: {}", e.getMessage());
			return new AtsourceAuthRespDTO();
		}
	}

	private HttpComponentsClientHttpRequestFactory getRequestFactory() {
		TrustStrategy acceptingTrustStrategy = (cert, authType) -> true;
		SSLContext sslContext = null;

		try {
			sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
		} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
			logger.error("Error While getting the request factory ", e);
		}

		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

		Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
				.register("http", new PlainConnectionSocketFactory()).register("https", sslsf).build();

		BasicHttpClientConnectionManager connectionManager = new BasicHttpClientConnectionManager(
				socketFactoryRegistry);

		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslsf)
				.setConnectionManager(connectionManager).build();

		return new HttpComponentsClientHttpRequestFactory(httpClient);
	}

	public Long getUserId(String token) {
		Long userId = 0l;
		if (token != null) {
			DecodedJWT jwt = JWT.decode(token.split(" ")[0]);
			Map<String, Claim> map = jwt.getClaims();
			String userData = map.get("user_name").asString();
			userId = Long.parseLong(userData);
		}
		return userId;
	}
}
