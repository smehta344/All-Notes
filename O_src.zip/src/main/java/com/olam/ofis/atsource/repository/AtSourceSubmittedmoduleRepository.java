/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.olam.ofis.atsource.model.AtsourceSubmittedmodule;

public interface AtSourceSubmittedmoduleRepository extends JpaRepository<AtsourceSubmittedmodule, Integer> {

    /**
     * <p>
     * Used to get current survey by farmer group id.
     *
     * @param farmerGroupId - To get survey by given id
     * @return survey
     */
	@Query("SELECT s FROM AtsourceSubmittedmodule s WHERE s.versionNumber = 0 and s.farmerGroupId = ?1")
    AtsourceSubmittedmodule findCurrentSurveyByFarmerGroupId(Integer farmerGroupId);

    /**
     * <p>
     * Used to get the max version number of given submitted module.
     * @return maximum version number
     */
    @Query("SELECT coalesce(max(versionNumber),0) FROM AtsourceSubmittedmodule WHERE farmerGroupId = ?1")
    Integer findMaxVersionNumberById(Integer farmerGroupId);
}
