/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.service.impl;

import java.lang.reflect.Type;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.expression.ParseException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.olam.ofis.atsource.dto.AtSourceQuestionDto;
import com.olam.ofis.atsource.dto.AtSourceSurveyAnswerDto;
import com.olam.ofis.atsource.dto.AtsourceModuleAssignmentDto;
import com.olam.ofis.atsource.dto.AtsourceSubmittedmoduleDto;
import com.olam.ofis.atsource.dto.AtsourceSurveyLookupvalueDto;
import com.olam.ofis.atsource.dto.AtsourceSurveyResponseDto;
import com.olam.ofis.atsource.dto.FarmerGroupDto;
import com.olam.ofis.atsource.dto.FarmerGroupResult;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.ModuleDto;
import com.olam.ofis.atsource.dto.SubModuleResullt;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.exception.ErrorCode;
import com.olam.ofis.atsource.model.AtSourceSurveyAnswer;
import com.olam.ofis.atsource.model.AtsourceModuleAssignment;
import com.olam.ofis.atsource.model.AtsourceSubmittedmodule;
import com.olam.ofis.atsource.model.AtsourceSurveylookupvalue;
import com.olam.ofis.atsource.model.AtsourceSurveyquestion;
import com.olam.ofis.atsource.model.Country;
import com.olam.ofis.atsource.model.FarmerGroup;
import com.olam.ofis.atsource.model.Module;
import com.olam.ofis.atsource.model.Partner;
import com.olam.ofis.atsource.model.Product;
import com.olam.ofis.atsource.model.Status;
import com.olam.ofis.atsource.repository.AtSourceLookUpValueRepository;
import com.olam.ofis.atsource.repository.AtSourceSubmittedmoduleRepository;
import com.olam.ofis.atsource.repository.AtSourceSurveyAnswerRepository;
import com.olam.ofis.atsource.repository.AtSourceSurveyQuestionRepository;
import com.olam.ofis.atsource.repository.AtsourceModuleAssignmentRepository;
import com.olam.ofis.atsource.repository.CountryRepository;
import com.olam.ofis.atsource.repository.DistrictRepository;
import com.olam.ofis.atsource.repository.FarmerGroupRepository;
import com.olam.ofis.atsource.repository.ModuleRepository;
import com.olam.ofis.atsource.repository.PartnerRepository;
import com.olam.ofis.atsource.repository.PlaceRepository;
import com.olam.ofis.atsource.repository.ProductRepository;
import com.olam.ofis.atsource.repository.RegionRepository;
import com.olam.ofis.atsource.repository.SectionRepository;
import com.olam.ofis.atsource.repository.SubModuleRepository;
import com.olam.ofis.atsource.repository.UserRepository;
import com.olam.ofis.atsource.service.AtSourceQuestionsService;
import com.olam.ofis.atsource.service.AtSourceSurveyAnswerService;
import com.olam.ofis.atsource.util.AtSourceConstants;
import com.olam.ofis.atsource.util.CommonConstants;
import com.olam.ofis.atsource.util.CommonUtil;
import com.olam.ofis.atsource.util.PaginationResult;

@Service
public class AtSourceSurveyAnswerServiceImpl implements AtSourceSurveyAnswerService {

	private static final Logger logger = LoggerFactory.getLogger(AtSourceSurveyAnswerServiceImpl.class);

	@Autowired
	private AtSourceSurveyAnswerRepository atSourceSurveyAnswerRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private AtSourceSurveyQuestionRepository atSourceSurveyQuestionRepository;

	@Autowired
	private AtSourceLookUpValueRepository atSourceLookUpValueRepository;

	@Autowired
	private AtsourceModuleAssignmentRepository atsourceModuleAssignmentRepository;

	@Autowired
	private FarmerGroupRepository farmerGroupRepository;

	@Autowired
	private SectionRepository sectionRepository;

	@Autowired
	private RegionRepository regionRepository;

	@Autowired
	private PlaceRepository placeRepository;

	@Autowired
	private DistrictRepository districtRepository;

	@Autowired
	private AtSourceSubmittedmoduleRepository atSourceSubmittedmoduleRepository;

	@Autowired
	private SubModuleRepository subModuleRepository;

	@Autowired
	private AtSourceQuestionsService atSourceQuestionsService;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private PartnerRepository partnerRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ModuleRepository moduleRepository;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<AtSourceSurveyAnswerDto> findAll() {
		logger.debug("Get all atsource survey answers");
		List<AtSourceSurveyAnswer> atSourceSurveyAnswers = atSourceSurveyAnswerRepo.findAll();
		return atSourceSurveyAnswers.stream().map(this::convertToDto).collect(Collectors.toList());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public AtSourceSurveyAnswerDto findById(Long id) throws CustomValidationException {
		logger.debug("Get atsource survey answers by id");
		Optional<AtSourceSurveyAnswer> surverAnswer = atSourceSurveyAnswerRepo.findById(id.intValue());
		if (!surverAnswer.isPresent()) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2003);
		}
		return convertToDto(surverAnswer.get());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<AtSourceSurveyAnswerDto> getSurveyAnswersByFarmerGroupId(Integer farmerGroupId)
			throws CustomValidationException {
		logger.debug("Get atsource survey answers by id");
		List<AtSourceSurveyAnswer> atSourceSurveyAnswers = atSourceSurveyAnswerRepo.findByFarmerGroupId(farmerGroupId);
		return atSourceSurveyAnswers.stream().map(this :: convertToDto).collect(Collectors.toList());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@Transactional
	public AtsourceSubmittedmoduleDto createAnswer(AtsourceSubmittedmoduleDto atsourceSubmittedmoduleDto, Long userId)
			throws CustomValidationException {
		if (CommonUtil.isNull(atsourceSubmittedmoduleDto.getSurveyAnswers())) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2024);
		}
		AtsourceSubmittedmodule existingSubmittedmodule = atSourceSubmittedmoduleRepository
				.findCurrentSurveyByFarmerGroupId(atsourceSubmittedmoduleDto.getFarmerGroupId());
		if (existingSubmittedmodule!=null) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2027);
		}
		AtsourceSubmittedmodule atsourceSubmittedmodule = modelMapper.map(atsourceSubmittedmoduleDto,
				AtsourceSubmittedmodule.class);
		atsourceSubmittedmodule.setCreatedBy(BigInteger.valueOf(userId));
		atsourceSubmittedmodule.setCreatedAt(new Date());
		atsourceSubmittedmodule.setUpdatedBy(BigInteger.valueOf(userId));
		atsourceSubmittedmodule.setUpdatedAt(new Date());
		if (Status.SUBMTTED.equals(atsourceSubmittedmodule.getStatus())) {
			atsourceSubmittedmodule.setSubmittedDate(new Date());
		}
		atsourceSubmittedmodule.setStatus(atsourceSubmittedmodule.getStatus());
		atsourceSubmittedmodule.setVersionNumber(0);
		AtsourceSubmittedmodule submittedModule = atSourceSubmittedmoduleRepository.save(atsourceSubmittedmodule);
		for (AtSourceSurveyAnswerDto surveyAnswerDto : atsourceSubmittedmoduleDto.getSurveyAnswers()) {
			createOrUpdateSurveyAnswer(surveyAnswerDto, submittedModule, userId);
		}
		List<AtSourceSurveyAnswer> surveyAnswers = atSourceSurveyAnswerRepo
				.findBySubmittedmoduleId(submittedModule.getId());
		List<AtSourceSurveyAnswerDto> surveyAnswerDtos = surveyAnswers.stream().map(this::convertToDto)
				.collect(Collectors.toList());
		AtsourceSubmittedmoduleDto submittedmoduleDto = modelMapper.map(submittedModule,
				AtsourceSubmittedmoduleDto.class);
		submittedmoduleDto.setSurveyAnswers(surveyAnswerDtos);
		return submittedmoduleDto;
	}

	private void createOrUpdateSurveyAnswer(AtSourceSurveyAnswerDto surveyAnswerDto,
			AtsourceSubmittedmodule submittedModule, Long userId) throws CustomValidationException {
		AtsourceSurveyquestion atsourceSurveyquestion = atSourceSurveyQuestionRepository
				.findById(surveyAnswerDto.getQuestionId()).orElse(null);
		if (atsourceSurveyquestion == null) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2013);
		}
		if (surveyAnswerDto.getId() == null || surveyAnswerDto.getEdited()) {
			try {
				AtSourceSurveyAnswer atSourceSurveyAnswer = convertToEntity(surveyAnswerDto);
				atSourceSurveyAnswer.setAtsourceSurveyquestion(atsourceSurveyquestion);
				atSourceSurveyAnswer.setSubmittedmoduleId(submittedModule.getId());
				if (atSourceSurveyAnswer.getCreatedBy() != null || surveyAnswerDto.getId() == null) {
					atSourceSurveyAnswer.setCreatedBy(userId.toString());
				}
				if (atSourceSurveyAnswer.getCreatedAt() != null || surveyAnswerDto.getId() == null) {
					atSourceSurveyAnswer.setCreatedAt(new Timestamp(System.currentTimeMillis()));
				}
				atSourceSurveyAnswer.setUpdatedBy(userId.toString());
				atSourceSurveyAnswer.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
				atSourceSurveyAnswerRepo.save(atSourceSurveyAnswer);
			} catch (Exception e) {
				throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2022, e);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@Transactional
	public AtsourceSubmittedmoduleDto updateAnswer(Long id, AtsourceSubmittedmoduleDto atsourceSubmittedmoduleDto,
			Long userId) throws CustomValidationException {
		if (atsourceSubmittedmoduleDto.getId() == null) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2020);
		}
		if (atsourceSubmittedmoduleDto.getId().longValue() != id) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2004);
		}
		AtsourceSubmittedmodule existingSubmittedmodule = atSourceSubmittedmoduleRepository
				.findById(atsourceSubmittedmoduleDto.getId()).orElse(null);
		if (existingSubmittedmodule == null) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2025);
		}
		if (Status.SUBMTTED.equals(existingSubmittedmodule.getStatus())) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2026);
		}
		AtsourceSubmittedmodule atsourceSubmittedmodule = modelMapper.map(atsourceSubmittedmoduleDto,
				AtsourceSubmittedmodule.class);
		for (AtSourceSurveyAnswerDto surveyAnswerDto : atsourceSubmittedmoduleDto.getSurveyAnswers()) {
			createOrUpdateSurveyAnswer(surveyAnswerDto, atsourceSubmittedmodule, userId);
		}
		atsourceSubmittedmodule.setUpdatedBy(BigInteger.valueOf(userId));
		atsourceSubmittedmodule.setUpdatedAt(new Date());
		atsourceSubmittedmodule.setStatus(atsourceSubmittedmodule.getStatus());
		atsourceSubmittedmodule.setVersionNumber(0);
		if (Status.SUBMTTED.equals(atsourceSubmittedmodule.getStatus())) {
			atsourceSubmittedmodule.setSubmittedDate(new Date());
		}
		AtsourceSubmittedmodule submittedModule = atSourceSubmittedmoduleRepository.save(atsourceSubmittedmodule);
		List<AtSourceSurveyAnswer> surveyAnswers = atSourceSurveyAnswerRepo
				.findBySubmittedmoduleId(submittedModule.getId());
		List<AtSourceSurveyAnswerDto> surveyAnswerDtos = surveyAnswers.stream().map(this::convertToDto)
				.collect(Collectors.toList());
		AtsourceSubmittedmoduleDto submittedmoduleDto = modelMapper.map(submittedModule,
				AtsourceSubmittedmoduleDto.class);
		submittedmoduleDto.setSurveyAnswers(surveyAnswerDtos);
		return submittedmoduleDto;
	}

	@Override
	public PaginationResult<AtSourceSurveyAnswerDto> getPaginatedSurveyAnswers(Integer pageNo, Integer size,
			String orderBy, String direction) {
		Sort sort = direction.equalsIgnoreCase(CommonConstants.STRING_DESC) ? Sort.by(orderBy).descending()
				: Sort.by(orderBy).ascending();
		Pageable pageable = PageRequest.of(pageNo - 1, size, sort);
		Page<AtSourceSurveyAnswer> pageResult = atSourceSurveyAnswerRepo.findAll(pageable);
		return convertPageToPaginationResult(pageResult);
	}

	/**
	 * <p>
	 * Used to convert entity to DTO.
	 * </p>
	 * 
	 * @param surveyAnswer
	 * @return surveyDto
	 */
	private AtSourceSurveyAnswerDto convertToDto(AtSourceSurveyAnswer surveyAnswer) {
		return modelMapper.map(surveyAnswer, AtSourceSurveyAnswerDto.class);
	}

	/**
	 * <p>
	 * Used to convert Dto to entity.
	 * </p>
	 * 
	 * @param surveyDto - surveyDto
	 * @return surveyEntity
	 * @throws ParseException
	 */
	private AtSourceSurveyAnswer convertToEntity(AtSourceSurveyAnswerDto surveyDto) {
		return modelMapper.map(surveyDto, AtSourceSurveyAnswer.class);
	}

	/**
	 * <p>
	 * Used to convert page entity to paginationResult Dto.
	 * </p>
	 * 
	 * @param pageResult - pageEntityList
	 * @return paginatedSurveyDtoList
	 */
	private PaginationResult<AtSourceSurveyAnswerDto> convertPageToPaginationResult(
			Page<AtSourceSurveyAnswer> pageResult) {
		PaginationResult<AtSourceSurveyAnswerDto> paginationResult = new PaginationResult<>();
		paginationResult
				.setContent(pageResult.getContent().stream().map(this::convertToDto).collect(Collectors.toList()));
		paginationResult.setSize(pageResult.getSize());
		paginationResult.setTotalPages(pageResult.getTotalPages());
		paginationResult.setPageNumber(pageResult.getPageable().getPageNumber() + 1);
		paginationResult.setTotalCount(pageResult.getTotalElements());
		return paginationResult;
	}

	@Override
	public ModuleDto getFarmerGroups(Long userId) throws CustomValidationException {
		List<FarmerGroup> farmerGroupList = new ArrayList<>();
		List<FarmerGroupDto> farmerGroupDtoList;
		List<AtsourceModuleAssignmentDto> moduleAssignmentDtoList = getActiveModuleAssignments();
		ModuleDto moduleDto = new ModuleDto();
		Optional<AtsourceModuleAssignmentDto> moduleAssignmentDto = moduleAssignmentDtoList.stream().findFirst();
		if (moduleAssignmentDto.isPresent()) {
			String moduleAssignmentType = moduleAssignmentDto.get().getModuleAssignmentType();
			farmerGroupList = getFarmerGroupsList(moduleAssignmentType, moduleAssignmentDtoList, userId);
			getModuleDetails(moduleDto, moduleAssignmentDto.get().getModuleId());
		}
		if (CommonUtil.isNotNull(farmerGroupList)) {
			Type listType = new TypeToken<List<FarmerGroupDto>>() {
			}.getType();
			farmerGroupDtoList = modelMapper.map(farmerGroupList, listType);
			moduleDto.setFarmerGroupDtoList(farmerGroupDtoList);
		}
		return moduleDto;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void getModuleDetails(ModuleDto moduleDto, Integer moduleId) {
		List<SubModuleResullt> subModuleResulltList = subModuleRepository.getModuleDetails(moduleId);
		if (null != subModuleResulltList && !subModuleResulltList.isEmpty()) {
			moduleDto.setModuleId(subModuleResulltList.get(0).getModule().getId());
			moduleDto.setModuleName(subModuleResulltList.get(0).getModule().getName());
			List subModuleList = subModuleResulltList.stream().map(SubModuleResullt::getSubmodule)
					.collect(Collectors.toList());
			moduleDto.setSubModuleDtoList(subModuleList);
		}
	}

	private List<FarmerGroup> getFarmerGroupsList(String moduleAssignmentType,
			List<AtsourceModuleAssignmentDto> moduleAssignmentDtoList, Long userId) throws CustomValidationException {
		List<FarmerGroup> farmerGroupList;
		List<Long> moduleAssignmentIds = moduleAssignmentDtoList.stream()
				.map(moduleAssignmentDto -> Long.valueOf(moduleAssignmentDto.getModuleAssignmentId()))
				.collect(Collectors.toList());
		switch (moduleAssignmentType) {
		case AtSourceConstants.COUNTRY:
			farmerGroupList = farmerGroupRepository.getFarmerGroupsByCountryIds(moduleAssignmentIds);
			break;
		case AtSourceConstants.FARMER_GROUP:
			farmerGroupList = farmerGroupRepository.getFarmerGroupsById(moduleAssignmentIds);
			break;
		case AtSourceConstants.FARMERGROUP:
			farmerGroupList = farmerGroupRepository.getFarmerGroupsById(moduleAssignmentIds);
			break;
		case AtSourceConstants.PRODUCT:
			farmerGroupList = farmerGroupRepository.getFarmerGroupsByProductIds(moduleAssignmentIds);
			break;
		case AtSourceConstants.PARTNER:
			farmerGroupList = farmerGroupRepository.getFarmerGroupsByPartnerIds(moduleAssignmentIds);
			break;
		case AtSourceConstants.PROGRAMME:
			farmerGroupList = farmerGroupRepository.getFarmerGroupsByProgrammeIds(moduleAssignmentIds);
			break;
		case AtSourceConstants.SECTION:
			farmerGroupList = convertResultToFarmerGroup(
					sectionRepository.getFarmerGroupsBySectionIds(moduleAssignmentIds));
			break;
		case AtSourceConstants.REGION:
			farmerGroupList = convertResultToFarmerGroup(
					regionRepository.getFarmerGroupsByRegionIds(moduleAssignmentIds));
			break;
		case AtSourceConstants.PLACE:
			farmerGroupList = convertResultToFarmerGroup(
					placeRepository.getFarmerGroupsByPlaceIds(moduleAssignmentIds));
			break;
		case AtSourceConstants.DISTRICT:
			farmerGroupList = convertResultToFarmerGroup(
					districtRepository.getFarmerGroupsByDistrictIds(moduleAssignmentIds));
			break;
		default:
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2017);
		}
		List<FarmerGroup> dataVisibilityFgList = getFgByDataVisibility(userId);
		if (null != dataVisibilityFgList) {
			farmerGroupList = farmerGroupList.stream().filter(dataVisibilityFgList::contains)
					.collect(Collectors.toList());
		} else {
			return new ArrayList<>();
		}
		return farmerGroupList;
	}

	public List<FarmerGroup> getFgByDataVisibility(Long userId) {
		String dataVisibilityObject = userRepository.getDataVisibilityObject(userId);
		List<FarmerGroup> farmerGroupList = new ArrayList<>();
		if (dataVisibilityObject.equalsIgnoreCase(AtSourceConstants.COUNTRY)) {
			farmerGroupList = getFgByCountries(userId);
		} else if (dataVisibilityObject.equalsIgnoreCase(AtSourceConstants.PARTNER)) {
			farmerGroupList = getFgByPartner(userId);
		} else if(dataVisibilityObject.equalsIgnoreCase(AtSourceConstants.FARMER_GROUP)) {
			List<Partner> partnerList = partnerRepository.getPartnersByUserId(userId);
			if(!partnerList.isEmpty()) {
				List<Long> partnerIdList = partnerList.stream().map(Partner::getPartnerId).collect(Collectors.toList());
				farmerGroupList.addAll(farmerGroupRepository.getFGIdByPartners(partnerIdList));
			}
			farmerGroupList.addAll(getFgByFarmerGroup(userId));
			return farmerGroupList;
		}
		return farmerGroupList;
	}

	private List<FarmerGroup> getFgByFarmerGroup(Long userId) {
		int farmergroupCount = farmerGroupRepository.findFarmerGroupByUser(userId);
		int partnerCount = partnerRepository.findPartnerByUser(userId);
		if (partnerCount > 0 && farmergroupCount == 0) {
			getFgByPartner(userId);
		} else if (partnerCount == 0 && farmergroupCount > 0) {
			return farmerGroupRepository.getFarmerGroupsByUserId(userId);
		} else if (partnerCount > 0 && farmergroupCount > 0) {
			return farmerGroupRepository.getFarmerGroupsByUserId(userId);
		}
		return new ArrayList<>();
	}

	private List<FarmerGroup> getFgByPartner(Long userId) {
		List<Long> partnerIdList;
		List<Partner> partnerList = partnerRepository.getPartnersByUserId(userId);
		if (partnerList.isEmpty()) {
			partnerList = partnerRepository.findAllActivePartner();
		}
		partnerIdList = partnerList.stream().map(Partner::getPartnerId).collect(Collectors.toList());
		return farmerGroupRepository.getFGIdByPartners(partnerIdList);
	}

	private List<FarmerGroup> getFgByCountries(Long userId) {
		List<Long> countryIdList;
		List<Long> productIdList;
		List<Product> products = productRepository.getProductsByUserId(userId);
		List<Country> countryList = countryRepository.getCountriesByUserId(userId);
		if (countryList.isEmpty()) {
			countryList = countryRepository.findCountryByActiveTrue();
		}
		countryIdList = countryList.stream().map(Country::getCountryId).collect(Collectors.toList());
		productIdList = products.stream().map(Product::getProductId).collect(Collectors.toList());
		return farmerGroupRepository.getFGByCountriesAndProducts(countryIdList, productIdList);
	}

	private List<AtsourceModuleAssignmentDto> getActiveModuleAssignments() {
		List<AtsourceModuleAssignment> atSourceModuleAssignmentList = atsourceModuleAssignmentRepository
				.findByActive(true);
		return atSourceModuleAssignmentList.stream().map(AtsourceModuleAssignmentDto::convertModelToDto)
				.collect(Collectors.toList());
	}

	@Override
	public List<AtSourceQuestionDto> getAtSourceSurveyQuestions() throws CustomValidationException {
		List<AtSourceQuestionDto> atSourceQuestionDtos = new ArrayList<>();
		List<AtsourceModuleAssignmentDto> moduleAssignmentDtoList = getActiveModuleAssignments();
		if (CommonUtil.isNotNull(moduleAssignmentDtoList)) {
			Optional<Module> module = moduleRepository.findById(moduleAssignmentDtoList.get(0).getModuleId());
			if (module.isPresent() && module.get().getActive()) {
				List<AtsourceSurveyquestion> surveyQuestions = atSourceQuestionsService.getAtSourceQuestions();
				atSourceQuestionDtos = convertModelToDto(surveyQuestions);
				atSourceQuestionDtos.forEach(atSourceQuestionDto -> {
					if (atSourceQuestionDto.getDisplayType()
							.equalsIgnoreCase(AtSourceConstants.PARENT_QUESTION_REPEATER)) {
						List<AtsourceSurveyquestion> subQuestionList = atSourceSurveyQuestionRepository
								.findSubQuestionsByParentId(AtSourceConstants.PARENT_QUESTION_REPEATER_ID
										+ atSourceQuestionDto.getId() + ",%");
						if (!subQuestionList.isEmpty()) {
							List<Integer> subQuestionIds = subQuestionList.stream().map(AtsourceSurveyquestion::getId)
									.collect(Collectors.toList());
							atSourceQuestionDto.setSubQuestionIds(subQuestionIds);
						}
					}
				});
			}
		}
		return atSourceQuestionDtos;
	}

	/**
	 * <p>
	 * Convert model to dto with fill related lookup values.
	 * </p>
	 * 
	 * @param surveyQuestions - survey Questions
	 * @return questions
	 */
	private List<AtSourceQuestionDto> convertModelToDto(List<AtsourceSurveyquestion> surveyQuestions) {
		List<AtSourceQuestionDto> questions = surveyQuestions.stream().map(this::convertToDto)
				.collect(Collectors.toList());
		List<AtsourceSurveylookupvalue> allLookupValues = atSourceLookUpValueRepository.findByActive();
		questions.forEach(question -> {
			List<AtsourceSurveylookupvalue> lookupValues = allLookupValues.stream()
					.filter(l -> question.getId().intValue() == l.getQuestion().getId()).collect(Collectors.toList());
			if (null != lookupValues && !lookupValues.isEmpty()) {
				List<AtsourceSurveyLookupvalueDto> lookupvalueDtos = lookupValues.stream().map(this::convertToDto)
						.collect(Collectors.toList());
				question.setLookupValues(lookupvalueDtos);
			}
		});
		return questions;
	}

	/**
	 * <p>
	 * Convert model to dto.
	 * </p>
	 * 
	 * @param atsourceSurveyquestion
	 * @return
	 */
	private AtSourceQuestionDto convertToDto(AtsourceSurveyquestion atsourceSurveyquestion) {
		return modelMapper.map(atsourceSurveyquestion, AtSourceQuestionDto.class);
	}

	/**
	 * <p>
	 * Convert model to dto.
	 * </p>
	 * 
	 * @param lookupValue
	 * @return
	 */
	private AtsourceSurveyLookupvalueDto convertToDto(AtsourceSurveylookupvalue lookupValue) {
		return modelMapper.map(lookupValue, AtsourceSurveyLookupvalueDto.class);
	}

	private List<FarmerGroup> convertResultToFarmerGroup(List<FarmerGroupResult> results) {
		FarmerGroup farmerGroup;
		List<FarmerGroup> farmerGroupList = new ArrayList<>();
		for (FarmerGroupResult farmerGroupResult : results) {
			farmerGroup = new FarmerGroup();
			farmerGroup.setName(farmerGroupResult.getName());
			farmerGroup.setFarmerGroupId(farmerGroupResult.getFarmerGroupId());
			farmerGroupList.add(farmerGroup);
		}
		return farmerGroupList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public AtsourceSubmittedmoduleDto findByFarmerGroupId(Long id) throws CustomValidationException {
		
		AtsourceSubmittedmoduleDto submittedmoduleDto = new AtsourceSubmittedmoduleDto();
		AtsourceSubmittedmodule atsourceSubmittedmodule = atSourceSubmittedmoduleRepository
				.findCurrentSurveyByFarmerGroupId(id.intValue());
		if(atsourceSubmittedmodule!=null) {
			if(Status.APPROVED.equals(atsourceSubmittedmodule.getStatus())) {
				submittedmoduleDto.setStatus(Status.APPROVED);
			} else {
				submittedmoduleDto = modelMapper.map(atsourceSubmittedmodule,
						AtsourceSubmittedmoduleDto.class);
				List<AtSourceSurveyAnswer> atSourceSurveyAnswers = atSourceSurveyAnswerRepo
						.findBySubmittedmoduleId(submittedmoduleDto.getId());
				List<AtSourceSurveyAnswerDto> surveyAnswerDtos = new ArrayList<>();
				atSourceSurveyAnswers.stream().forEach(surveyAnswer -> {
					AtSourceSurveyAnswerDto answerDto = modelMapper.map(surveyAnswer, AtSourceSurveyAnswerDto.class);
					answerDto.setQuestionId(surveyAnswer.getAtsourceSurveyquestion().getId());
					surveyAnswerDtos.add(answerDto);
				});
				submittedmoduleDto.setSurveyAnswers(surveyAnswerDtos);
			}		
		}
		return submittedmoduleDto;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public MessageDto saveAtsourceSurveyResponses(List<AtsourceSurveyResponseDto> responses, Long userId)
			throws CustomValidationException {
		MessageDto response = new MessageDto(AtSourceConstants.SUCCESS);
		if (CommonUtil.isNull(responses)) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2031);
		}
		for (AtsourceSurveyResponseDto res : responses) {
			if (res.getFarmerGroupId() == null || res.getFarmerGroupId() == 0 || res.getSubmittedModuleId() == null
					|| res.getSubmittedModuleId() == 0 || res.getStatus() == null) {
				throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2032);
			}
		}
		List<Integer> submittedModuleIds = responses.stream().map(AtsourceSurveyResponseDto::getSubmittedModuleId)
				.collect(Collectors.toList());
		List<AtsourceSubmittedmodule> submittedModules = atSourceSubmittedmoduleRepository
				.findAllById(submittedModuleIds);
		saveAtSourceSubmittedModule(submittedModules, responses, userId);
		return response;
	}
	
	private void saveAtSourceSubmittedModule(List<AtsourceSubmittedmodule> submittedModules, 
										List<AtsourceSurveyResponseDto> responses,Long userId) {
		if (!submittedModules.isEmpty()) {
			for (AtsourceSurveyResponseDto res : responses) {
				submittedModules.forEach(sub -> {
					if (sub.getId().equals(res.getSubmittedModuleId())
							&& sub.getFarmerGroupId().equals(res.getFarmerGroupId())
							&& Status.SUBMTTED.equals(sub.getStatus())) {
						sub.setStatus(res.getStatus());
						sub.setUpdatedBy(BigInteger.valueOf(userId));
						if (Status.APPROVED.equals(sub.getStatus())) {
							Integer versionNum = atSourceSubmittedmoduleRepository
									.findMaxVersionNumberById(res.getFarmerGroupId());
							++versionNum;
							sub.setVersionNumber(versionNum);
							sub.setApprovedDate(new Date());
						} else if (Status.REJECTED.equals(sub.getStatus())) {
							sub.setRejectedDate(new Date());
							sub.setVersionNumber(0);
						}
					}
					sub.setAppId(AtSourceConstants.APPLICATIONTYPE_OFIS);
				});
			}
			atSourceSubmittedmoduleRepository.saveAll(submittedModules);
		}
	}

}
