/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.olam.ofis.atsource.util.AtSourceConstants;

@Entity
@Table(name = "modules", catalog = AtSourceConstants.SURVEY_SCHEMA)
public class Module implements Serializable {

	public Module() {
		// default constructor
	}
	
	private static final long serialVersionUID = -45131108128L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "name")
	private String name;

	@Column(name = "name_fr")
	private String nameFr;

	@Column(name = "name_es")
	private String nameEs;

	@Column(name = "name_id")
	private String nameId;

	@Column(name = "name_pt")
	private String namePt;

	@Column(name = "name_tr")
	private String nameTr;

	@Column(name = "name_lo")
	private String nameLo;

	@Column(name = "name_vi")
	private String nameVi;

	@Column(name = "name_th")
	private String nameTh;

	@Column(name = "expires")
	private Date expires;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "annual_survey")
	private Boolean annualSurvey;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "is_oscmodule")
	private Boolean isOscModule;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "active")
	private Boolean active;

	@Column(name = "created_at")
	private Date createdAt;

	@Column(name = "updated_at")
	private Date updatedAt;

	@Column(name = "app_id")
	private Integer appId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNameFr() {
		return nameFr;
	}

	public void setNameFr(String nameFr) {
		this.nameFr = nameFr;
	}

	public String getNameEs() {
		return nameEs;
	}

	public void setNameEs(String nameEs) {
		this.nameEs = nameEs;
	}

	public String getNameId() {
		return nameId;
	}

	public void setNameId(String nameId) {
		this.nameId = nameId;
	}

	public String getNamePt() {
		return namePt;
	}

	public void setNamePt(String namePt) {
		this.namePt = namePt;
	}

	public String getNameTr() {
		return nameTr;
	}

	public void setNameTr(String nameTr) {
		this.nameTr = nameTr;
	}

	public String getNameLo() {
		return nameLo;
	}

	public void setNameLo(String nameLo) {
		this.nameLo = nameLo;
	}

	public String getNameVi() {
		return nameVi;
	}

	public void setNameVi(String nameVi) {
		this.nameVi = nameVi;
	}

	public String getNameTh() {
		return nameTh;
	}

	public void setNameTh(String nameTh) {
		this.nameTh = nameTh;
	}

	public Date getExpires() {
		return expires;
	}

	public void setExpires(Date expires) {
		this.expires = expires;
	}

	public Boolean getAnnualSurvey() {
		return annualSurvey;
	}

	public void setAnnualSurvey(Boolean annualSurvey) {
		this.annualSurvey = annualSurvey;
	}

	public Boolean getIsOscModule() {
		return isOscModule;
	}

	public void setIsOscModule(Boolean isOscModule) {
		this.isOscModule = isOscModule;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

}
