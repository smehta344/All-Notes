/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * The persistent class for the atsource_surveylookupvalue database table.
 * 
 */
@Entity
@Table(name = "atsource_surveylookupvalue")
public class AtsourceSurveylookupvalue implements Serializable {
	
	public AtsourceSurveylookupvalue() {
		// default constructor
	}
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	private Byte active;

	@Column(name = "app_id")
	private Integer appId;

	private String code;

	@Column(name = "created_at")
	private Date createdAt;

	@Column(name = "created_by")
	private BigInteger createdBy;

	private String photo;

	private Integer position;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="question_id")
	private AtsourceSurveyquestion question;

	@Column(name = "updated_at")
	private Date updatedAt;

	@Column(name = "updated_by")
	private BigInteger updatedBy;

	private String value;

	@Column(name = "value_es")
	private String valueEs;

	@Column(name = "value_fr")
	private String valueFr;

	@Column(name = "value_id")
	private String valueId;

	@Column(name = "value_lo")
	private String valueLo;

	@Column(name = "value_pt")
	private String valuePt;

	@Column(name = "value_th")
	private String valueTh;

	@Column(name = "value_tr")
	private String valueTr;

	@Column(name = "value_vi")
	private String valueVi;

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Byte getActive() {
		return this.active;
	}

	public void setActive(Byte active) {
		this.active = active;
	}

	public Integer getAppId() {
		return this.appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public BigInteger getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(BigInteger createdBy) {
		this.createdBy = createdBy;
	}

	public String getPhoto() {
		return this.photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public Integer getPosition() {
		return this.position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	public AtsourceSurveyquestion getQuestion() {
		return this.question;
	}

	public void setQuestion(AtsourceSurveyquestion question) {
		this.question = question;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public BigInteger getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(BigInteger updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getValueEs() {
		return this.valueEs;
	}

	public void setValueEs(String valueEs) {
		this.valueEs = valueEs;
	}

	public String getValueFr() {
		return this.valueFr;
	}

	public void setValueFr(String valueFr) {
		this.valueFr = valueFr;
	}

	public String getValueId() {
		return this.valueId;
	}

	public void setValueId(String valueId) {
		this.valueId = valueId;
	}

	public String getValueLo() {
		return this.valueLo;
	}

	public void setValueLo(String valueLo) {
		this.valueLo = valueLo;
	}

	public String getValuePt() {
		return this.valuePt;
	}

	public void setValuePt(String valuePt) {
		this.valuePt = valuePt;
	}

	public String getValueTh() {
		return this.valueTh;
	}

	public void setValueTh(String valueTh) {
		this.valueTh = valueTh;
	}

	public String getValueTr() {
		return this.valueTr;
	}

	public void setValueTr(String valueTr) {
		this.valueTr = valueTr;
	}

	public String getValueVi() {
		return this.valueVi;
	}

	public void setValueVi(String valueVi) {
		this.valueVi = valueVi;
	}

}
