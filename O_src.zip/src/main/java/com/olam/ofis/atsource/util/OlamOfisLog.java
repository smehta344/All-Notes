/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.util;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to enable logging at method level.
 * 
 * @AgitLog(args = true, returnValue = true, debug = true, time = false)
 */
@Target({ ElementType.METHOD, ElementType.ANNOTATION_TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface OlamOfisLog {

	public static final int DEFAULT_THRESHOLD = 200;
	
	/**
	 * @return Method description
	 */
	String value() default "";

	/**
	 * @return Should the arguments be logged?
	 */
	boolean args() default true;

	/**
	 * @return Should the time taken be logged?
	 */
	boolean time() default true;

	/**
	 * @return Should the return value be logged?
	 */
	boolean returnValue() default false;

	/**
	 * @return Should the logging be done in debug level?
	 */
	boolean debug() default true;

	/**
	 * @return Threshold time for the method called
	 */
	int threshold() default DEFAULT_THRESHOLD;

}
