/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.dto;

import java.io.Serializable;

import com.olam.ofis.atsource.model.AtsourceModuleAssignment;
import com.olam.ofis.atsource.model.Module;

public class AtsourceModuleAssignmentDto implements Serializable {

	private static final long serialVersionUID = -5703742899483883608L;

	public AtsourceModuleAssignmentDto(){
		//default constructor
	}
	
	private Integer moduleId;

	private String moduleAssignmentId;

	private String moduleAssignmentType;

	private Integer recurrenceFrequency;

	private String recurrenceType;

	private String disabledMonths;

	private Integer appId;

	private Boolean atsource;

	private Boolean active;

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleAssignmentId() {
		return moduleAssignmentId;
	}

	public void setModuleAssignmentId(String moduleAssignmentId) {
		this.moduleAssignmentId = moduleAssignmentId;
	}

	public String getModuleAssignmentType() {
		return moduleAssignmentType;
	}

	public void setModuleAssignmentType(String moduleAssignmentType) {
		this.moduleAssignmentType = moduleAssignmentType;
	}

	public Integer getRecurrenceFrequency() {
		return recurrenceFrequency;
	}

	public void setRecurrenceFrequency(Integer recurrenceFrequency) {
		this.recurrenceFrequency = recurrenceFrequency;
	}

	public String getRecurrenceType() {
		return recurrenceType;
	}

	public void setRecurrenceType(String recurrenceType) {
		this.recurrenceType = recurrenceType;
	}

	public String getDisabledMonths() {
		return disabledMonths;
	}

	public void setDisabledMonths(String disabledMonths) {
		this.disabledMonths = disabledMonths;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public AtsourceModuleAssignment convertDtoToModel(AtsourceModuleAssignmentDto atsourceModuleAssignmentDto) {
		AtsourceModuleAssignment atsourceModuleAssignment = new AtsourceModuleAssignment();

		Module module = new Module();
		module.setId(atsourceModuleAssignmentDto.getModuleId());

		atsourceModuleAssignment.setModuleId(module);
		atsourceModuleAssignment.setModuleAssignmentType(atsourceModuleAssignmentDto.getModuleAssignmentType());
		atsourceModuleAssignment.setRecurrenceFrequency(atsourceModuleAssignmentDto.getRecurrenceFrequency());
		atsourceModuleAssignment.setRecurrenceType(atsourceModuleAssignmentDto.getRecurrenceType());
		atsourceModuleAssignment.setDisabledMonths(atsourceModuleAssignmentDto.getDisabledMonths());
		atsourceModuleAssignment.setAppId(atsourceModuleAssignmentDto.getAppId());
		atsourceModuleAssignment.setActive(atsourceModuleAssignmentDto.getActive());
		return atsourceModuleAssignment;
	}

	public static AtsourceModuleAssignmentDto convertModelToDto(AtsourceModuleAssignment atsourceModuleAssignment) {
		AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
		atsourceModuleAssignmentDto.setModuleId(atsourceModuleAssignment.getModuleId().getId());
		atsourceModuleAssignmentDto.setModuleAssignmentType(atsourceModuleAssignment.getModuleAssignmentType());
		atsourceModuleAssignmentDto
				.setModuleAssignmentId(String.valueOf(atsourceModuleAssignment.getModuleAssignmentId()));
		atsourceModuleAssignmentDto.setRecurrenceFrequency(atsourceModuleAssignment.getRecurrenceFrequency());
		atsourceModuleAssignmentDto.setRecurrenceType(atsourceModuleAssignment.getRecurrenceType());
		atsourceModuleAssignmentDto.setDisabledMonths(atsourceModuleAssignment.getDisabledMonths());
		atsourceModuleAssignmentDto.setAppId(atsourceModuleAssignment.getAppId());
		atsourceModuleAssignmentDto.setActive(atsourceModuleAssignment.getActive());
		return atsourceModuleAssignmentDto;
	}

	public Boolean getAtsource() {
		return atsource;
	}

	public void setAtsource(Boolean atsource) {
		this.atsource = atsource;
	}

	public Boolean getActive() { return active; }

	public void setActive(Boolean active) { this.active = active; }
}
