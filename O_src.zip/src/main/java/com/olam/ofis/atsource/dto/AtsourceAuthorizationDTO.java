package com.olam.ofis.atsource.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AtsourceAuthorizationDTO implements Serializable {

	private static final long serialVersionUID = 6843318554245442082L;
	@JsonProperty("username")
	private String userName;
	@JsonProperty("password")
	private String password;
	@JsonProperty("userDetailsRequired")
	private boolean userDetailsRequired;
	@JsonProperty("language")
	private String language;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isUserDetailsRequired() {
		return userDetailsRequired;
	}

	public void setUserDetailsRequired(boolean userDetailsRequired) {
		this.userDetailsRequired = userDetailsRequired;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AtsourceAuthorizationDTO [userName=");
		builder.append(userName);
		builder.append(", password=");
		builder.append(password);
		builder.append(", userDetailsRequired=");
		builder.append(userDetailsRequired);
		builder.append(", language=");
		builder.append(language);
		builder.append("]");
		return builder.toString();
	}

}
