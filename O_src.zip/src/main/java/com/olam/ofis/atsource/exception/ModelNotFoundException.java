/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.exception;

public class ModelNotFoundException extends Exception {

	private static final long serialVersionUID = 2816438424415940868L;

	private final ErrorCode errorCode;

	public ModelNotFoundException(ErrorCode codes) {
		super(getMessage(codes));
		this.errorCode = codes;
	}

	public ErrorCode getErrorCode() {
		return errorCode;
	}

	private static String getMessage(ErrorCode errorCode) {
		if (errorCode.getMessage() != null) {
			return errorCode.getMessage();
		} else {
			return null;
		}
	}
}
