/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Which is used to configure the swagger in ofis atsource service
 * @author mani.kasi
 *
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {

	public SwaggerConfig() {
		// default constructor
	}
	
	@Value("OLAM")
	private String createdBy;

	@Bean
	public Docket api() {
		List<springfox.documentation.service.Parameter> parameters = new ArrayList<>();
		parameters.add(new ParameterBuilder().name("Authorization").description("Access token")
				.modelRef(new ModelRef("string")).parameterType("header").required(true).build());
		parameters.add(new ParameterBuilder().name("App-Id").description("App Id").modelRef(new ModelRef("string"))
				.parameterType("header").required(true).build());
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.olam.ofis.atsource.controller"))
				.paths(PathSelectors.any()).build().apiInfo(apiInfo()).globalOperationParameters(parameters);
	}

	public ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("Olam OFIS").description("OLAM OFIS AtSource Data System")
				.version("1.0").termsOfServiceUrl(createdBy).build();
	}
}
