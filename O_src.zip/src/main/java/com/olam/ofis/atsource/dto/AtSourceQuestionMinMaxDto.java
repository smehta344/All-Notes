/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.dto;

import java.io.Serializable;

public class AtSourceQuestionMinMaxDto implements Serializable {

	private static final long serialVersionUID = -2266797016614164930L;

	private String kmCode;
	
	private Long minValue;

	private Long maxValue;

	public AtSourceQuestionMinMaxDto() {
		this.kmCode = null;
		this.minValue = null;
		this.maxValue = null;
	}

	public String getKmCode() {
		return kmCode;
	}

	public void setKmCode(String kmCode) {
		this.kmCode = kmCode;
	}

	public Long getMinValue() {
		return minValue;
	}

	public void setMinValue(Long minValue) {
		this.minValue = minValue;
	}

	public Long getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(Long maxValue) {
		this.maxValue = maxValue;
	}
	
	

}
