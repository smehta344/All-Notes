/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.olam.ofis.atsource.util.AtSourceConstants;

@Entity
@Table(schema= AtSourceConstants.MASTER_SCHEMA,name="users",catalog=AtSourceConstants.MASTER_SCHEMA)
public class User implements Serializable {

	public User() {
		// default constructor
	}
	
	private static final long serialVersionUID = 3931952748017802803L;

	@Id
	@Column(name= "id")
	private Long id;
	
	@Column(name= "role_id")
	private int roleId;
	
	@Column(name= "firstname")
	private String firstname;
	
	@Column(name= "lastname")
	private String lastname;
	
	@Column(name= "email")
	private String email;
	
	@Column(name= "remember_token")
	private String rememberToken;
	
	@Column(name= "datavisibilityobject")
	private String datavisibilityobject;
	
	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name="can_download_farmer_data")
	private Boolean canDownloadFarmerData;
	
	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name="can_view_fmp")
	private Boolean canViewFmp;
	
	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name="can_manage_fmp")
	private Boolean canManageFmp;
	
	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name="can_send_messages")
	private Boolean canSendMessages;
	
	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name="can_send_unapproved_messages")
	private Boolean canSendUnapprovedMessages;
	
	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name="can_approve_messages")
	private Boolean canApproveMessages;
	
	@Column(name= "mblox_service_name")
	private String mbloxServiceName;
	
	@Column(name= "mblox_service_key")
	private String mbloxServiceKey;
	
	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name="active")
	private Boolean active;
	
	@Column(name="created_at")
	private Date createdTs;
	
	@Column(name="updated_at")
	private Date updatedTs;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRememberToken() {
		return rememberToken;
	}

	public void setRememberToken(String rememberToken) {
		this.rememberToken = rememberToken;
	}

	public String getDatavisibilityobject() {
		return datavisibilityobject;
	}

	public void setDatavisibilityobject(String datavisibilityobject) {
		this.datavisibilityobject = datavisibilityobject;
	}

	public Boolean getCanDownloadFarmerData() {
		return canDownloadFarmerData;
	}

	public void setCanDownloadFarmerData(Boolean canDownloadFarmerData) {
		this.canDownloadFarmerData = canDownloadFarmerData;
	}

	public Boolean getCanViewFmp() {
		return canViewFmp;
	}

	public void setCanViewFmp(Boolean canViewFmp) {
		this.canViewFmp = canViewFmp;
	}

	public Boolean getCanManageFmp() {
		return canManageFmp;
	}

	public void setCanManageFmp(Boolean canManageFmp) {
		this.canManageFmp = canManageFmp;
	}

	public Boolean getCanSendMessages() {
		return canSendMessages;
	}

	public void setCanSendMessages(Boolean canSendMessages) {
		this.canSendMessages = canSendMessages;
	}

	public Boolean getCanSendUnapprovedMessages() {
		return canSendUnapprovedMessages;
	}

	public void setCanSendUnapprovedMessages(Boolean canSendUnapprovedMessages) {
		this.canSendUnapprovedMessages = canSendUnapprovedMessages;
	}

	public Boolean getCanApproveMessages() {
		return canApproveMessages;
	}

	public void setCanApproveMessages(Boolean canApproveMessages) {
		this.canApproveMessages = canApproveMessages;
	}

	public String getMbloxServiceName() {
		return mbloxServiceName;
	}

	public void setMbloxServiceName(String mbloxServiceName) {
		this.mbloxServiceName = mbloxServiceName;
	}

	public String getMbloxServiceKey() {
		return mbloxServiceKey;
	}

	public void setMbloxServiceKey(String mbloxServiceKey) {
		this.mbloxServiceKey = mbloxServiceKey;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public Date getUpdatedTs() {
		return updatedTs;
	}

	public void setUpdatedTs(Date updatedTs) {
		this.updatedTs = updatedTs;
	}

	
}
