/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.olam.ofis.atsource.dto.SubModuleResullt;
import com.olam.ofis.atsource.model.SubModule;

public interface SubModuleRepository extends JpaRepository<SubModule, Long> {

	@Query("select sm from SubModule sm where sm.moduleId.id = :moduleId")
	List<SubModule> getAllSubmodulesByModuleId(@Param("moduleId") Integer moduleId);

	@Query("SELECT s as submodule, m as module FROM SubModule s "
		+ "join Module m  on s.moduleId.id = m.id where s.moduleId.id = :moduleId group by s.id")
	List<SubModuleResullt> getModuleDetails(@Param("moduleId") Integer moduleId);
}
