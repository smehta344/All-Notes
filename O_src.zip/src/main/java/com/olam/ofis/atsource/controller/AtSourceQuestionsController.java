/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.olam.ofis.atsource.dto.AtSourceQuestionDto;
import com.olam.ofis.atsource.dto.AtSourceQuestionMinMaxDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.SubModuleDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.service.AtSourceQuestionsService;
import com.olam.ofis.atsource.util.CommonUtil;
import com.olam.ofis.atsource.util.PaginationResult;

@RestController
@RequestMapping(path = "/atsource/questions")
public class AtSourceQuestionsController extends BaseController {

	@Autowired
	private AtSourceQuestionsService atSourceQuestionsService;
	
	@Autowired
	HttpServletRequest httpServletRequest;
	
	@Autowired
	ModelMapper modelMapper;

	private static final Logger logger = LoggerFactory.getLogger(AtSourceQuestionsController.class);

	@GetMapping("/getAllAtsourceQuestions")
	public PaginationResult<AtSourceQuestionDto> getAllAtsourceQuestions(
			@RequestParam(name = "pageNo", defaultValue = "1", required = false) Integer pageNo,
			@RequestParam(name = "size", required = false, defaultValue = "50") Integer size,
			@RequestParam(name = "orderBy", required = false, defaultValue = "id") String orderBy,
			@RequestParam(name = "direction", required = false, defaultValue = "asc") String direction) {
		return atSourceQuestionsService.getAllAtsourceQuestions(pageNo, size, orderBy, direction);
	}

	@PostMapping(value = "/save", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<MessageDto> saveQuestion(@RequestBody AtSourceQuestionDto atSourceQuestionDto)
			throws CustomValidationException {
		logger.info("Save AtSourceQuestions started");
		Long userId = getUser().getUserId();
		atSourceQuestionDto.setAppId(CommonUtil.getAppId(httpServletRequest));
		return new ResponseEntity<>(atSourceQuestionsService.saveQuestion(userId, atSourceQuestionDto),
				HttpStatus.CREATED);
	}

	@GetMapping(value = "/edit/{questionId}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AtSourceQuestionDto> getQuestion(@PathVariable("questionId") Integer questionId) {
		logger.info("getQuestionId started");
		return new ResponseEntity<>(atSourceQuestionsService.getQuestionById(questionId), HttpStatus.OK);
	}

	@GetMapping("/getAllAtsourceSubModules")
	public ResponseEntity<List<SubModuleDto>> getAllAtsourceSubModules() throws CustomValidationException {
		logger.info("Get AllSubModules started");
		List<SubModuleDto> subModuleDtoList = atSourceQuestionsService.getAllSubModules();
		logger.info("Get AllSubModules end");
		return new ResponseEntity<>(subModuleDtoList, HttpStatus.OK);
	}

	@PutMapping(value = "/updateMinMaxValues", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<MessageDto> updateQuestionMinMaxValues(
			@RequestBody AtSourceQuestionMinMaxDto atSourceQuestionMinMaxDto)
			throws CustomValidationException {
		logger.info("Update Min Max values started");
		AtSourceQuestionDto atSourceQuestionDto = modelMapper.map(atSourceQuestionMinMaxDto, AtSourceQuestionDto.class); 
		Long userId = getUser().getUserId();
		atSourceQuestionDto.setAppId(CommonUtil.getAppId(httpServletRequest));
		return new ResponseEntity<>(atSourceQuestionsService.updateQuestionMinMaxValues(userId, atSourceQuestionDto),
				HttpStatus.CREATED);
	}
}
