/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.service.impl;

import java.math.BigInteger;
import java.util.Date;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.olam.ofis.atsource.dto.AtsourceQuestionResult;
import com.olam.ofis.atsource.dto.AtsourceSurveyLookupvalueDto;
import com.olam.ofis.atsource.dto.AtsourceSurveyLookupvalueQueryResult;
import com.olam.ofis.atsource.dto.AtsourcelookupValueResult;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.exception.ErrorCode;
import com.olam.ofis.atsource.model.AtsourceSurveylookupvalue;
import com.olam.ofis.atsource.model.AtsourceSurveyquestion;
import com.olam.ofis.atsource.repository.AtSourceLookUpValueRepository;
import com.olam.ofis.atsource.repository.AtSourceSurveyQuestionRepository;
import com.olam.ofis.atsource.service.AtsourceSurveyLookupvalueService;
import com.olam.ofis.atsource.util.AtSourceConstants;
import com.olam.ofis.atsource.util.CommonUtil;
import com.olam.ofis.atsource.util.PaginationResult;

/**
 * Created by Ideas2it-Karthick on 29/3/19.
 */

@Service
public class AtsourceSurveyLookupvalueServiceImpl implements AtsourceSurveyLookupvalueService {

	@Autowired
	ModelMapper modelMapper;
	@Autowired
	private AtSourceLookUpValueRepository atSourceLookUpValueRepository;
	@Autowired
	private AtSourceSurveyQuestionRepository atSourceSurveyQuestionRepository;

	/**
	 * Fetch all active survey lookup values
	 *
	 * @param pageNo
	 * @param size
	 * @param orderBy
	 * @param direction
	 *
	 */
	@Override
	public PaginationResult<AtsourceSurveyLookupvalueDto> getAllLookupValues(Integer pageNo, Integer size,
			String orderBy, String direction) {
		Pageable pageable = CommonUtil.getPageRequest(pageNo, size, orderBy, direction);
		Page<AtsourceSurveyLookupvalueQueryResult> atsourceSurveylookupvalues = atSourceLookUpValueRepository
				.findAllActiveLookupValue(pageable);
		return convertPageToPaginationResult(atsourceSurveylookupvalues);
	}

	/**
	 * Save survey lookup values
	 *
	 * @param userId
	 * @param atsourceSurveyLookupvalueDto
	 *
	 */
	@Override
	public MessageDto saveLookUpValue(Long userId, AtsourceSurveyLookupvalueDto atsourceSurveyLookupvalueDto)
			throws CustomValidationException {
		MessageDto messageDto = new MessageDto();
		try {
			AtsourceSurveylookupvalue saveAtsourceSurveylookupvalue = convertDtoToModel(atsourceSurveyLookupvalueDto);
			setLookUpValues(userId,atsourceSurveyLookupvalueDto, saveAtsourceSurveylookupvalue);
			atSourceLookUpValueRepository.save(saveAtsourceSurveylookupvalue);
			messageDto.setMessage(AtSourceConstants.SUCCESS);
		} catch (Exception e) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2016, e);
		}
		return messageDto;
	}

	private AtsourceSurveylookupvalue convertDtoToModel(AtsourceSurveyLookupvalueDto atsourceSurveyLookupvalueDto) {
		if (CommonUtil.isNotNull(atsourceSurveyLookupvalueDto)) {
			return modelMapper.map(atsourceSurveyLookupvalueDto, AtsourceSurveylookupvalue.class);
		}
		return null;
	}

	private PaginationResult<AtsourceSurveyLookupvalueDto> convertPageToPaginationResult(
			Page<AtsourceSurveyLookupvalueQueryResult> page) {
		PaginationResult<AtsourceSurveyLookupvalueDto> paginationResult = new PaginationResult<>();
		paginationResult.setContent(page.getContent().stream().map(this::convertToDto).collect(Collectors.toList()));
		paginationResult.setSize(page.getSize());
		paginationResult.setTotalPages(page.getTotalPages());
		paginationResult.setPageNumber(page.getPageable().getPageNumber() + 1);
		paginationResult.setTotalCount(page.getTotalElements());
		return paginationResult;
	}

	private AtsourceSurveyLookupvalueDto convertToDto(AtsourceSurveyLookupvalueQueryResult atsourceSurveylookupvalue) {
		AtsourceSurveyLookupvalueDto atsourceSurveyLookupvalueDto = new AtsourceSurveyLookupvalueDto();
		if(null != atsourceSurveylookupvalue.getQuestion() && 
				null != atsourceSurveylookupvalue.getAtsourcelookupValueResult()) {
			AtsourcelookupValueResult atsourcelookupValueResult = atsourceSurveylookupvalue.getAtsourcelookupValueResult();
			AtsourceQuestionResult atsourceQuestionResult = atsourceSurveylookupvalue.getQuestion();
			// set question details
			atsourceSurveyLookupvalueDto.setQuestionId(atsourceQuestionResult.getId());
			atsourceSurveyLookupvalueDto.setQuestionName(atsourceQuestionResult.getQuestion());

			// set lookup value details
			atsourceSurveyLookupvalueDto.setId(atsourcelookupValueResult.getId());
			atsourceSurveyLookupvalueDto.setValue(atsourcelookupValueResult.getValue());
			atsourceSurveyLookupvalueDto.setValueVi(atsourcelookupValueResult.getValueVi());
			atsourceSurveyLookupvalueDto.setValueTr(atsourcelookupValueResult.getValueTr());
			atsourceSurveyLookupvalueDto.setValueTh(atsourcelookupValueResult.getValueTh());
			atsourceSurveyLookupvalueDto.setValuePt(atsourcelookupValueResult.getValuePt());
			atsourceSurveyLookupvalueDto.setValueLo(atsourcelookupValueResult.getValueLo());
			atsourceSurveyLookupvalueDto.setValueId(atsourcelookupValueResult.getValueId());
			atsourceSurveyLookupvalueDto.setValueFr(atsourcelookupValueResult.getValueFr());
			atsourceSurveyLookupvalueDto.setValueEs(atsourcelookupValueResult.getValueEs());
			atsourceSurveyLookupvalueDto.setPosition(atsourcelookupValueResult.getPosition());
			atsourceSurveyLookupvalueDto.setActive(atsourcelookupValueResult.getActive());
		}
		return atsourceSurveyLookupvalueDto;
	}

	private void setLookUpValues(Long userId, AtsourceSurveyLookupvalueDto atsourceSurveyLookupvalueDto,
								 AtsourceSurveylookupvalue saveAtsourceSurveylookupvalue) {
		if (atsourceSurveyLookupvalueDto.getId() == null) {
			saveAtsourceSurveylookupvalue.setCreatedAt(new Date());
			saveAtsourceSurveylookupvalue.setUpdatedAt(new Date());
			saveAtsourceSurveylookupvalue.setCreatedBy(BigInteger.valueOf(userId));
			Optional<AtsourceSurveyquestion> atsourceSurveyquestionsOptional = atSourceSurveyQuestionRepository
					.findById(atsourceSurveyLookupvalueDto.getQuestionId());
			if (atsourceSurveyquestionsOptional.isPresent()) {
				saveAtsourceSurveylookupvalue.setCode(
				CommonUtil.getUniqueRandomCode(atsourceSurveyquestionsOptional.get().getQuestion()));
			}
		} else {
			// Update only updated by and updated time
			Optional<AtsourceSurveylookupvalue> atsourceSurveylookupvalueOptional = atSourceLookUpValueRepository
					.findById(atsourceSurveyLookupvalueDto.getId());
			if (atsourceSurveylookupvalueOptional.isPresent()) {
				AtsourceSurveylookupvalue atsourceSurveylookupvalue = atsourceSurveylookupvalueOptional.get();
				saveAtsourceSurveylookupvalue.setCreatedAt(atsourceSurveylookupvalue.getCreatedAt());
				saveAtsourceSurveylookupvalue.setUpdatedAt(new Date());
				saveAtsourceSurveylookupvalue.setCreatedBy(atsourceSurveylookupvalue.getCreatedBy());
				saveAtsourceSurveylookupvalue.setUpdatedBy(BigInteger.valueOf(userId));
				saveAtsourceSurveylookupvalue.setCode(atsourceSurveylookupvalue.getCode());
			}
		}

		// mandatory check for other languages
		saveAtsourceSurveylookupvalue
		.setValueEs(CommonUtil.isEmpty(atsourceSurveyLookupvalueDto.getValueEs().trim()) ? atsourceSurveyLookupvalueDto.getValue().trim()
				: atsourceSurveyLookupvalueDto.getValueEs().trim());
		saveAtsourceSurveylookupvalue
		.setValueFr(CommonUtil.isEmpty(atsourceSurveyLookupvalueDto.getValueFr().trim()) ? atsourceSurveyLookupvalueDto.getValue().trim()
				: atsourceSurveyLookupvalueDto.getValueFr().trim());
		saveAtsourceSurveylookupvalue
		.setValueId(CommonUtil.isEmpty(atsourceSurveyLookupvalueDto.getValueId().trim()) ? atsourceSurveyLookupvalueDto.getValue().trim()
				: atsourceSurveyLookupvalueDto.getValueId().trim());
		saveAtsourceSurveylookupvalue
		.setValueLo(CommonUtil.isEmpty(atsourceSurveyLookupvalueDto.getValueLo().trim()) ? atsourceSurveyLookupvalueDto.getValue().trim()
				: atsourceSurveyLookupvalueDto.getValueLo().trim());
		saveAtsourceSurveylookupvalue
		.setValuePt(CommonUtil.isEmpty(atsourceSurveyLookupvalueDto.getValuePt().trim()) ? atsourceSurveyLookupvalueDto.getValue().trim()
				: atsourceSurveyLookupvalueDto.getValuePt().trim());
		saveAtsourceSurveylookupvalue
		.setValueTh(CommonUtil.isEmpty(atsourceSurveyLookupvalueDto.getValueTh().trim()) ? atsourceSurveyLookupvalueDto.getValue().trim()
				: atsourceSurveyLookupvalueDto.getValueTh().trim());
		saveAtsourceSurveylookupvalue
		.setValueTr(CommonUtil.isEmpty(atsourceSurveyLookupvalueDto.getValueTr().trim()) ? atsourceSurveyLookupvalueDto.getValue().trim()
				: atsourceSurveyLookupvalueDto.getValueTr().trim());
		saveAtsourceSurveylookupvalue
		.setValueVi(CommonUtil.isEmpty(atsourceSurveyLookupvalueDto.getValueVi().trim()) ? atsourceSurveyLookupvalueDto.getValue().trim()
				: atsourceSurveyLookupvalueDto.getValueVi().trim());

	}

	/**
	 * Fetch lookup value by id
	 * 
	 * @param lookupValueId
	 */
	@Override
	public AtsourceSurveyLookupvalueDto getLookUpValueById(Integer lookupValueId) {
		AtsourceSurveyLookupvalueDto atsourceSurveyLookupvalueDto = new AtsourceSurveyLookupvalueDto();
		AtsourceSurveylookupvalue atsourceSurveylookupvalue = atSourceLookUpValueRepository
				.getLookUpValueById(lookupValueId);
		if (CommonUtil.isNotNull(atsourceSurveylookupvalue)) {
			atsourceSurveyLookupvalueDto = modelMapper.map(atsourceSurveylookupvalue, AtsourceSurveyLookupvalueDto.class);
		}
		return atsourceSurveyLookupvalueDto;
	}
}
