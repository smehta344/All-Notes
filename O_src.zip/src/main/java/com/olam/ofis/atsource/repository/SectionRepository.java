/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.olam.ofis.atsource.dto.FarmerGroupResult;
import com.olam.ofis.atsource.model.Section;

public interface SectionRepository extends JpaRepository<Section, Long> {

	@Query("SELECT f.farmerGroupId as farmerGroupId,f.name as name FROM Section sec join FarmerGroup f "
			+ "on sec.farmerGroupId = f.farmerGroupId where sec.sectionId IN :moduleAssignmentIds "
			+ "group by f.farmerGroupId")
	List<FarmerGroupResult> getFarmerGroupsBySectionIds(@Param("moduleAssignmentIds") List<Long> moduleAssignmentIds);

}
