/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.util;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.olam.ofis.atsource.dto.UserDTO;

@Component
public class RetrieveUserData {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public UserDTO getUserData(HttpServletRequest request) {
		logger.debug(request.getHeader(CommonConstants.AUTHORIZATION));
		if (request.getHeader(CommonConstants.AUTHORIZATION) != null
				&& request.getHeader(CommonConstants.AUTHORIZATION).split(" ")[1] != null) {
			DecodedJWT jwt = JWT.decode(request.getHeader(CommonConstants.AUTHORIZATION).split(" ")[1]);
			Map<String, Claim> map = jwt.getClaims();
			String languageISOCode = map.get("language_iso_code").asString();
			String userData = map.get("user_name").asString();
			String clientId = map.get("client_id").asString();

			UserDTO user = new UserDTO();
			user.setUserId(Long.parseLong(userData));
			user.setUserName(userData);
			if (CommonConstants.TT_MOBILE_CLIENT.equals(clientId)) {
				int index = userData.lastIndexOf(CommonConstants.TT_MOBILE_SFX);
				if (index > 0) {
					user.setUserName(userData.substring(0, index));
				}
			}
			user.setApplicationId(Long.valueOf(clientId));
			user.setLanguageIsoCode(languageISOCode);
			return user;
		} else {
			return null;
		}
	}

}
