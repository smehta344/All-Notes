/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.olam.ofis.atsource.util.AtSourceConstants;

@Entity
@Table(name="questions",schema = AtSourceConstants.SURVEY_SCHEMA)
public class Question implements Serializable {
	
	public Question() {
		// default constructor
	}
	
	/**
	 * Generated SERIEL UID
	 */
	private static final long serialVersionUID = -6441111082391815594L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "submodule_id")
	private Long submoduleId;
	
	@Column(name = "datatype_id")
	private Long dataTypeId;
	
	@Column(name = "position")
	private Long position;
	
	@Column(name = "display_type")
	private String displayType;
	
	@Column(name = "question")
	private String questionEn;
	
	@Column(name = "question_fr")
	private String questionFr;
	
	@Column(name = "question_es")
	private String questionEs;
	
	@Column(name = "question_id")
	private String questionId;
	
	@Column(name = "question_pt")
	private String questionPt;
	
	@Column(name = "question_tr")
	private String questionTr;
	
	@Column(name = "question_lo")
	private String questionLo;
	
	@Column(name = "question_vi")
	private String questionVi;
	
	@Column(name = "question_th")
	private String questionTh;
	
	@Column(name = "display_configuration")
	private String displayConfiguration;
	
	@Column(name = "storage_model")
	private String storageModel;
	
	@Column(name = "storage_column")
	private String storageColumn;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "active")
	private Boolean isActive;
	
	@Column(name = "created_at")
	private Date createdTs;

	@Column(name = "updated_at")
	private Date updatedTs;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSubmoduleId() {
		return submoduleId;
	}

	public void setSubmoduleId(Long submoduleId) {
		this.submoduleId = submoduleId;
	}

	public Long getDataTypeId() {
		return dataTypeId;
	}

	public void setDataTypeId(Long dataTypeId) {
		this.dataTypeId = dataTypeId;
	}

	public Long getPosition() {
		return position;
	}

	public void setPosition(Long position) {
		this.position = position;
	}

	public String getDisplayType() {
		return displayType;
	}

	public void setDisplayType(String displayType) {
		this.displayType = displayType;
	}

	public String getQuestionEn() {
		return questionEn;
	}

	public void setQuestionEn(String questionEn) {
		this.questionEn = questionEn;
	}

	public String getQuestionFr() {
		return questionFr;
	}

	public void setQuestionFr(String questionFr) {
		this.questionFr = questionFr;
	}

	public String getQuestionEs() {
		return questionEs;
	}

	public void setQuestionEs(String questionEs) {
		this.questionEs = questionEs;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getQuestionPt() {
		return questionPt;
	}

	public void setQuestionPt(String questionPt) {
		this.questionPt = questionPt;
	}

	public String getQuestionTr() {
		return questionTr;
	}

	public void setQuestionTr(String questionTr) {
		this.questionTr = questionTr;
	}

	public String getQuestionLo() {
		return questionLo;
	}

	public void setQuestionLo(String questionLo) {
		this.questionLo = questionLo;
	}

	public String getQuestionVi() {
		return questionVi;
	}

	public void setQuestionVi(String questionVi) {
		this.questionVi = questionVi;
	}

	public String getQuestionTh() {
		return questionTh;
	}

	public void setQuestionTh(String questionTh) {
		this.questionTh = questionTh;
	}

	public String getDisplayConfiguration() {
		return displayConfiguration;
	}

	public void setDisplayConfiguration(String displayConfiguration) {
		this.displayConfiguration = displayConfiguration;
	}

	public String getStorageModel() {
		return storageModel;
	}

	public void setStorageModel(String storageModel) {
		this.storageModel = storageModel;
	}

	public String getStorageColumn() {
		return storageColumn;
	}

	public void setStorageColumn(String storageColumn) {
		this.storageColumn = storageColumn;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public Date getUpdatedTs() {
		return updatedTs;
	}

	public void setUpdatedTs(Date updatedTs) {
		this.updatedTs = updatedTs;
	}

	
	
}
