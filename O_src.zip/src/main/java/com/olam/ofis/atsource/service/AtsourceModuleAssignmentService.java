/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.service;

import java.util.List;

import com.olam.ofis.atsource.dto.AtsourceModuleAssignmentDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.SubModuleDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.model.AtsourceModuleAssignment;

public interface AtsourceModuleAssignmentService {

	/**
	 * To save atsource module assignment
	 *
	 * @param atsourceModuleAssignmentDto
	 * @return {@link MessageDto}
	 * @throws CustomValidationException
	 */
	MessageDto saveModuleAssignment(AtsourceModuleAssignmentDto atsourceModuleAssignmentDto)
			throws CustomValidationException;

	/**
	 * To get atsource module assignment
	 *
	 * @param moduleId - {@link Integer}
	 * @return {@link AtsourceModuleAssignmentDto}
	 * @throws CustomValidationException
	 */
	AtsourceModuleAssignmentDto getModuleAssignment(Integer moduleId) 
			throws CustomValidationException;

	/**
	 * To get all atsource module assignment without module id
	 *
	 * @return {@link List<AtsourceModuleAssignmentDto>}
	 * @throws CustomValidationException
	 */
	public List<AtsourceModuleAssignmentDto> getAllModuleAssignment() 
			throws CustomValidationException;

	AtsourceModuleAssignment getAtSourceModule();

	List<SubModuleDto> getAllSubmodulesByModuleId(Integer id) throws CustomValidationException;
}
