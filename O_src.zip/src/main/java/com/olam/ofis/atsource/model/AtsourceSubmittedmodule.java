/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.olam.ofis.atsource.util.AtSourceConstants;

/**
 * The persistent class for the atsource_submittedmodules database table.
 * 
 */
@Entity
@Table(name = "atsource_submittedmodules", 
	schema = AtSourceConstants.ATSOURCE_SCHEMA, catalog = AtSourceConstants.ATSOURCE_SCHEMA)
public class AtsourceSubmittedmodule implements Serializable {
	
	public AtsourceSubmittedmodule() {
		// default constructor
	}
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "module_id")
	private Integer moduleId;

	@Column(name = "farmer_group_id")
	private Integer farmerGroupId;

	@Enumerated(EnumType.ORDINAL)
	private Status status;

	@Column(name = "version_number")
	private Integer versionNumber;
	
	@Column(name = "app_id")
	private Integer appId;

	@Column(name = "created_at")
	private Date createdAt;

	@Column(name = "created_by")
	private BigInteger createdBy;

	@Column(name = "rejected_date")
	private Date rejectedDate;

	@Column(name = "submitted_date")
	private Date submittedDate;

	@Column(name = "approved_date")
	private Date approvedDate;

	@Column(name = "updated_at")
	private Date updatedAt;

	@Column(name = "updated_by")
	private BigInteger updatedBy;

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAppId() {
		return this.appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public BigInteger getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(BigInteger createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getFarmerGroupId() {
		return this.farmerGroupId;
	}

	public void setFarmerGroupId(Integer farmerGroupId) {
		this.farmerGroupId = farmerGroupId;
	}

	public Integer getModuleId() {
		return this.moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public Date getRejectedDate() {
		return this.rejectedDate;
	}

	public void setRejectedDate(Date rejectedDate) {
		this.rejectedDate = rejectedDate;
	}

	public Date getSubmittedDate() {
		return this.submittedDate;
	}

	public void setSubmittedDate(Date submittedDate) {
		this.submittedDate = submittedDate;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public BigInteger getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(BigInteger updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Integer getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(Integer versionNumber) {
		this.versionNumber = versionNumber;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}
	
}
