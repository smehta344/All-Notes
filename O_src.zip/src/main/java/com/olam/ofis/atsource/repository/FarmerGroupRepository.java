/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.olam.ofis.atsource.model.FarmerGroup;

public interface FarmerGroupRepository extends JpaRepository<FarmerGroup, Long> {

	@Query("SELECT f FROM FarmerGroup f WHERE f.countryId IN :moduleAssignmentIds AND f.active=true ORDER BY f.name")
	List<FarmerGroup> getFarmerGroupsByCountryIds(@Param("moduleAssignmentIds") List<Long> moduleAssignmentIds);

	@Query("SELECT f FROM FarmerGroup f WHERE f.farmerGroupId IN :moduleAssignmentIds AND f.active=true ORDER BY f.name")
	List<FarmerGroup> getFarmerGroupsById(@Param("moduleAssignmentIds") List<Long> moduleAssignmentIds);

	@Query("SELECT f FROM FarmerGroup f WHERE f.productId IN :moduleAssignmentIds AND f.active=true ORDER BY f.name")
	List<FarmerGroup> getFarmerGroupsByProductIds(@Param("moduleAssignmentIds") List<Long> moduleAssignmentIds);

	@Query("SELECT f FROM FarmerGroup f WHERE f.partnerId IN :moduleAssignmentIds AND f.active=true ORDER BY f.name")
	List<FarmerGroup> getFarmerGroupsByPartnerIds(@Param("moduleAssignmentIds") List<Long> moduleAssignmentIds);

	@Query("SELECT f FROM FarmerGroup f WHERE f.programmeId IN :moduleAssignmentIds AND f.active=true ORDER BY f.name")
	List<FarmerGroup> getFarmerGroupsByProgrammeIds(@Param("moduleAssignmentIds") List<Long> moduleAssignmentIds);

	@SuppressWarnings("rawtypes")
	@Query(value= "SELECT fg FROM FarmerGroup fg where fg.countryId in "
			+ "(:countryIdList) and fg.productId in (:productIdList) and fg.active = 1")
	List<FarmerGroup> getFGByCountriesAndProducts(@Param("countryIdList") List countryIdList,
			@Param("productIdList") List productIdList);

	@SuppressWarnings("rawtypes")
	@Query(value = "SELECT fg FROM FarmerGroup fg WHERE fg.partnerId in (:partnerIdList) and fg.active = 1")
	List<FarmerGroup> getFGIdByPartners(@Param("partnerIdList") List partnerIdList);

	@Query("SELECT fg FROM FarmerGroupUser fu JOIN fu.farmergroups fg WHERE fu.userId = :userId and fg.active = 1")
	List<FarmerGroup> getFarmerGroupsByUserId(@Param("userId") Long userId);

	@Query("SELECT COUNT(fu) FROM FarmerGroupUser fu WHERE fu.userId = :userId")
	int findFarmerGroupByUser(@Param("userId") Long userId);
}
