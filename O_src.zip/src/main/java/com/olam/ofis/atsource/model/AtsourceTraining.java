/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the atsource_training database table.
 * 
 */
@Entity
@Table(name = "atsource_training")
public class AtsourceTraining implements Serializable {
	
	public AtsourceTraining() {
		// default constructor
	}
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "app_id")
	private Integer appId;

	private Byte attended;

	@Column(name = "course_description")
	private String courseDescription;

	@Column(name = "course_id")
	private Integer courseId;

	@Column(name = "course_name")
	private String courseName;

	@Column(name = "course_name_es")
	private String courseNameEs;

	@Column(name = "course_name_fr")
	private String courseNameFr;

	@Column(name = "course_name_id")
	private String courseNameId;

	@Column(name = "course_name_lo")
	private String courseNameLo;

	@Column(name = "course_name_pt")
	private String courseNamePt;

	@Column(name = "course_name_th")
	private String courseNameTh;

	@Column(name = "course_name_tr")
	private String courseNameTr;

	@Column(name = "course_name_vi")
	private String courseNameVi;

	@Column(name = "course_target")
	private Integer courseTarget;

	@Column(name = "course_target_percentage")
	private Integer courseTargetPercentage;

	@Column(name = "created_at")
	private Date createdAt;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "farmer_id")
	private BigInteger farmerId;

	private String grade;

	private Byte passed;

	private BigDecimal percentage;

	@Column(name = "pillar_id")
	private Integer pillarId;

	@Column(name = "pillar_name")
	private String pillarName;

	private BigDecimal postscore;

	private BigDecimal prescore;

	private BigDecimal score;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "submission_time")
	private Date submissionTime;

	@Column(name = "trainingattendees_id")
	private Integer trainingattendeesId;

	@Column(name = "trainingmodule_completioncriterion_id")
	private Integer trainingmoduleCompletioncriterionId;

	@Column(name = "trainingmodule_description")
	private String trainingmoduleDescription;

	@Column(name = "trainingmodule_id")
	private Integer trainingmoduleId;

	@Column(name = "trainingmodule_name")
	private String trainingmoduleName;

	@Column(name = "trainingmodule_name_es")
	private String trainingmoduleNameEs;

	@Column(name = "trainingmodule_name_fr")
	private String trainingmoduleNameFr;

	@Column(name = "trainingmodule_name_id")
	private String trainingmoduleNameId;

	@Column(name = "trainingmodule_name_lo")
	private String trainingmoduleNameLo;

	@Column(name = "trainingmodule_name_pt")
	private String trainingmoduleNamePt;

	@Column(name = "trainingmodule_name_th")
	private String trainingmoduleNameTh;

	@Column(name = "trainingmodule_name_tr")
	private String trainingmoduleNameTr;

	@Column(name = "trainingmodule_name_vi")
	private String trainingmoduleNameVi;

	@Column(name = "trainingrecord_id")
	private Integer trainingrecordId;

	@Column(name = "updated_at")
	private Date updatedAt;

	@Column(name = "updated_by")
	private String updatedBy;

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAppId() {
		return this.appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public Byte getAttended() {
		return this.attended;
	}

	public void setAttended(Byte attended) {
		this.attended = attended;
	}

	public String getCourseDescription() {
		return this.courseDescription;
	}

	public void setCourseDescription(String courseDescription) {
		this.courseDescription = courseDescription;
	}

	public Integer getCourseId() {
		return this.courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return this.courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseNameEs() {
		return this.courseNameEs;
	}

	public void setCourseNameEs(String courseNameEs) {
		this.courseNameEs = courseNameEs;
	}

	public String getCourseNameFr() {
		return this.courseNameFr;
	}

	public void setCourseNameFr(String courseNameFr) {
		this.courseNameFr = courseNameFr;
	}

	public String getCourseNameId() {
		return this.courseNameId;
	}

	public void setCourseNameId(String courseNameId) {
		this.courseNameId = courseNameId;
	}

	public String getCourseNameLo() {
		return this.courseNameLo;
	}

	public void setCourseNameLo(String courseNameLo) {
		this.courseNameLo = courseNameLo;
	}

	public String getCourseNamePt() {
		return this.courseNamePt;
	}

	public void setCourseNamePt(String courseNamePt) {
		this.courseNamePt = courseNamePt;
	}

	public String getCourseNameTh() {
		return this.courseNameTh;
	}

	public void setCourseNameTh(String courseNameTh) {
		this.courseNameTh = courseNameTh;
	}

	public String getCourseNameTr() {
		return this.courseNameTr;
	}

	public void setCourseNameTr(String courseNameTr) {
		this.courseNameTr = courseNameTr;
	}

	public String getCourseNameVi() {
		return this.courseNameVi;
	}

	public void setCourseNameVi(String courseNameVi) {
		this.courseNameVi = courseNameVi;
	}

	public Integer getCourseTarget() {
		return this.courseTarget;
	}

	public void setCourseTarget(Integer courseTarget) {
		this.courseTarget = courseTarget;
	}

	public Integer getCourseTargetPercentage() {
		return this.courseTargetPercentage;
	}

	public void setCourseTargetPercentage(Integer courseTargetPercentage) {
		this.courseTargetPercentage = courseTargetPercentage;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public BigInteger getFarmerId() {
		return this.farmerId;
	}

	public void setFarmerId(BigInteger farmerId) {
		this.farmerId = farmerId;
	}

	public String getGrade() {
		return this.grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public Byte getPassed() {
		return this.passed;
	}

	public void setPassed(Byte passed) {
		this.passed = passed;
	}

	public BigDecimal getPercentage() {
		return this.percentage;
	}

	public void setPercentage(BigDecimal percentage) {
		this.percentage = percentage;
	}

	public Integer getPillarId() {
		return this.pillarId;
	}

	public void setPillarId(Integer pillarId) {
		this.pillarId = pillarId;
	}

	public String getPillarName() {
		return this.pillarName;
	}

	public void setPillarName(String pillarName) {
		this.pillarName = pillarName;
	}

	public BigDecimal getPostscore() {
		return this.postscore;
	}

	public void setPostscore(BigDecimal postscore) {
		this.postscore = postscore;
	}

	public BigDecimal getPrescore() {
		return this.prescore;
	}

	public void setPrescore(BigDecimal prescore) {
		this.prescore = prescore;
	}

	public BigDecimal getScore() {
		return this.score;
	}

	public void setScore(BigDecimal score) {
		this.score = score;
	}

	public Date getSubmissionTime() {
		return this.submissionTime;
	}

	public void setSubmissionTime(Date submissionTime) {
		this.submissionTime = submissionTime;
	}

	public Integer getTrainingattendeesId() {
		return this.trainingattendeesId;
	}

	public void setTrainingattendeesId(Integer trainingattendeesId) {
		this.trainingattendeesId = trainingattendeesId;
	}

	public Integer getTrainingmoduleCompletioncriterionId() {
		return this.trainingmoduleCompletioncriterionId;
	}

	public void setTrainingmoduleCompletioncriterionId(Integer trainingmoduleCompletioncriterionId) {
		this.trainingmoduleCompletioncriterionId = trainingmoduleCompletioncriterionId;
	}

	public String getTrainingmoduleDescription() {
		return this.trainingmoduleDescription;
	}

	public void setTrainingmoduleDescription(String trainingmoduleDescription) {
		this.trainingmoduleDescription = trainingmoduleDescription;
	}

	public Integer getTrainingmoduleId() {
		return this.trainingmoduleId;
	}

	public void setTrainingmoduleId(Integer trainingmoduleId) {
		this.trainingmoduleId = trainingmoduleId;
	}

	public String getTrainingmoduleName() {
		return this.trainingmoduleName;
	}

	public void setTrainingmoduleName(String trainingmoduleName) {
		this.trainingmoduleName = trainingmoduleName;
	}

	public String getTrainingmoduleNameEs() {
		return this.trainingmoduleNameEs;
	}

	public void setTrainingmoduleNameEs(String trainingmoduleNameEs) {
		this.trainingmoduleNameEs = trainingmoduleNameEs;
	}

	public String getTrainingmoduleNameFr() {
		return this.trainingmoduleNameFr;
	}

	public void setTrainingmoduleNameFr(String trainingmoduleNameFr) {
		this.trainingmoduleNameFr = trainingmoduleNameFr;
	}

	public String getTrainingmoduleNameId() {
		return this.trainingmoduleNameId;
	}

	public void setTrainingmoduleNameId(String trainingmoduleNameId) {
		this.trainingmoduleNameId = trainingmoduleNameId;
	}

	public String getTrainingmoduleNameLo() {
		return this.trainingmoduleNameLo;
	}

	public void setTrainingmoduleNameLo(String trainingmoduleNameLo) {
		this.trainingmoduleNameLo = trainingmoduleNameLo;
	}

	public String getTrainingmoduleNamePt() {
		return this.trainingmoduleNamePt;
	}

	public void setTrainingmoduleNamePt(String trainingmoduleNamePt) {
		this.trainingmoduleNamePt = trainingmoduleNamePt;
	}

	public String getTrainingmoduleNameTh() {
		return this.trainingmoduleNameTh;
	}

	public void setTrainingmoduleNameTh(String trainingmoduleNameTh) {
		this.trainingmoduleNameTh = trainingmoduleNameTh;
	}

	public String getTrainingmoduleNameTr() {
		return this.trainingmoduleNameTr;
	}

	public void setTrainingmoduleNameTr(String trainingmoduleNameTr) {
		this.trainingmoduleNameTr = trainingmoduleNameTr;
	}

	public String getTrainingmoduleNameVi() {
		return this.trainingmoduleNameVi;
	}

	public void setTrainingmoduleNameVi(String trainingmoduleNameVi) {
		this.trainingmoduleNameVi = trainingmoduleNameVi;
	}

	public Integer getTrainingrecordId() {
		return this.trainingrecordId;
	}

	public void setTrainingrecordId(Integer trainingrecordId) {
		this.trainingrecordId = trainingrecordId;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

}
