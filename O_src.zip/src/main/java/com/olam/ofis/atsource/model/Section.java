/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.olam.ofis.atsource.util.AtSourceConstants;

@Entity
@Table(schema = AtSourceConstants.MASTER_SCHEMA, name = "sections", catalog = AtSourceConstants.MASTER_SCHEMA)
public class Section implements Serializable{

	public Section() {
		// default constructor	
	}
	
	private static final long serialVersionUID = 5079190864875098845L;
	
	@Id
	@Column(name = "id")
	private Long sectionId;

	@Column(name = "farmergroup_id")
	private Long farmerGroupId;

	@Column(name = "credit_balance")
	private Long creditBalance;

	@Column(name = "code")
	private String code;

	@Column(name = "name")
	private String name;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "active")
	private Boolean active;

	@Column(name = "created_at")
	private Date createdTs;

	@Column(name = "updated_at")
	private Date updatedTs;

	@OneToMany
	@JoinColumn(name = "farmer_group_id")
	private List<FarmerGroup> farmerGroups;

	public Long getSectionId() {
		return sectionId;
	}

	public void setSectionId(Long sectionId) {
		this.sectionId = sectionId;
	}

	public Long getFarmerGroupId() {
		return farmerGroupId;
	}

	public void setFarmerGroupId(Long farmerGroupId) {
		this.farmerGroupId = farmerGroupId;
	}

	public Long getCreditBalance() {
		return creditBalance;
	}

	public void setCreditBalance(Long creditBalance) {
		this.creditBalance = creditBalance;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public Date getUpdatedTs() {
		return updatedTs;
	}

	public void setUpdatedTs(Date updatedTs) {
		this.updatedTs = updatedTs;
	}

	public List<FarmerGroup> getFarmerGroups() {
		return farmerGroups;
	}

	public void setFarmerGroups(List<FarmerGroup> farmerGroups) {
		this.farmerGroups = farmerGroups;
	}

}
