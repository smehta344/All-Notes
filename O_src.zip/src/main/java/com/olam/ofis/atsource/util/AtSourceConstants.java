/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.util;

import java.math.BigInteger;

public final class AtSourceConstants {
	public AtSourceConstants() {
	}

	public static final String AUTHORIZATION = "Authorization";

	public static final String ATSOURCE_SCHEMA = "ofisatsource";

	public static final String MASTER_SCHEMA = "master";
	public static final String FARMER_SCHEMA = "farmer";
	public static final String SURVEY_SCHEMA = "survey";
	public static final String TRAINING_SCHEMA = "training";

	public static final String DATE_FORMAT_DD_MM_YYYY = "dd-MM-yyyy";
	public static final String DATE_FORMAT_YYYYMMDD = "yyyy-MM-dd";

	// Default language
	public static final String ENGLISH = "en";

	// Application Types
	public static final int APPLICATIONTYPE_OFIS = 1;
	public static final int APPLICATIONTYPE_OT = 2;
	public static final int APPLICATIONTYPE_OD = 3;
	public static final int APPLICATIONTYPE_FSP = 4;
	public static final Integer SUB_MODULE_ID = 1;
	public static final Integer DATA_TYPE_ID = 2;
	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
	public static final BigInteger CREATED_BY = BigInteger.valueOf(0);
	public static final String COUNTRY = "Country";
	public static final String FARMERGROUP = "FarmerGroup";
	public static final String FARMER_GROUP = "Farmer Group";
	public static final String PRODUCT = "Product";
	public static final String PARTNER = "Partner";
	public static final String PROGRAMME = "Programme";
	public static final String SECTION = "Section";
	public static final String REGION = "Region";
	public static final String DISTRICT = "District";
	public static final String PLACE = "Place";

	public static final String PARENT_QUESTION_REPEATER = "repeater";
	public static final String PARENT_QUESTION_REPEATER_ID = "%\"repeater_id\":";
	public static final String ATSOURCE_ASSIGNMENTS_DELETED = "Module Assignment cleared";
}
