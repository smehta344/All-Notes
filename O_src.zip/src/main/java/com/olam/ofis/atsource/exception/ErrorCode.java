/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.exception;

public enum ErrorCode implements ErrorHandle {
	OFIS_ATSOURCE_2001(2001, "Oops!!! Something went wrong. Please contact the administrator."),
	OFIS_ATSOURCE_2002(2002, "App Id Required"), OFIS_ATSOURCE_2003(2003, "Given atsource survey answers not present."),
	OFIS_ATSOURCE_2004(2004, "Given ID mismatch with the path parameter."),
	OFIS_ATSOURCE_2005(2005, "Invalid ID field."), OFIS_ATSOURCE_2006(2006, "User ID not found."),
	OFIS_ATSOURCE_2007(2007, "Survey answer already submitted."),
	OFIS_ATSOURCE_2008(2008, "Unable to save atsource module assignments."),
	OFIS_ATSOURCE_2009(2009, "No module assignments found"), OFIS_ATSOURCE_2010(2010, "Module Id Required."),
	OFIS_ATSOURCE_2011(2011, "Invalid Module Id."), OFIS_ATSOURCE_2012(2012, "Module is not active."),
	OFIS_ATSOURCE_2013(2013, "Invalid Question Id."), OFIS_ATSOURCE_2014(2014, "Survey answer not found."),
	OFIS_ATSOURCE_2015(2015, "Unable to save Question data."),
	OFIS_ATSOURCE_2016(2016, "Unable to save Lookup Value data."),
	OFIS_ATSOURCE_2017(2017, "Module Assignment type not found"),
	OFIS_ATSOURCE_2018(2018, "Question Id not found."),
	OFIS_ATSOURCE_2019(2019, "Farmer Group Id not found."),
	OFIS_ATSOURCE_2020(2020, "Submitted Module Id not found."),
	OFIS_ATSOURCE_2021(2021, "Survey answer id not found."),
	OFIS_ATSOURCE_2022(2022, "Unable to save survey answer."),
	OFIS_ATSOURCE_2023(2023, "Submitted flag not found."),
	OFIS_ATSOURCE_2024(2024, "No Survey answers found."),
	OFIS_ATSOURCE_2025(2025, "Submitted module not found."),
	OFIS_ATSOURCE_2026(2026, "Submitted module already submitted."),
	OFIS_ATSOURCE_2027(2027, "Submitted module exists for this farmer group."),
	OFIS_ATSOURCE_2028(2028, "KM Code mandatory."),
	OFIS_ATSOURCE_2029(2029, "Invalid KM Code."),
	OFIS_ATSOURCE_2030(2030, "Min or Max value not found."),
	OFIS_ATSOURCE_2031(2031, "Farmergroup list can't abe empty"),
	OFIS_ATSOURCE_2032(2032, "One of farmer group id, submitted module id or status can't be empty"),
	OFIS_ATSOURCE_2033(2033, "{#FILED} : {#VALUE} is not exits"),
    OFIS_ATSOURCE_2034(2034,"Km Code cannot be empty" ),
    OFIS_ATSOURCE_2035(2035,"Duplicate KM code" ),
	OFIS_ATSOURCE_2036(2036, "Unable to save survey review data."),
	OFIS_ATSOURCE_2037(2037, "Survey review ID mandatory."),
	OFIS_ATSOURCE_2038(2038, "Survey review ID didn't match with the request param."),
	OFIS_ATSOURCE_2039(2039, "Invalid Survey review ID."),
	OFIS_ATSOURCE_2040(2040, "Survey review already approved."),
	OFIS_ATSOURCE_2041(2041, "Survey review not found."),
	OFIS_ATSOURCE_2042(2042, "Survey review already submitted."),
	OFIS_ATSOURCE_2043(2043, "Survey review already rejected.");
	

	private final int code;
	private final String message;

	ErrorCode(int errorCode, String message) {
		this.code = errorCode;
		this.message = message;
	}

	@Override
	public int getErrorCode() {

		return this.code;
	}

	@Override
	public String getMessage() {

		return this.message;
	}

}
