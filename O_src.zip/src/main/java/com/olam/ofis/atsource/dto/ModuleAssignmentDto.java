/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Ideas2it-Karthick on 3/4/19.
 */
public class ModuleAssignmentDto implements Serializable {

	private static final long serialVersionUID = -2281460330489867926L;

	private Integer id;

	private Integer moduleId;

	private Integer moduleassignmentId;

	private String moduleassignmentType;

	private Integer recurrenceFrequency;

	private String recurrenceType;

	private String disabledMonths;

	private Boolean active;

	private Date createdAt;

	private Date updatedAt;

	private Integer appId;

	public ModuleAssignmentDto() {
		// default constructor
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public Integer getModuleassignmentId() {
		return moduleassignmentId;
	}

	public void setModuleassignmentId(Integer moduleassignmentId) {
		this.moduleassignmentId = moduleassignmentId;
	}

	public String getModuleassignmentType() {
		return moduleassignmentType;
	}

	public void setModuleassignmentType(String moduleassignmentType) {
		this.moduleassignmentType = moduleassignmentType;
	}

	public Integer getRecurrenceFrequency() {
		return recurrenceFrequency;
	}

	public void setRecurrenceFrequency(Integer recurrenceFrequency) {
		this.recurrenceFrequency = recurrenceFrequency;
	}

	public String getRecurrenceType() {
		return recurrenceType;
	}

	public void setRecurrenceType(String recurrenceType) {
		this.recurrenceType = recurrenceType;
	}

	public String getDisabledMonths() {
		return disabledMonths;
	}

	public void setDisabledMonths(String disabledMonths) {
		this.disabledMonths = disabledMonths;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	
}
