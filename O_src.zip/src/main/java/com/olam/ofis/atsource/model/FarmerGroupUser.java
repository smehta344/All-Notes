/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.olam.ofis.atsource.util.AtSourceConstants;

@Entity
@Table(schema= AtSourceConstants.MASTER_SCHEMA,name="farmergroup_user",catalog=AtSourceConstants.MASTER_SCHEMA)
public class FarmerGroupUser {
	
	public FarmerGroupUser() {
		// default constructor
	}
	
	@Column(name="id")
	private Long farmergroupUserId;
	
	@Id
	@Column(name="farmergroup_id")
	private Long farmergroupId;
	
	@Column(name="user_id")
	private Long userId;
	
	@Column(name="created_at")
	private Date createdAt;
	
	@Column(name="updated_at")
	private Date updatedAt;
	
	@OneToMany
	@JoinColumn(name="farmer_group_id")
	private List<FarmerGroup> farmergroups;

	public Long getFarmergroupUserId() {
		return farmergroupUserId;
	}

	public void setFarmergroupUserId(Long farmergroupUserId) {
		this.farmergroupUserId = farmergroupUserId;
	}

	public Long getFarmergroupId() {
		return farmergroupId;
	}

	public void setFarmergroupId(Long farmergroupId) {
		this.farmergroupId = farmergroupId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<FarmerGroup> getFarmergroups() {
		return farmergroups;
	}

	public void setFarmergroups(List<FarmerGroup> farmergroups) {
		this.farmergroups = farmergroups;
	}
	
	

}
