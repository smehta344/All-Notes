/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.dto;

import java.io.Serializable;

/**
 * Created by Ideas2it-Karthick on 29/3/19.
 */
public class AtsourceSurveyLookupvalueDto extends BaseDTO implements Serializable {

	public AtsourceSurveyLookupvalueDto() {
		// default constructor
	}
	
	private static final long serialVersionUID = 517887646698951861L;

	private Integer id;
	private Integer questionId;
	private String questionName;
	private Integer position;
	private String value;
	private String valueFr;
	private String valueEs;
	private String valueId;
	private String valuePt;
	private String valueTr;
	private String valueLo;
	private String valueVi;
	private String valueTh;
	private String photo;
	private String code;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}

	public String getQuestionName() {
		return questionName;
	}

	public void setQuestionName(String questionName) {
		this.questionName = questionName;
	}

	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getValueFr() {
		return valueFr;
	}

	public void setValueFr(String valueFr) {
		this.valueFr = valueFr;
	}

	public String getValueEs() {
		return valueEs;
	}

	public void setValueEs(String valueEs) {
		this.valueEs = valueEs;
	}

	public String getValueId() {
		return valueId;
	}

	public void setValueId(String valueId) {
		this.valueId = valueId;
	}

	public String getValuePt() {
		return valuePt;
	}

	public void setValuePt(String valuePt) {
		this.valuePt = valuePt;
	}

	public String getValueTr() {
		return valueTr;
	}

	public void setValueTr(String valueTr) {
		this.valueTr = valueTr;
	}

	public String getValueLo() {
		return valueLo;
	}

	public void setValueLo(String valueLo) {
		this.valueLo = valueLo;
	}

	public String getValueVi() {
		return valueVi;
	}

	public void setValueVi(String valueVi) {
		this.valueVi = valueVi;
	}

	public String getValueTh() {
		return valueTh;
	}

	public void setValueTh(String valueTh) {
		this.valueTh = valueTh;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
