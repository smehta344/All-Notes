/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.olam.ofis.atsource.dto.AtSourceQuestionDto;
import com.olam.ofis.atsource.dto.AtSourceSurveyAnswerDto;
import com.olam.ofis.atsource.dto.AtsourceSubmittedmoduleDto;
import com.olam.ofis.atsource.dto.AtsourceSurveyResponseDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.ModuleDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.service.AtSourceSurveyAnswerService;
import com.olam.ofis.atsource.util.PaginationResult;

/**
 * <p>
 * CRUD operation for atsource survey answers.
 * </p>
 * 
 * @author Rajasankar
 */
@RestController
@RequestMapping(path = "/atsource/answers")
public class AtSourceSurveyanswerController extends BaseController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private AtSourceSurveyAnswerService atSourceSurveyAnswerSerive;

	@GetMapping("/surveyAnswers")
	public ResponseEntity<List<AtSourceSurveyAnswerDto>> getAllSurveyAnswers(HttpServletRequest httpServletRequest) {
		logger.debug("Get all atsource survey answers");
		List<AtSourceSurveyAnswerDto> surveyAnswers = atSourceSurveyAnswerSerive.findAll();
		return new ResponseEntity<>(surveyAnswers, HttpStatus.OK);
	}

	@GetMapping("/surveyAnswer/paginated")
	public ResponseEntity<PaginationResult<AtSourceSurveyAnswerDto>> getPaginatedSurveyAnswers(
			@RequestParam(name = "pageNo", defaultValue = "1", required = false) Integer pageNo,
			@RequestParam(name = "size", required = false, defaultValue = "50") Integer size,
			@RequestParam(name = "orderBy", required = false, defaultValue = "id") String orderBy,
			@RequestParam(name = "direction", required = false, defaultValue = "asc") String direction,
			HttpServletRequest httpServletRequest) {
		logger.debug("Get paginated atsource survey answers");
		PaginationResult<AtSourceSurveyAnswerDto> surveyAnswers = atSourceSurveyAnswerSerive
				.getPaginatedSurveyAnswers(pageNo, size, orderBy, direction);
		return new ResponseEntity<>(surveyAnswers, HttpStatus.OK);
	}

	@GetMapping("/surveyAnswer/{id}")
	public ResponseEntity<AtSourceSurveyAnswerDto> getSurveyAnswersById(@PathVariable Long id,
			HttpServletRequest httpServletRequest) throws CustomValidationException {
		logger.debug("Get atsource survey answers by id");
		AtSourceSurveyAnswerDto surveyAnswer = atSourceSurveyAnswerSerive.findById(id);
		return new ResponseEntity<>(surveyAnswer, HttpStatus.OK);
	}

	@GetMapping("/surveyAnswer/farmerGroup")
	public ResponseEntity<List<AtSourceSurveyAnswerDto>> getSurveyAnswersByFarmerGroupId(
			@RequestParam(name = "farmerGroupId", required = true) Integer farmerGroupId,
			HttpServletRequest httpServletRequest) throws CustomValidationException {
		logger.debug("Get atsource survey answers by id");
		List<AtSourceSurveyAnswerDto> surveyAnswers = atSourceSurveyAnswerSerive
				.getSurveyAnswersByFarmerGroupId(farmerGroupId);
		return new ResponseEntity<>(surveyAnswers, HttpStatus.OK);
	}

	@GetMapping("/surveyQuestionswithLookupValues")
	public ResponseEntity<List<AtSourceQuestionDto>> getSurveyQuestions(HttpServletRequest httpServletRequest)
			throws CustomValidationException {
		logger.debug("Get atsource survey Questions");
		List<AtSourceQuestionDto> surveyQuestions = atSourceSurveyAnswerSerive.getAtSourceSurveyQuestions();
		return new ResponseEntity<>(surveyQuestions, HttpStatus.OK);
	}

	@PostMapping("/surveyAnswer")
	public ResponseEntity<AtsourceSubmittedmoduleDto> createAtSourceSurveyAnswer(
			@RequestBody AtsourceSubmittedmoduleDto atsourceSubmittedmoduleDto, HttpServletRequest httpServletRequest)
			throws CustomValidationException {
		logger.debug("Create at source survey Answers");
		Long userId = getUser().getUserId();
		AtsourceSubmittedmoduleDto surveyAnswer = atSourceSurveyAnswerSerive.createAnswer(atsourceSubmittedmoduleDto,
				userId);
		return new ResponseEntity<>(surveyAnswer, HttpStatus.OK);
	}

	@PutMapping("/surveyAnswer/{id}")
	public ResponseEntity<AtsourceSubmittedmoduleDto> updateAtSourceSurveyAnswer(@PathVariable("id") Long id,
			@RequestBody AtsourceSubmittedmoduleDto atsourceSubmittedmoduleDto, HttpServletRequest httpServletRequest)
			throws CustomValidationException {
		logger.debug("Update at source survey Answers");
		Long userId = getUser().getUserId();
		AtsourceSubmittedmoduleDto surveyAnswer = atSourceSurveyAnswerSerive.updateAnswer(id,
				atsourceSubmittedmoduleDto, userId);
		return new ResponseEntity<>(surveyAnswer, HttpStatus.OK);
	}

	@GetMapping("/getFarmerGroups")
	public ResponseEntity<ModuleDto> getFarmerGroups() throws CustomValidationException {
		logger.debug("Get atsource farmer groups");
		ModuleDto farmerGroupDtoList = atSourceSurveyAnswerSerive.getFarmerGroups(getUser().getUserId());
		return new ResponseEntity<>(farmerGroupDtoList, HttpStatus.OK);
	}

	@GetMapping("/surveyAnswerByFarmerGroup/{id}")
	public ResponseEntity<AtsourceSubmittedmoduleDto> getSurveyAnswersByFarmerGroupId(@PathVariable Long id,
			HttpServletRequest httpServletRequest) throws CustomValidationException {
		logger.debug("Get atsource survey answers by farmer group id");
		AtsourceSubmittedmoduleDto submittedmoduleDto = atSourceSurveyAnswerSerive.findByFarmerGroupId(id);
		return new ResponseEntity<>(submittedmoduleDto, HttpStatus.OK);
	}

	@PutMapping("/atSourceSurveyResponse")
	public ResponseEntity<MessageDto> saveAtsourceSurveyResponses(
			@RequestBody List<AtsourceSurveyResponseDto> responses) throws CustomValidationException {
		logger.debug("Save atsource survey response, approval/rejection flow");
		MessageDto response = atSourceSurveyAnswerSerive.saveAtsourceSurveyResponses(responses, getUser().getUserId());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
