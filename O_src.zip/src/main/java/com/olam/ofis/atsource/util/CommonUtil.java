/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.util;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.exception.ErrorCode;

/**
 * It contains common util methods
 * 
 * @author Mani K
 *
 */
public class CommonUtil {

	/**
	 * private constructor
	 */
	private CommonUtil() {}
	
	private static final Logger logger = LoggerFactory.getLogger(CommonUtil.class);
	public static final String DATE_FORMAT_DD_MM_YYYY = "dd/MM/YYYY";
	private static final int RANGE_TEN = 10;
	private static final int RANGE_SIXTEEN = 16;
	private static final int RANGE_EIGHT = 8;
	
	public static String convertToDateString(Date date) {
		String dateString = null;
		logger.debug("Before Conversion of date {}", date);
		if (date != null) {
			SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_DD_MM_YYYY);
			dateString = format.format(date);
			logger.debug("After Conversion of date {}", dateString);
		}

		return dateString;
	}

	/**
	 * Used to format the date using specific format.
	 * 
	 * @param dateStr   (i.e, 31-Jun-2018)
	 * @param formatStr (i.e, yyyy-MM-dd)
	 * @return {@link Date}
	 */
	public static Date formatDate(String dateStr, String formatStr) {
		DateFormat df = null;
		Date date = null;
		try {
			if (!isNull(dateStr, formatStr)) {
				df = new SimpleDateFormat(formatStr);
				date = df.parse(dateStr);
			}
		} catch (ParseException ex) {
			logger.error("Format date expection" , ex);
		}
		return date;
	}

	/**
	 * Used to format the date using default (yyyy-MM-dd HH:mm:ss) format.
	 * 
	 * @param dateStr (i.e, 31-Jun-2018)
	 * @return {@link Date}
	 */
	public static Date formatDate(String dateStr) {
		return !isNull(dateStr) ? formatDate(dateStr, CommonConstants.SURVEY_JSON_DATE_FORMAT) : null;
	}

	/**
	 * Used to format the date using default (yyyy-MM-dd HH:mm:ss) format.
	 * 
	 * @param date (i.e, 31-Jun-2018)
	 * @return {@link Date}
	 */
	public static Date formatDate(Date date) {
		return !isNull(date) ? formatDate(getDateString(date), CommonConstants.SURVEY_JSON_DATE_FORMAT) : null;
	}

	/**
	 * Used to get the date string using specific format
	 * 
	 * @param date      (i.e, 31-Jun-2018)
	 * @param formatStr (i.e, yyyy-MM-dd)
	 * @return {@link String}
	 */
	public static String getDateString(Date date, String formatStr) {
		String dateStr = null;
		DateFormat df = null;
		try {
			if (!isNull(date, formatStr)) {
				df = new SimpleDateFormat(formatStr);
				dateStr = df.format(date);
			}
		} catch (Exception ex) {
			logger.error("Error while getDateString" , ex);
		}
		return dateStr;
	}

	/**
	 * Used to get the date string using default (yyyy-MM-dd HH:mm:ss) format.
	 * 
	 * @param date (i.e, 31-Jun-2018)
	 * @return {@link String}
	 */
	public static String getDateString(Date date) {
		return getDateString(date, CommonConstants.SURVEY_JSON_DATE_FORMAT);
	}

	/**
	 * Used to get the two dates difference days / month / year.
	 * 
	 * @param fromDate
	 * @param toDate
	 * @param type     (i.e, YEAR / MONTH / DAY )
	 * @return int
	 */
	public static int getCalendarDiff(Date fromDate, Date toDate, int type) {
		Calendar fCal = Calendar.getInstance();
		Calendar tCal = Calendar.getInstance();
		fCal.setTime(fromDate);
		tCal.setTime(toDate);
		if (!isNull(fromDate, toDate)) {
			return (tCal.get(type) - fCal.get(type));
		}
		return 0;
	}

	/**
	 * Used to get the two dates difference years.
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return int
	 */
	public static int getDiffYears(Date fromDate, Date toDate) {
		return getCalendarDiff(fromDate, toDate, Calendar.YEAR);
	}

	public static Integer getDateField(Date date, int type) {
		Integer value = null;
		Calendar calendar = null;
		if (!isNull(date, type)) {
			calendar = Calendar.getInstance();
			calendar.setTime(date);
			return calendar.get(type);
		}
		return value;
	}

	public static Integer getDateField(String date, String dateFormat, int type) {
		return getDateField(formatDate(date, dateFormat), type);
	}

	public static Integer getDateField(String date, int type) {
		return getDateField(formatDate(date), type);
	}

	/**
	 * Used to check null condition
	 * 
	 * @param pObj
	 * @return boolean
	 */
	@SuppressWarnings("rawtypes")
	public static boolean isNull(Object... pObj) {
		Boolean isNull = false;
		if (pObj == null) {
			isNull = true;
		} else {
			for (Object lObj : pObj) {
				if (lObj == null) {
					isNull = true;
				} else if (lObj instanceof String) {
					isNull = ((String) lObj).trim().equals("");
				} else if (lObj instanceof Collection) {
					isNull = (((Collection) lObj).isEmpty());
				} else if (lObj instanceof Map) {
					isNull = (((Map) lObj).size() == 0);
				} else {
					isNull = false;
				}
				if (isNull) {
					break;
				}
			}
		}
		return isNull;
	}

	/**
	 * Used to check not null condition
	 * 
	 * @param pObj
	 * @return boolean
	 */
	public static boolean isNotNull(Object... pObj) {
		return !isNull(pObj);
	}

	/**
	 * Used to get the string to integer value.
	 * 
	 * @param value
	 * @return {@link Integer}
	 */
	public static int toInteger(String value) {
		int integerVal = 0;
		if (isNumeric(value)) {
			integerVal = Integer.parseInt(value);
		}
		return integerVal;
	}

	/**
	 * Used to get the string to long value.
	 * 
	 * @param value
	 * @return {@link Long}
	 */
	public static long toLong(String value) {
		long integerVal = 0;
		if (isNumeric(value)) {
			integerVal = Long.parseLong(value);
		}
		return integerVal;
	}

	/**
	 * Used to check the string objects contains numeric value.
	 * 
	 * @param values
	 * @return {@link Boolean}
	 */
	public static boolean isNumeric(String... values) {
		if (values == null) {
			return false;
		} else {
			for (String str : values) {
				if (null != str && !NumberUtils.isCreatable(str.trim())) {
					return false;
				}
			}
		}
		return true;
	}

	public static List<String> getListOfStringValues(String commaSepratedValues) {
		List<String> listOfValues = null;
		if (!isNull(commaSepratedValues)) {
			listOfValues = Arrays.asList(commaSepratedValues.split("\\s*,\\s*"));
		}
		return listOfValues;
	}

	/**
	 * Used to get stack trace string
	 * 
	 * @param Throwable
	 * @return {@link String}
	 */
	public static String getStackTrace(Throwable th) {
		return ExceptionUtils.getStackTrace(th);
	}

	/**
	 * Used to get exception short message
	 * 
	 * @param Throwable
	 * @return {@link String}
	 */
	public static String getMessage(Throwable th) {
		return ExceptionUtils.getStackTrace(th);
	}

	/**
	 * To get rounded value with precision
	 * 
	 * @param value     i.e., 3.4343333
	 * @param precision i.e., 3
	 * @return 3.434
	 */
	public static double getRoundedValue(double value, int precision) {
		try {
			int scale = (int) Math.pow(RANGE_TEN, precision);
			return (double) Math.round(value * scale) / scale;
		} catch (Exception ex) {
			logger.error("getRoundedValue ", ex);
			return value;
		}
	}

	/**
	 * To get rounded value with precision
	 * 
	 * @param value i.e., 3.4343333
	 * @return 3.4
	 */
	public static double getRoundedValue(double value) {
		return getRoundedValue(value, 1);
	}

	public static String getCommaSepratedValues(List<Object> listOfValues) {
		return !isNull(listOfValues)
				? listOfValues.stream().map(Object::toString).collect(Collectors.joining(","))
				: "";
	}

	public static String getCurrentTimeStamp() {
		return new SimpleDateFormat(CommonConstants.CURRENT_TIMESTAMP_DATE_FORMAT).format(new Date());
	}

	public static void printRunTimeMemory() {

		Runtime runtime = Runtime.getRuntime();
		final NumberFormat format = NumberFormat.getInstance();
		final long maxMemory = runtime.maxMemory();
		final long allocatedMemory = runtime.totalMemory();
		final long freeMemory = runtime.freeMemory();
		final long mb = 1024l * 1024;
		final String mega = "MB";
		final String freeMem = String.format("Free memory: %s %s", format.format(freeMemory / mb), mega);
		final String allocMem =  String.format("Allocated memory: %s %s", 
				format.format(allocatedMemory / mb) , mega);
		final String maxMem = String.format("Max memory: %s %s " , format.format(maxMemory / mb) , mega);
		final String totalMem = String.format("Total free memory: %s %s " , 
				format.format((freeMemory + (maxMemory - allocatedMemory)) / mb) , mega);
		logger.info("========================== Memory Info ==========================");
		logger.info(freeMem);
		logger.info(allocMem);
		logger.info(maxMem);
		logger.info(totalMem);
		logger.info("=================================================================\n");

	}

	/**
	 * Which is used to generate 20chars unique code
	 * 
	 * @param uniqueString - Input string can be a sentence or space separated
	 *                     string
	 * @return {@link String} - unique code
	 */
	public static String getUniqueRandomCode(String uniqueString) {
		StringBuilder sb = new StringBuilder();
		String[] strArr = StringUtils.split(uniqueString);
		if (strArr != null && strArr.length > 0) {
			Arrays.stream(strArr).forEach(str -> {
				if (str != null) {
					sb.append((str.trim().charAt(0) + "").toUpperCase());
				}
			});
		}

		String code = sb.toString();
		if (code.length() > RANGE_TEN) {
			code = code.substring(0, RANGE_TEN);
		}
		int randomLen = RANGE_SIXTEEN - code.length() - 1;
		if (randomLen > 0) {
			code +=  RandomStringUtils.randomNumeric(randomLen);
		}
		return code;
	}

	/**
	 * Which is used to generate 15chars unique code
	 * 
	 * @param uniqueString - Input string can be a sentence or space separated
	 *                     string
	 * @return {@link String} - unique code
	 */
	public static String getQuestionUniqueRandomCode(String uniqueString) {
		StringBuilder sb = new StringBuilder();
		String[] strArr = StringUtils.split(uniqueString);
		if (strArr != null && strArr.length > 0) {
			Arrays.stream(strArr).forEach(str -> {
				if (str != null) {
					sb.append((str.trim().charAt(0) + "").toUpperCase());
				}
			});
		}
		String code = "KM-" + sb.toString();
		if (code.length() > RANGE_EIGHT) {
			code = code.substring(0, RANGE_EIGHT);
		}
		int randomLen = RANGE_SIXTEEN - code.length() - 1;
		if (randomLen > 0) {
			code +=  RandomStringUtils.randomNumeric(randomLen);
		}
		return code;
	}

	
	/**
	 * <p>
	 * Used to get app Id for given request.
	 * </p>
	 * 
	 * @param request - httpRequest
	 * @return appId - If appId present then appId or else throws Exception.
	 * @throws CustomValidationException
	 */
	public static Integer getAppId(HttpServletRequest request) throws CustomValidationException {
		String strAppId = request.getHeader("App-Id");
		Integer result;
		if (strAppId == null) {
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2002);
		}
		try {
			result = Integer.parseInt(strAppId);
		} catch (NumberFormatException ne) {
			logger.error("Exception on getAppId", ne);
			throw new CustomValidationException(ErrorCode.OFIS_ATSOURCE_2002);
		}
		return result;
	}

	public static Date convertToStringToDate(String stringDate) {
		Date date = null;
		if (stringDate != null) {
			try {
				SimpleDateFormat format = new SimpleDateFormat(AtSourceConstants.DATE_FORMAT_DD_MM_YYYY);
				date = format.parse(stringDate);
			} catch (ParseException e) {
				logger.error("Date parsing issue");
			}
		}

		return date;
	}

	public static String listToString(List<Long> list) {
		return list.stream().map(Object::toString).collect(Collectors.joining(","));
	}

	public static Pageable getPageRequest(Integer pageNo, Integer size, String orderBy, String direction) {
		Sort sort = direction.equalsIgnoreCase(CommonConstants.STRING_DESC) ? Sort.by(orderBy).descending()
				: Sort.by(orderBy).ascending();
		return PageRequest.of(pageNo - 1, size, sort);
	}
	
	//OW-1822 Changes
	public static boolean isEmpty(Object str) {
		return str == null || "".equals(str);
	}
}
