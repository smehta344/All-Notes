/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * <p>
 * Persist class for atsource survey answers.
 * </p>
 * 
 * @author Rajasankar
 */
@Entity
@Table(name = "atsource_surveyanswer")
public class AtSourceSurveyAnswer extends BaseModel implements Serializable {

	public AtSourceSurveyAnswer(){
		// default constructor
	}
	
	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "question_id")
	private AtsourceSurveyquestion atsourceSurveyquestion;

	@Column(name = "farmer_group_id")
	private Integer farmerGroupId;

	@Column(name = "submittedmodule_id")
	private Integer submittedmoduleId;

	@Column(name = "answer_boolean")
	private Boolean answerBoolean;

	@Temporal(TemporalType.DATE)
	@Column(name = "answer_date")
	private Date answerDate;

	@Column(name = "answer_decimal")
	private BigDecimal answerDecimal;

	@Column(name = "answer_int")
	private Integer answerInt;

	@Lob
	@Column(name = "answer_text")
	private String answerText;

	@Column(name = "app_id")
	private Integer appId;

	@Column(name = "answer")
	private String answer;

	public Boolean getAnswerBoolean() {
		return this.answerBoolean;
	}

	public void setAnswerBoolean(Boolean answerBoolean) {
		this.answerBoolean = answerBoolean;
	}

	public Date getAnswerDate() {
		return this.answerDate;
	}

	public void setAnswerDate(Date answerDate) {
		this.answerDate = answerDate;
	}

	public BigDecimal getAnswerDecimal() {
		return this.answerDecimal;
	}

	public void setAnswerDecimal(BigDecimal answerDecimal) {
		this.answerDecimal = answerDecimal;
	}

	public Integer getAnswerInt() {
		return this.answerInt;
	}

	public void setAnswerInt(Integer answerInt) {
		this.answerInt = answerInt;
	}

	public String getAnswerText() {
		return this.answerText;
	}

	public void setAnswerText(String answerText) {
		this.answerText = answerText;
	}

	public Integer getFarmerGroupId() {
		return this.farmerGroupId;
	}

	public void setFarmerGroupId(Integer farmerGroupId) {
		this.farmerGroupId = farmerGroupId;
	}

	public Integer getSubmittedmoduleId() {
		return this.submittedmoduleId;
	}

	public void setSubmittedmoduleId(Integer submittedmoduleId) {
		this.submittedmoduleId = submittedmoduleId;
	}

	public AtsourceSurveyquestion getAtsourceSurveyquestion() {
		return this.atsourceSurveyquestion;
	}

	public void setAtsourceSurveyquestion(AtsourceSurveyquestion atsourceSurveyquestion) {
		this.atsourceSurveyquestion = atsourceSurveyquestion;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
}
