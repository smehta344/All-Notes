/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.olam.ofis.atsource.dto.AtsourceSurveyReviewDto;
import com.olam.ofis.atsource.dto.FarmerGroupProjectionDto;
import com.olam.ofis.atsource.dto.FarmerModuleProjectionDto;
import com.olam.ofis.atsource.dto.KmFarmerGroupIdDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.service.AtSourceSurveyReviewService;
import com.olam.ofis.atsource.util.AtSourceConstants;
import com.olam.ofis.atsource.util.PaginationResult;

/**
 * <p>
 * CRUD operation for atsource survey review.
 * </p>
 * 
 * @author Mahroof
 */
@RestController
@RequestMapping(path = "/atsource/reviews")
public class AtSourceSurveyReviewController extends BaseController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private AtSourceSurveyReviewService atSourceSurveyReviewService;

	@PostMapping("/")
	public ResponseEntity<MessageDto> saveAtsourceSurveyReview(@RequestBody AtsourceSurveyReviewDto surveyReviewDto)
			throws CustomValidationException {
		logger.debug("Save atsource survey review response, approval/rejection flow");
		MessageDto response = atSourceSurveyReviewService.saveAtsourceSurveyReviewResponses(surveyReviewDto,
				getUser().getUserId());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PutMapping("/{reviewId}")
	public ResponseEntity<MessageDto> updateAtsourceSurveyReview(@PathVariable Long reviewId,
			@RequestBody AtsourceSurveyReviewDto surveyReviewDto) throws CustomValidationException {
		logger.debug("Update atsource survey review response, approval/rejection flow");
		MessageDto response = atSourceSurveyReviewService.updateAtsourceSurveyReviewResponses(reviewId, surveyReviewDto,
				getUser().getUserId());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping("/getAllKmCodes")
	public ResponseEntity<List<String>> getAllKmCodes() {
		logger.debug("Get all KM Codes for Survey Review");
		List<String> response = atSourceSurveyReviewService.getAllKmCodes();
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * <p>
	 * get all farmer groups for km id controller
	 * </p>
	 * 
	 * @param kmId
	 * @param request
	 * @return ResponseEntity<List<FarmerGroupProjectionDto>>
	 * @throws CustomValidationException
	 */
	@GetMapping("/getAllFarmerGroupsByKmId")
	public ResponseEntity<List<FarmerGroupProjectionDto>> getAllFarmerGroupsByKmId(
						@RequestParam String kmId) throws CustomValidationException {
		logger.info("Get all farmer groups by km id started");
		try {
			return new ResponseEntity<>(atSourceSurveyReviewService.getAllFarmerGroupsByKmId(kmId, getUser().getUserId()),
					HttpStatus.OK);
		} catch (Exception e) {
			// Exception occurred
			logger.debug(String.format("Exception occured in getAllFarmerGroupsByKmId. %s", e.getMessage()));
		}
		return null;
	}

	@PutMapping("/saveSurveyReview")
	public ResponseEntity<MessageDto> saveSurveyReviewByKmIdAndFgId(@RequestBody KmFarmerGroupIdDto kmFarmerGroupIdDto)
			throws CustomValidationException {
		logger.debug("Save atsource survey review, approval/rejection flow");
		MessageDto response = atSourceSurveyReviewService.saveSurveyReviewByKmIdAndFgId(kmFarmerGroupIdDto,
				getUser().getUserId());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PutMapping("/submitSurveyReview")
	public ResponseEntity<MessageDto> submitSurveyReviewByKmIdAndFgId(
			@RequestBody KmFarmerGroupIdDto kmFarmerGroupIdDto) throws CustomValidationException {
		logger.debug("Submit atsource survey review, approval/rejection flow");
		MessageDto response = atSourceSurveyReviewService.submitSurveyReviewByKmIdAndFgId(kmFarmerGroupIdDto,
				getUser().getUserId());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * <p>
	 * farmer module controller
	 * </p>
	 * 
	 * @param kmId
	 * @param farmerGroupId
	 * @return ResponseEntity<List<FarmerModuleProjectionDto>>
	 * @throws CustomValidationException
	 */
	@GetMapping("/getFarmerModule")
	public ResponseEntity<PaginationResult<FarmerModuleProjectionDto>> getFarmerModule(@RequestParam String kmId,
			@RequestParam String farmerGroupId, @RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "20") Integer size,
			@RequestParam(defaultValue="moduleName") String sort,
			@RequestParam(defaultValue="asc") String direction) throws CustomValidationException

	{
		logger.info("Get all farmer module started");
		try {
			return new ResponseEntity<>(atSourceSurveyReviewService.getFarmerModule(
							kmId, farmerGroupId,page,size,sort,direction),HttpStatus.OK);
		} catch (CustomValidationException e) {
			// Exception occurred
			logger.debug(String.format("CustomValidationException occured in getFarmerModule. %s", e.getMessage()));
		} catch (Exception e) {
			// Exception occurred

			logger.debug(String.format("Exception occured in getFarmerModule. %s", e.getMessage()));
		}
		return null;
	}
	/***
	 * API exposed to AtSource
	 * receive the review of AtSource categorize to BU Survey / Training Pillar / Enumerator Survey
	 */
	@PostMapping("/all")
	public ResponseEntity<List<AtsourceSurveyReviewDto>> categorizeAndSaveAtSourceReviews
	(@RequestBody List<AtsourceSurveyReviewDto> atsourceSurveyReviewDtoList,
			@RequestHeader(name = "App-Id") Integer appId,HttpServletRequest httpServletRequest)
			throws CustomValidationException{
		String token = httpServletRequest.getHeader(AtSourceConstants.AUTHORIZATION);
		
		return new ResponseEntity<>(atSourceSurveyReviewService.categorizeAndSaveAtSourceReviews
				(atsourceSurveyReviewDtoList,getUser().getUserId(),appId,token), HttpStatus.OK);
	}
}
