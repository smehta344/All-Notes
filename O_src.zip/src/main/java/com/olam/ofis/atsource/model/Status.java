/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.model;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonValue;

@JsonFormat(shape=JsonFormat.Shape.OBJECT)
public enum Status {

	SAVED(0), SUBMTTED(1), REJECTED(2), APPROVED(3);

	Status(int c) {
		this.code = c;
	}

	int code;

	@JsonValue
	public int getCode() {
		return this.code;
	}

	@Override
	public String toString() {
		return String.valueOf(this.code);
	}

	@JsonCreator
	public static Status fromCode(int code) {
		for (Status st : values()) {
			if (code == st.getCode()) {
				return st;
			}
		}
		throw new IllegalArgumentException(
				"Unknown enum type " + code + ", Allowed values are " + Arrays.toString(values()));
	}

}