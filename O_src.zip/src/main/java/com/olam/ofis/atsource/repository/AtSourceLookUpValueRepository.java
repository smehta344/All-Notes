/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.olam.ofis.atsource.dto.AtsourceSurveyLookupvalueQueryResult;
import com.olam.ofis.atsource.model.AtsourceSurveylookupvalue;

/**
 * Created by Ideas2it-Karthick on 29/3/19.
 */
public interface AtSourceLookUpValueRepository extends JpaRepository<AtsourceSurveylookupvalue, Integer> {

	@Query("SELECT l as atsourcelookupValueResult, q as question FROM AtsourceSurveylookupvalue l join " +
			"AtsourceSurveyquestion q  on l.question = q.id")
	Page<AtsourceSurveyLookupvalueQueryResult> findAllActiveLookupValue(Pageable pageable);

	@Query("select lv from AtsourceSurveylookupvalue lv where lv.id = :lookupValueId")
	AtsourceSurveylookupvalue getLookUpValueById(@Param("lookupValueId") Integer lookupValueId);

	@Query("SELECT q FROM AtsourceSurveylookupvalue q WHERE q.active = 1")
	List<AtsourceSurveylookupvalue> findByActive();
}
