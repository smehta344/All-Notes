/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.olam.ofis.atsource.dto.FarmerGroupResult;
import com.olam.ofis.atsource.model.Region;

public interface RegionRepository extends JpaRepository<Region, Serializable> {

	@Query("SELECT fg.farmerGroupId as farmerGroupId,fg.name as name FROM Region as region "
			+ "join Country as country on region.countryId=country.countryId and region.id in :moduleAssignmentIds "
			+ "join FarmerGroup as fg on fg.countryId = country.countryId group by fg.farmerGroupId")
	List<FarmerGroupResult> getFarmerGroupsByRegionIds(@Param("moduleAssignmentIds") List<Long> moduleAssignmentIds);

}
