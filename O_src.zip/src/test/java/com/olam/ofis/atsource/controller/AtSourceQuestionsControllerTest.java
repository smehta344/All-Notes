/*******************************************************************************
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 *******************************************************************************/

package com.olam.ofis.atsource.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.gson.Gson;
import com.olam.ofis.atsource.dto.AtSourceQuestionDto;
import com.olam.ofis.atsource.dto.AtSourceQuestionMinMaxDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.SubModuleDto;
import com.olam.ofis.atsource.dto.UserDTO;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.service.AtSourceQuestionsService;
import com.olam.ofis.atsource.util.PaginationResult;
import com.olam.ofis.atsource.util.RetrieveUserData;

/**
 * Class - AtSourceQuestionsControllerTest
 *
 * @author Mohammed Mahroof
 *
 */
public class AtSourceQuestionsControllerTest {

    private MockMvc mockMvc;

    @Mock
    AtSourceQuestionsService atSourceQuestionsService;

	@Mock
	private RetrieveUserData retrieveUserData;

    @InjectMocks
	private AtSourceQuestionsController atSourceQuestionsController;
	
    @Mock
	private ModelMapper modelMapper;
    
    @Mock
	private HttpServletRequest request;
    
    private String tokenString
            = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJsYW5ndWFnZUlTT0NvZGUiOiJlbiIsInRpbWV6b25lSXNvQ29kZSI6IldJQiIsI";

    @Before
   	public void init() {
   		MockitoAnnotations.initMocks(this);
   		this.mockMvc = MockMvcBuilders.standaloneSetup(atSourceQuestionsController).build();
   	}
    
    @Test
    public void getAllAtsourceQuestionsTest() throws Exception {
        PaginationResult<AtSourceQuestionDto> paginationResult = new PaginationResult<>();
        Mockito.when(atSourceQuestionsService.getAllAtsourceQuestions(anyInt(), anyInt(), anyString(), anyString()))
                .thenReturn(paginationResult);
        this.mockMvc.perform(
                get("/atsource/questions/getAllAtsourceQuestions")
                    .header("Authorization", "Bearer " + tokenString)
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void saveQuestionTest() throws CustomValidationException, Exception {
        AtSourceQuestionDto atSourceQuestionDto = new AtSourceQuestionDto();
        MessageDto messageDto = new MessageDto();
        UserDTO userDTO = mock(UserDTO.class);
        when(userDTO.getUserId()).thenReturn(629L); 
        when(retrieveUserData.getUserData(any(HttpServletRequest.class))).thenReturn(userDTO);
        when(request.getHeader(Mockito.anyString())).thenReturn("1"); 
		
//        Mockito.when(retrieveUserData.getUserData(any())).thenReturn(userDTO);
        Mockito.when(atSourceQuestionsService.saveQuestion(anyLong(), any(AtSourceQuestionDto.class)))
                .thenReturn(messageDto); 
        this.mockMvc.perform(  
                post("/atsource/questions/save")
                     .header("Authorization", "Bearer " + tokenString).header("App-Id", 1)
                     .contentType(MediaType.APPLICATION_JSON).content(new Gson().toJson(atSourceQuestionDto)))
                .andExpect(status().isCreated());
    }

    @Test
    public void getQuestionTest() throws Exception {
        AtSourceQuestionDto atSourceQuestionDto = new AtSourceQuestionDto();
        Mockito.when(atSourceQuestionsService.getQuestionById(anyInt())).thenReturn(atSourceQuestionDto);
        this.mockMvc.perform(
                get("/atsource/questions/edit/1")
                    .header("Authorization", "Bearer " + tokenString)
                    .contentType(MediaType.APPLICATION_JSON)).andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    public void getAllAtsourceSubModulesTest() throws Exception {
        List<SubModuleDto> subModuleDtos = new ArrayList<>();
        Mockito.when(atSourceQuestionsService.getAllSubModules()).thenReturn(subModuleDtos);
        this.mockMvc.perform(
                get("/atsource/questions/getAllAtsourceSubModules")
                    .header("Authorization", "Bearer " + tokenString)
                    .contentType(MediaType.APPLICATION_JSON)).andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    public void updateQuestionMinMaxValuesTest() throws CustomValidationException, Exception {
        AtSourceQuestionMinMaxDto atSourceQuestionMinMaxDto = new AtSourceQuestionMinMaxDto();
        atSourceQuestionMinMaxDto.setKmCode("km-01");
        long temp = 1;
        atSourceQuestionMinMaxDto.setMaxValue(temp);
        atSourceQuestionMinMaxDto.setMinValue(temp);
        MessageDto messageDto = new MessageDto();
        UserDTO userDTO = mock(UserDTO.class);
        when(retrieveUserData.getUserData(any(HttpServletRequest.class))).thenReturn(userDTO);
		when(userDTO.getUserId()).thenReturn(629L);
		
		when(modelMapper.map(Mockito.any(),Mockito.any()))
		.thenReturn(getMockAtSourceQuestionDto());
		 when(request.getHeader(Mockito.anyString())).thenReturn("1"); 
        Mockito.when(atSourceQuestionsService.updateQuestionMinMaxValues(anyLong(), any(AtSourceQuestionDto.class)))
                .thenReturn(messageDto);
        this.mockMvc.perform(
                put("/atsource/questions/updateMinMaxValues")
                     .header("Authorization", "Bearer " + tokenString).header("App-Id", 1)
                     .contentType(MediaType.APPLICATION_JSON).content(new Gson().toJson(atSourceQuestionMinMaxDto)))
                .andExpect(status().isCreated());
    }
    private AtSourceQuestionDto getMockAtSourceQuestionDto() {
    	AtSourceQuestionDto dto = new AtSourceQuestionDto();
    	dto.setKmCode("km-01");
    	dto.setMaxValue(50L);
    	return dto;
    }

}