/*******************************************************************************
 * Copyright (c) 2019 OLAM Limited
 * 
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited.
 ******************************************************************************/
package com.olam.ofis.atsource;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.olam.ofis.atsource.dto.AtSourceQuestionDto;
import com.olam.ofis.atsource.dto.AtSourceQuestionMinMaxDto;
import com.olam.ofis.atsource.dto.AtSourceSurveyAnswerDto;
import com.olam.ofis.atsource.dto.AtsourceModuleAssignmentDto;
import com.olam.ofis.atsource.dto.AtsourceSubmittedmoduleDto;
import com.olam.ofis.atsource.dto.AtsourceSurveyLookupvalueDto;
import com.olam.ofis.atsource.dto.AtsourceSurveyResponseDto;
import com.olam.ofis.atsource.dto.AtsourceSurveyReviewDto;
import com.olam.ofis.atsource.dto.BaseDTO;
import com.olam.ofis.atsource.dto.FarmerGroupDto;
import com.olam.ofis.atsource.dto.KmFarmerGroupIdDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.ModuleAssignmentDto;
import com.olam.ofis.atsource.dto.ModuleDto;
import com.olam.ofis.atsource.dto.SubModuleDto;
import com.olam.ofis.atsource.dto.UserDTO;
import com.olam.ofis.atsource.exception.ErrorCode;
import com.olam.ofis.atsource.exception.ErrorMessage;
import com.olam.ofis.atsource.exception.ModelNotFoundException;
import com.olam.ofis.atsource.exception.Response;
import com.olam.ofis.atsource.model.AtSourceSurveyAnswer;
import com.olam.ofis.atsource.model.AtsourceModuleAssignment;
import com.olam.ofis.atsource.model.AtsourceModuleAssignmentData;
import com.olam.ofis.atsource.model.AtsourceSubmittedmodule;
import com.olam.ofis.atsource.model.AtsourceSurveyReview;
import com.olam.ofis.atsource.model.AtsourceSurveylookupvalue;
import com.olam.ofis.atsource.model.AtsourceSurveyquestion;
import com.olam.ofis.atsource.model.AtsourceTraining;
import com.olam.ofis.atsource.model.BaseModel;
import com.olam.ofis.atsource.model.Country;
import com.olam.ofis.atsource.model.CountryUser;
import com.olam.ofis.atsource.model.DataType;
import com.olam.ofis.atsource.model.District;
import com.olam.ofis.atsource.model.FarmerGroup;
import com.olam.ofis.atsource.model.FarmerGroupUser;
import com.olam.ofis.atsource.model.KmQuestionmapping;
import com.olam.ofis.atsource.model.Module;
import com.olam.ofis.atsource.model.Partner;
import com.olam.ofis.atsource.model.PartnerUser;
import com.olam.ofis.atsource.model.Place;
import com.olam.ofis.atsource.model.Product;
import com.olam.ofis.atsource.model.ProductUser;
import com.olam.ofis.atsource.model.Programme;
import com.olam.ofis.atsource.model.Question;
import com.olam.ofis.atsource.model.Region;
import com.olam.ofis.atsource.model.Section;
import com.olam.ofis.atsource.model.SubModule;
import com.olam.ofis.atsource.model.TrainingPillar;
import com.olam.ofis.atsource.model.User;
import com.olam.ofis.atsource.model.UserCountry;
import com.olam.ofis.atsource.util.AtSourceConstants;
import com.olam.ofis.atsource.util.TestObjectService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AtSourceApplicationTests {

	//@Test
	public void contextLoads() {
	}

	@Test
	public void testDto() {
		Map<Class<?>, Object> classNameMap = new HashMap<>();
		classNameMap.put(UserDTO.class, new UserDTO());
		classNameMap.put(AtSourceQuestionMinMaxDto.class, new AtSourceQuestionMinMaxDto());
		classNameMap.put(AtsourceSurveyResponseDto.class, new AtsourceSurveyResponseDto());
		classNameMap.put(FarmerGroupDto.class, new FarmerGroupDto());
		classNameMap.put(ModuleAssignmentDto.class, new ModuleAssignmentDto());
		classNameMap.put(ModuleDto.class, new ModuleDto());
		classNameMap.put(AtsourceSubmittedmoduleDto.class, new AtsourceSubmittedmoduleDto());
		classNameMap.put(MessageDto.class, new MessageDto());
		classNameMap.put(SubModuleDto.class, new SubModuleDto());
		classNameMap.put(AtsourceModuleAssignmentDto.class, new AtsourceModuleAssignmentDto());
		classNameMap.put(BaseDTO.class, new BaseDTO());
		classNameMap.put(AtSourceQuestionDto.class, new AtSourceQuestionDto());
		classNameMap.put(AtsourceSurveyLookupvalueDto.class, new AtsourceSurveyLookupvalueDto());
		classNameMap.put(AtsourceSurveyReviewDto.class, new AtsourceSurveyReviewDto());
		classNameMap.put(KmFarmerGroupIdDto.class, new KmFarmerGroupIdDto());
		classNameMap.put(AtSourceSurveyAnswerDto.class, new AtSourceSurveyAnswerDto());
		Assert.assertTrue("Success", TestObjectService.testObject(classNameMap));
	}

	@Test
	public void testModel() {
		Map<Class<?>, Object> classNameMap = new HashMap<>();
		classNameMap.put(CountryUser.class, new CountryUser());
		classNameMap.put(FarmerGroupUser.class, new FarmerGroupUser());
		classNameMap.put(Partner.class, new Partner());
		classNameMap.put(PartnerUser.class, new PartnerUser());
		classNameMap.put(Product.class, new Product());
		classNameMap.put(ProductUser.class, new ProductUser());
		classNameMap.put(Programme.class, new Programme());
		classNameMap.put(Section.class, new Section());
		classNameMap.put(User.class, new User());
		classNameMap.put(AtsourceTraining.class, new AtsourceTraining());
		classNameMap.put(AtsourceSubmittedmodule.class, new AtsourceSubmittedmodule());
		classNameMap.put(Region.class, new Region());
		classNameMap.put(Place.class, new Place());
		classNameMap.put(District.class, new District());
		classNameMap.put(Country.class, new Country());
		classNameMap.put(FarmerGroup.class, new FarmerGroup());
		classNameMap.put(Module.class, new Module());
		classNameMap.put(DataType.class, new DataType());
		classNameMap.put(BaseModel.class, new BaseModel());
		classNameMap.put(SubModule.class, new SubModule());
		classNameMap.put(AtsourceModuleAssignment.class, new AtsourceModuleAssignment());
		classNameMap.put(AtSourceSurveyAnswer.class, new AtSourceSurveyAnswer());
		classNameMap.put(AtsourceSurveyquestion.class, new AtsourceSurveyquestion());
		classNameMap.put(AtsourceSurveylookupvalue.class, new AtsourceSurveylookupvalue());
		classNameMap.put(AtsourceSurveyReview.class, new AtsourceSurveyReview());
		classNameMap.put(KmQuestionmapping.class, new KmQuestionmapping());
		classNameMap.put(TrainingPillar.class, new TrainingPillar());
		classNameMap.put(UserCountry.class, new UserCountry());
		classNameMap.put(Question.class, new Question());
		classNameMap.put(AtsourceModuleAssignmentData.class, new AtsourceModuleAssignmentData(
				Mockito.anyInt(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()));
		Assert.assertTrue("Success", TestObjectService.testObject(classNameMap));
	}
	@Test
	public void testConstants() {
		Map<Class<?>, Object> classNameMap = new HashMap<>();
		classNameMap.put(AtSourceConstants.class, new AtSourceConstants());
		classNameMap.put(ErrorMessage.class, new ErrorMessage());
		classNameMap.put(Response.class, new Response());
		classNameMap.put(ModelNotFoundException.class, new ModelNotFoundException(ErrorCode.OFIS_ATSOURCE_2001));
		Assert.assertTrue("Success", TestObjectService.testObject(classNameMap));
	}
}
