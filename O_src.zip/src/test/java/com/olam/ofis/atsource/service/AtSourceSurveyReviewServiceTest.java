/*******************************************************************************
 * Copyright (c) 2019 OLAM Limited
 * 
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited.
 ******************************************************************************/
package com.olam.ofis.atsource.service;

import com.olam.ofis.atsource.AtSourceApplication;
import com.olam.ofis.atsource.client.ITrainingPillarClient;
import com.olam.ofis.atsource.dto.AtsourceSurveyReviewDto;
import com.olam.ofis.atsource.dto.FarmerGroupProjectionDto;
import com.olam.ofis.atsource.dto.KmFarmerGroupIdDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.exception.ErrorCode;
import com.olam.ofis.atsource.model.AtsourceSurveyReview;
import com.olam.ofis.atsource.model.Status;
import com.olam.ofis.atsource.repository.AtSourceSubmittedmoduleRepository;
import com.olam.ofis.atsource.repository.AtSourceSurveyQuestionRepository;
import com.olam.ofis.atsource.repository.AtSourceSurveyReviewRepository;
import com.olam.ofis.atsource.repository.KmQuestionmappingRepository;
import com.olam.ofis.atsource.repository.TrainingPillarRepository;
import com.olam.ofis.atsource.service.impl.AtSourceSurveyAnswerServiceImpl;
import com.olam.ofis.atsource.service.impl.AtSourceSurveyReviewServiceImpl;
import com.olam.ofis.atsource.util.AtSourceConstants;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AtSourceApplication.class)
public class AtSourceSurveyReviewServiceTest {

	@Autowired
	private AtSourceSurveyReviewServiceImpl atSourceSurveyReviewServiceImpl;
	@Autowired
	AtSourceSurveyAnswerServiceImpl atSourceSurveyAnswerService;
	
	@MockBean
	private AtSourceSurveyReviewRepository atSourceSurveyReviewRepository;

	@MockBean
	TrainingPillarRepository trainingPillarRepository;
	@MockBean
	AtSourceSurveyQuestionRepository atSourceSurveyQuestionRepository;
	@MockBean
	KmQuestionmappingRepository kmQuestionmappingRepository;
	@MockBean
	ITrainingPillarClient iTrainingPillarClient;
	@MockBean
	AtSourceSubmittedmoduleRepository atSourceSubmittedmoduleRepository;
	
	
	private static final long USER_ID = 1;

	public void contextLoads() {
	}

	@Test
	public void testGetAllKmCodes() {
		Mockito.when(atSourceSurveyReviewRepository.getAllKmCodes()).thenReturn(getMockKMCodes());

		List<String> kmCodeList = atSourceSurveyReviewServiceImpl.getAllKmCodes();
		Assert.assertTrue(AtSourceConstants.SUCCESS, kmCodeList.size() >= 0 );
	}

	private List<String> getMockKMCodes() {
		List<String> kmCodeList = new ArrayList<String>();
		kmCodeList.add("KM-1");
		return kmCodeList;
	}

	@Test
	public void saveSurveyReviewByKmIdAndFgIdTest() throws CustomValidationException {

		/**
		 * Scenario 1 - Survey review is null
		 */
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(null);
		try {
			atSourceSurveyReviewServiceImpl.saveSurveyReviewByKmIdAndFgId(
					getMockKmFarmerGroupIdDto(), USER_ID);
		} catch (CustomValidationException e) {
			Assert.assertTrue(AtSourceConstants.SUCCESS, e.getMessage().equalsIgnoreCase(
					ErrorCode.OFIS_ATSOURCE_2041.getMessage()));
		}

		/**
		 * Scenario 2 - Survey review is already approved
		 */
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(getMockApprovedSurveyReview());
		try {
			atSourceSurveyReviewServiceImpl.saveSurveyReviewByKmIdAndFgId(
					getMockKmFarmerGroupIdDto(), USER_ID);
		} catch (CustomValidationException e) {
			Assert.assertTrue(AtSourceConstants.SUCCESS, e.getMessage().equalsIgnoreCase(
					ErrorCode.OFIS_ATSOURCE_2040.getMessage()));
		}

		/**
		 * Scenario 3 - Survey review is already submitted
		 */
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(getMockSubmittedSurveyReview());
		try {
			atSourceSurveyReviewServiceImpl.saveSurveyReviewByKmIdAndFgId(
					getMockKmFarmerGroupIdDto(), USER_ID);
		} catch (CustomValidationException e) {
			Assert.assertTrue(AtSourceConstants.SUCCESS, e.getMessage().equalsIgnoreCase(
					ErrorCode.OFIS_ATSOURCE_2042.getMessage()));
		}

		/**
		 * Scenario 4 - Survey review is rejected
		 */
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(getMockRejectedSurveyReview());
		Mockito.when(atSourceSurveyReviewRepository.save(Mockito.any(AtsourceSurveyReview.class))).thenReturn(null);
		MessageDto messageDto = atSourceSurveyReviewServiceImpl.saveSurveyReviewByKmIdAndFgId(
				getMockKmFarmerGroupIdDto(), USER_ID);
		Assert.assertTrue(AtSourceConstants.SUCCESS, AtSourceConstants.SUCCESS.equals(messageDto.getMessage()));
	}

	@Test
	public void submitSurveyReviewByKmIdAndFgIdTest() throws CustomValidationException {

		/**
		 * Scenario 1 - Survey review is null
		 */
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(null);
		try {
			atSourceSurveyReviewServiceImpl.submitSurveyReviewByKmIdAndFgId(
					getMockKmFarmerGroupIdDto(), USER_ID);
		} catch (CustomValidationException e) {
			Assert.assertTrue(AtSourceConstants.SUCCESS, e.getMessage().equalsIgnoreCase(
					ErrorCode.OFIS_ATSOURCE_2041.getMessage()));
		}

		/**
		 * Scenario 2 - Survey review is already approved
		 */
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(getMockApprovedSurveyReview());
		try {
			atSourceSurveyReviewServiceImpl.submitSurveyReviewByKmIdAndFgId(
					getMockKmFarmerGroupIdDto(), USER_ID);
		} catch (CustomValidationException e) {
			Assert.assertTrue(AtSourceConstants.SUCCESS, e.getMessage().equalsIgnoreCase(
					ErrorCode.OFIS_ATSOURCE_2040.getMessage()));
		}

		/**
		 * Scenario 3 - Survey review is already submitted
		 */
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(getMockSubmittedSurveyReview());
		try {
			atSourceSurveyReviewServiceImpl.submitSurveyReviewByKmIdAndFgId(
					getMockKmFarmerGroupIdDto(), USER_ID);
		} catch (CustomValidationException e) {
			Assert.assertTrue(AtSourceConstants.SUCCESS, e.getMessage().equalsIgnoreCase(
					ErrorCode.OFIS_ATSOURCE_2042.getMessage()));
		}

		/**
		 * Scenario 4 - Survey review is rejected
		 */
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(getMockSavedSurveyReview());
		Mockito.when(atSourceSurveyReviewRepository.save(Mockito.any(AtsourceSurveyReview.class))).thenReturn(null);
		MessageDto messageDto = atSourceSurveyReviewServiceImpl.submitSurveyReviewByKmIdAndFgId(
				getMockKmFarmerGroupIdDto(), USER_ID);
		Assert.assertTrue(AtSourceConstants.SUCCESS, AtSourceConstants.SUCCESS.equals(messageDto.getMessage()));
	}

	private KmFarmerGroupIdDto getMockKmFarmerGroupIdDto() {
		KmFarmerGroupIdDto kmFarmerGroupIdDto = new KmFarmerGroupIdDto();
		kmFarmerGroupIdDto.setKmId("KM-1");
		kmFarmerGroupIdDto.setFarmerGroupId(1);
		return kmFarmerGroupIdDto;
	}

	private AtsourceSurveyReview getMockApprovedSurveyReview() {
		AtsourceSurveyReview surveyReview = new AtsourceSurveyReview();
		surveyReview.setStatus(Status.APPROVED);
		return surveyReview;
	}

	private AtsourceSurveyReview getMockSubmittedSurveyReview() {
		AtsourceSurveyReview surveyReview = new AtsourceSurveyReview();
		surveyReview.setStatus(Status.SUBMTTED);
		return surveyReview;
	}

	private AtsourceSurveyReview getMockRejectedSurveyReview() {
		AtsourceSurveyReview surveyReview = new AtsourceSurveyReview();
		surveyReview.setStatus(Status.REJECTED);
		return surveyReview;
	}

	private AtsourceSurveyReview getMockSavedSurveyReview() {
		AtsourceSurveyReview surveyReview = new AtsourceSurveyReview();
		surveyReview.setStatus(Status.SAVED);
		return surveyReview;
	}

	@Test
	public void saveAtsourceSurveyReviewResponsesTest() throws CustomValidationException {

		/**
		 * Scenario 1 - Survey review already approved
		 */
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(getMockApprovedSurveyReview());
		try {
			atSourceSurveyReviewServiceImpl.saveAtsourceSurveyReviewResponses(
					getMockAtsourceSurveyReviewDto(), USER_ID);
		} catch (CustomValidationException e) {
			Assert.assertTrue(AtSourceConstants.SUCCESS, e.getMessage().equalsIgnoreCase(
					ErrorCode.OFIS_ATSOURCE_2040.getMessage()));
		}

		/**
		 * Scenario 2 - Survey review already rejected
		 */
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(getMockRejectedSurveyReview());
		try {
			atSourceSurveyReviewServiceImpl.saveAtsourceSurveyReviewResponses(
					getMockAtsourceSurveyReviewDto(), USER_ID);
		} catch (CustomValidationException e) {
			Assert.assertTrue(AtSourceConstants.SUCCESS, e.getMessage().equalsIgnoreCase(
					ErrorCode.OFIS_ATSOURCE_2043.getMessage()));
		}

		/**
		 * Scenario 3 - Survey review is null
		 */
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(null);
		Mockito.when(atSourceSurveyReviewRepository.save(Mockito.any(AtsourceSurveyReview.class))).thenReturn(null);
		MessageDto messageDto = atSourceSurveyReviewServiceImpl.saveAtsourceSurveyReviewResponses(
				getMockAtsourceSurveyReviewDto(), USER_ID);
		Assert.assertTrue(AtSourceConstants.SUCCESS, AtSourceConstants.SUCCESS.equals(messageDto.getMessage()));

		/**
		 * Scenario 4 - Survey review is submitted
		 */
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(getMockSubmittedSurveyReview());
		Mockito.when(atSourceSurveyReviewRepository.save(Mockito.any(AtsourceSurveyReview.class))).thenReturn(null);
		MessageDto message = atSourceSurveyReviewServiceImpl.saveAtsourceSurveyReviewResponses(
				getMockAtsourceSurveyReviewDto(), USER_ID);
		Assert.assertTrue(AtSourceConstants.SUCCESS, AtSourceConstants.SUCCESS.equals(message.getMessage()));
	}

	private AtsourceSurveyReviewDto getMockAtsourceSurveyReviewDto() {
		AtsourceSurveyReviewDto surveyReviewDto = new AtsourceSurveyReviewDto();
		surveyReviewDto.setStatus(Status.REJECTED);
		return surveyReviewDto;
	}
	
	
	@Test
	public void testCategorizeAndSaveAtSourceReviews_01() throws CustomValidationException{
		List<AtsourceSurveyReviewDto> atsourceSurveyReviewDtoList = null;
		Long userId = USER_ID;
		int appId = 1;
		String token = "asdfasd".repeat(10);
		
		/* Null input */
//		Mockito.when(trainingPillarRepository.getKmIds(Mockito.anyObject()))
//		.thenReturn(null);
//		Assert.assertEquals(NullPointerException.class, atSourceSurveyReviewServiceImpl.categorizeAndSaveAtSourceReviews(atsourceSurveyReviewDtoList, userId, appId, token));

		/* Empty input */
		Mockito.when(trainingPillarRepository.getKmIds(Mockito.anyObject()))
		.thenReturn(Collections.emptyList());
		Mockito.when(atSourceSurveyQuestionRepository.getKmIds(Mockito.anyObject()))
		.thenReturn(Collections.emptyList());
		Mockito.when(kmQuestionmappingRepository.getKmIds(Mockito.anyObject()))
		.thenReturn(Collections.emptyList());
		
		atsourceSurveyReviewDtoList = new ArrayList<>();
		List<AtsourceSurveyReviewDto>  result = atSourceSurveyReviewServiceImpl.categorizeAndSaveAtSourceReviews(atsourceSurveyReviewDtoList, userId, appId, token);
		Assert.assertEquals(atsourceSurveyReviewDtoList, result);
		
		/* Input with trainingPillar KmId */
		List<String> trainingInput = new ArrayList<>();
		trainingInput.add("km-01");
		Mockito.when(trainingPillarRepository.getKmIds(Mockito.anyObject()))
		.thenReturn(trainingInput);
		Mockito.when(iTrainingPillarClient.saveTrainingPillarSurveyReview(Mockito.anyObject(),Mockito.anyInt(),Mockito.anyString()))
			.thenReturn(null);
		AtsourceSurveyReviewDto dto = new AtsourceSurveyReviewDto();
		dto.setFarmerGroupId(1);
		dto.setStatus(Status.APPROVED);
		dto.setKmId("km-01");
		atsourceSurveyReviewDtoList.add(dto);
		
		result = atSourceSurveyReviewServiceImpl.categorizeAndSaveAtSourceReviews(atsourceSurveyReviewDtoList, userId, appId, token);
		Assert.assertEquals(atsourceSurveyReviewDtoList, result);		
	}
	@Test
	public void testCategorizeAndSaveAtSourceReviews_02() throws CustomValidationException{
		List<AtsourceSurveyReviewDto> atsourceSurveyReviewDtoList = new ArrayList<>();
		Long userId = USER_ID;
		int appId = 1;
		String token = "asdfasd".repeat(10);
		
		Mockito.when(trainingPillarRepository.getKmIds(Mockito.anyObject()))
		.thenReturn(Collections.emptyList());
		Mockito.when(kmQuestionmappingRepository.getKmIds(Mockito.anyObject()))
		.thenReturn(Collections.emptyList());
		
		List<String> trainingInput = new ArrayList<>();
		trainingInput.add("km-01");
			
		/* Positive Test - Input with BUSurvey KmId */
		Mockito.when(atSourceSurveyQuestionRepository.getKmIds(Mockito.anyObject()))
		.thenReturn(trainingInput);
		Mockito.when(atSourceSubmittedmoduleRepository.findAllById(Mockito.anyCollection()))
				.thenReturn(Collections.emptyList());
		Mockito.when(atSourceSubmittedmoduleRepository.findMaxVersionNumberById(Mockito.anyInt()))
				.thenReturn(1);
		Mockito.when(atSourceSubmittedmoduleRepository.saveAll(Mockito.anyCollection()))
		.thenReturn(null);
		
		AtsourceSurveyReviewDto dto1 = new AtsourceSurveyReviewDto();
		dto1.setFarmerGroupId(1);
		dto1.setStatus(Status.APPROVED);
		dto1.setKmId("km-01");
		dto1.setSubmittedModuleId(1);
		atsourceSurveyReviewDtoList.add(dto1);
		
		List<AtsourceSurveyReviewDto> result = 
				atSourceSurveyReviewServiceImpl.categorizeAndSaveAtSourceReviews(atsourceSurveyReviewDtoList, userId, appId, token);
		Assert.assertEquals(atsourceSurveyReviewDtoList, result);
		
		/* Negative test - SubmittedModuleId as 0 */
		dto1.setSubmittedModuleId(0);
		atsourceSurveyReviewDtoList.add(dto1);
		try {
		result = atSourceSurveyReviewServiceImpl.categorizeAndSaveAtSourceReviews(atsourceSurveyReviewDtoList, userId, appId, token);
		}catch(CustomValidationException e) {
		Assert.assertEquals(ErrorCode.OFIS_ATSOURCE_2032.getMessage(), e.getMessage());
		}
		
		/* KM id not in main list */
		dto1.setSubmittedModuleId(1);
		atsourceSurveyReviewDtoList.clear();
		atsourceSurveyReviewDtoList.add(dto1);
		trainingInput.clear();
		trainingInput.add("km-02");
		try {
		result = atSourceSurveyReviewServiceImpl.categorizeAndSaveAtSourceReviews(atsourceSurveyReviewDtoList, userId, appId, token);
		}catch(CustomValidationException e) {
		Assert.assertEquals(ErrorCode.OFIS_ATSOURCE_2031.getMessage(), e.getMessage());
		}	
	}
	
	@Test
	public void testCategorizeAndSaveAtSourceReviews_03() throws CustomValidationException{
		List<AtsourceSurveyReviewDto> atsourceSurveyReviewDtoList = new ArrayList<>();
		Long userId = USER_ID;
		int appId = 1;
		String token = "asdfasd".repeat(10);
		
		Mockito.when(trainingPillarRepository.getKmIds(Mockito.anyObject()))
		.thenReturn(Collections.emptyList());
		Mockito.when(atSourceSurveyQuestionRepository.getKmIds(Mockito.anyObject()))
		.thenReturn(Collections.emptyList());
		
		List<String> kmIdsInput = new ArrayList<>();
		kmIdsInput.add("km-01");
		Mockito.when(kmQuestionmappingRepository.getKmIds(Mockito.anyObject()))
		.thenReturn(kmIdsInput);
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(),Mockito.anyInt()))
		.thenReturn(null);
		Mockito.when(atSourceSurveyReviewRepository.save(Mockito.anyObject()))
		.thenReturn(null);
		
		AtsourceSurveyReviewDto dto = new AtsourceSurveyReviewDto();
		dto.setFarmerGroupId(1);
		dto.setStatus(Status.APPROVED);
		dto.setKmId("km-01");
		atsourceSurveyReviewDtoList.add(dto);
		
		/* Positive Test */
		List<AtsourceSurveyReviewDto> result =
				atSourceSurveyReviewServiceImpl.categorizeAndSaveAtSourceReviews(atsourceSurveyReviewDtoList, userId, appId, token);
		Assert.assertEquals(atsourceSurveyReviewDtoList, result);
		
		/* status as rejected */
		dto.setStatus(Status.REJECTED);
		atsourceSurveyReviewDtoList.clear();
		atsourceSurveyReviewDtoList.add(dto);
		
		 result = atSourceSurveyReviewServiceImpl.categorizeAndSaveAtSourceReviews(atsourceSurveyReviewDtoList, userId, appId, token);
		Assert.assertEquals(atsourceSurveyReviewDtoList, result);
		
		/* data already available with status APPROVED */
		AtsourceSurveyReview asr = new AtsourceSurveyReview();
		asr.setStatus(Status.APPROVED);
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(),Mockito.anyInt()))
		.thenReturn(asr);
		
		try {
			result = atSourceSurveyReviewServiceImpl.categorizeAndSaveAtSourceReviews(atsourceSurveyReviewDtoList, userId, appId, token);
			}catch(CustomValidationException e) {
			Assert.assertEquals(ErrorCode.OFIS_ATSOURCE_2040.getMessage(), e.getMessage());
			}	
		
		/* data already available with status REJECTED */
		asr.setStatus(Status.REJECTED);
		Mockito.when(atSourceSurveyReviewRepository.findByKmIdAndFarmerGroupId(Mockito.anyString(),Mockito.anyInt()))
		.thenReturn(asr);
		
		try {
			result = atSourceSurveyReviewServiceImpl.categorizeAndSaveAtSourceReviews(atsourceSurveyReviewDtoList, userId, appId, token);
			}catch(CustomValidationException e) {
			Assert.assertEquals(ErrorCode.OFIS_ATSOURCE_2043.getMessage(), e.getMessage());
			}	
		
	}
	
	
	@Test
	public void testUpdateAtsourceSurveyReviewResponses() throws Exception {
		MessageDto result;
		long reviewId = 1;
		AtsourceSurveyReviewDto asr = new AtsourceSurveyReviewDto();
		
		Mockito.when(atSourceSurveyReviewRepository.findById(Mockito.anyInt()))
		.thenReturn(Optional.empty());
		Mockito.when(atSourceSurveyReviewRepository.save(Mockito.anyObject()))
		.thenReturn(null);
		/* Id as null */
		try {
			 result = atSourceSurveyReviewServiceImpl.updateAtsourceSurveyReviewResponses(reviewId, asr, USER_ID);
		}catch(CustomValidationException e) {
			Assert.assertEquals(ErrorCode.OFIS_ATSOURCE_2037.getMessage(), e.getMessage());
		}
		/* UserId reviewId same */
		asr.setId(USER_ID);
		try {
			 result = atSourceSurveyReviewServiceImpl.updateAtsourceSurveyReviewResponses(reviewId, asr, USER_ID);
		}catch(CustomValidationException e) {
			Assert.assertEquals(ErrorCode.OFIS_ATSOURCE_2038.getMessage(), e.getMessage());
		}
		
		/* data not present */
		reviewId = 2;
		try { 
			 result = atSourceSurveyReviewServiceImpl.updateAtsourceSurveyReviewResponses(reviewId, asr, USER_ID);
		}catch(Exception e) {
			Assert.assertEquals(ErrorCode.OFIS_ATSOURCE_2039.getMessage(), e.getMessage());
		}
		
		
		Mockito.when(atSourceSurveyReviewRepository.findById(Mockito.anyInt()))
		.thenReturn(getOptionalMockApprovedSurveyReviewAPPROVED());
		
		/* APPROVED status */
		asr.setStatus(Status.APPROVED);
		try {
			 result = atSourceSurveyReviewServiceImpl.updateAtsourceSurveyReviewResponses(reviewId, asr, USER_ID);
		}catch(CustomValidationException e) {
			Assert.assertEquals(ErrorCode.OFIS_ATSOURCE_2040.getMessage(), e.getMessage());
		}
		
		Mockito.when(atSourceSurveyReviewRepository.findById(Mockito.anyInt()))
		.thenReturn(getOptionalMockApprovedSurveyReview());
		
		/* REJECTED status */
		asr.setStatus(Status.REJECTED);
			 result = atSourceSurveyReviewServiceImpl.updateAtsourceSurveyReviewResponses(reviewId, asr, USER_ID);
			 Assert.assertEquals(AtSourceConstants.SUCCESS, result.getMessage());
		/* SAVED status */
		asr.setStatus(Status.SAVED);
		result = atSourceSurveyReviewServiceImpl.updateAtsourceSurveyReviewResponses(reviewId, asr, USER_ID);
		Assert.assertEquals(AtSourceConstants.SUCCESS, result.getMessage());
		/* SUBMTTED status */ 
		asr.setStatus(Status.SUBMTTED);
		result = atSourceSurveyReviewServiceImpl.updateAtsourceSurveyReviewResponses(reviewId, asr, USER_ID);
		Assert.assertEquals(AtSourceConstants.SUCCESS, result.getMessage());
	}
	private Optional<AtsourceSurveyReview> getOptionalMockApprovedSurveyReviewAPPROVED() {
		AtsourceSurveyReview surveyReview = new AtsourceSurveyReview();
		surveyReview.setStatus(Status.APPROVED);
		Optional<AtsourceSurveyReview> result = Optional.of(surveyReview);
		return result;
	}
	private Optional<AtsourceSurveyReview> getOptionalMockApprovedSurveyReview() {
		AtsourceSurveyReview surveyReview = new AtsourceSurveyReview();
		surveyReview.setKmId("km-01");
		surveyReview.setStatus(Status.SAVED);
		Optional<AtsourceSurveyReview> result = Optional.of(surveyReview);
		return result;
	}
	
	
	
	@Test 
	public void testGetAllFarmerGroupsByKmId() throws Exception {
		String kmId = "km_01";
		List<FarmerGroupProjectionDto> result;
		try {
		result = atSourceSurveyReviewServiceImpl.getAllFarmerGroupsByKmId(kmId,null);
		}catch(CustomValidationException e) {
			Assert.assertEquals(ErrorCode.OFIS_ATSOURCE_2006.getMessage(), e.getMessage());
		}
		
		Mockito.when(atSourceSurveyReviewRepository.getAtSourceSurveyReviewFarmerGroups(Mockito.anyString()))
		.thenReturn(Collections.emptyList());
		result = atSourceSurveyReviewServiceImpl.getAllFarmerGroupsByKmId(kmId,USER_ID);
		Assert.assertEquals(Collections.emptyList(), result);
	}
}
