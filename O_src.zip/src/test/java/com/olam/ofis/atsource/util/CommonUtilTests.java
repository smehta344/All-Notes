/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */ 
package com.olam.ofis.atsource.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.assertj.core.util.Arrays;
import org.junit.Assert;
import org.junit.Test;

/**
 * @author LTI Developer
 */
public class CommonUtilTests {
	
	@Test
	public void testFormatDate() {
		Assert.assertNotNull(CommonUtil.convertToDateString(new Date()));
		Assert.assertNotNull(CommonUtil.formatDate("01-Jan-2019","DD-MMM-YY"));
		
		Assert.assertNotNull(CommonUtil.formatDate(new Date()));
		Assert.assertNotNull(CommonUtil.getDateString(new Date(),"DD-MMM-YY"));
		Assert.assertNotNull(CommonUtil.getDateString(new Date()));
		
		Assert.assertNotNull(CommonUtil.formatDate("2019-Jan-01"));
	}
	@SuppressWarnings("deprecation")
	@Test
	public void testGetCalendarDiff() {
		Assert.assertNotNull(CommonUtil.getCalendarDiff(new Date("01-Oct-2001"),new Date(),1));
		Assert.assertNotNull(CommonUtil.getDiffYears(new Date("01-Oct-2001"),new Date()));
		Assert.assertNotNull(CommonUtil.getDateField(new Date("01-Oct-2001"),1));
		
		Assert.assertNotNull(CommonUtil.getDateField("01-Oct-2001",1));
		Assert.assertNotNull(CommonUtil.getDateField("2019-Jan-01","dd-mmm-yyyy",1));
	}
	@Test
	public void testisNull() {
		Map<String,Integer> map = new HashMap<String,Integer>();
		map.put("one", 1);
		Assert.assertNotNull(CommonUtil.isNull(map));
	}
	@Test
	public void testOthers() {
		Assert.assertNotNull(CommonUtil.toInteger("1"));
		Assert.assertNotNull(CommonUtil.toLong("1"));
		Assert.assertNotNull(CommonUtil.isNumeric(new String("1")));
		Assert.assertNotNull(CommonUtil.getListOfStringValues("1,2,3"));
		
		Assert.assertNotNull(CommonUtil.getStackTrace(new Exception()));
		Assert.assertNotNull(CommonUtil.getMessage(new Exception()));
		
		Assert.assertNotNull(CommonUtil.getRoundedValue(2.07));
		
		String a[] = new String[] { "A", "B", "C", "D" };
		Assert.assertNotNull(CommonUtil.getCommaSepratedValues(Arrays.asList(a)));
		
		Assert.assertNotNull(CommonUtil.getCurrentTimeStamp());
	
		CommonUtil.printRunTimeMemory();
		
		Assert.assertNotNull(CommonUtil.getUniqueRandomCode("Test cases for unused code"));
		Assert.assertNotNull(CommonUtil.getQuestionUniqueRandomCode("Test cases for unused code"));
		
		Assert.assertNotNull(CommonUtil.convertToStringToDate("01-10-2001"));
		
		List<Long> tempList = new ArrayList<Long>();
		tempList.add(1L);
		tempList.add(2L);
		Assert.assertNotNull(CommonUtil.listToString(tempList));
	}
	
}
