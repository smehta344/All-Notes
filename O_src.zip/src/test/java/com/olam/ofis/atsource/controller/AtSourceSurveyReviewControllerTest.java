package com.olam.ofis.atsource.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.olam.ofis.atsource.dto.AtsourceSurveyReviewDto;
import com.olam.ofis.atsource.dto.KmFarmerGroupIdDto;
import com.olam.ofis.atsource.dto.UserDTO;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.model.Status;
import com.olam.ofis.atsource.service.AtSourceSurveyReviewService;
import com.olam.ofis.atsource.util.RetrieveUserData;

public class AtSourceSurveyReviewControllerTest {

	private static final String tokenString = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJsYW5ndWFnZUlTT0NvZGUiOiJlbiIsInRpbWV6b25lSXNvQ29kZSI6IldJQiIsI";
	
	@Mock
	private HttpServletRequest request;

	@Mock
	private AtSourceSurveyReviewService atSourceSurveyReviewService;

	@Mock
	RetrieveUserData retrieveUserData;
	
	@InjectMocks
	private AtSourceSurveyReviewController atSourceSurveyReviewController;

	private MockMvc mockMvc;
	 long USERID = 1;
	 ObjectMapper mapper = new ObjectMapper();
	 
	 @Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(atSourceSurveyReviewController).build();
		
		UserDTO user = new UserDTO();
		user.setUserId(USERID);
		user.setUserName("admin");
		Mockito.when(retrieveUserData.getUserData(Mockito.anyObject()))
		.thenReturn(user);
	}
	@Test
	public void categorizeAndSaveAtSourceReviewsTest_01() throws Exception {
		List<AtsourceSurveyReviewDto> request = buildAtsourceSurveyReviewDtoData();
		
		Mockito.when(atSourceSurveyReviewService.categorizeAndSaveAtSourceReviews(Mockito.anyList(),Mockito.anyLong(),Mockito.anyInt(),Mockito.anyString()))
				.thenReturn(request);
		
		mockMvc.perform(post("/atsource/reviews/all").header("Authorization", "Bearer " + tokenString)
				.header("App-Id", 1).contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(request))).andDo(print()).andExpect(status().isOk());
	}

	/**
	 * mock request data
	 * 
	 * @return
	 */
	public List<AtsourceSurveyReviewDto> buildAtsourceSurveyReviewDtoData() {
		List<AtsourceSurveyReviewDto> dtos = new ArrayList<>();

		AtsourceSurveyReviewDto dto = new AtsourceSurveyReviewDto();
		dto.setFarmerGroupId(1);
		dto.setKmId("KM-00");
		dto.setMaxValue(50);
		dto.setMinValue(1);
		dto.setStatus(Status.APPROVED);
		dto.setVersionNumber(1);

		dtos.add(dto);
		return dtos;
	}

	@Test
	public void testGetAllKmCodes() throws Exception {
		Mockito.when(atSourceSurveyReviewService.getAllKmCodes())
		.thenReturn(Collections.emptyList());
		
		mockMvc.perform(get("/atsource/reviews/getAllKmCodes").header("Authorization", "Bearer " + tokenString)
							.header("App-Id", 1).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
	
	@Test
	public void testGetFarmerModule() throws Exception {
		Mockito.when(atSourceSurveyReviewService.getFarmerModule(Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(),Mockito.anyInt(),
											Mockito.anyString(),Mockito.anyString()))
		.thenReturn(null);
		
		mockMvc.perform(get("/atsource/reviews/getFarmerModule")
							.header("Authorization", "Bearer " + tokenString)
							.header("App-Id", 1)
							.contentType(MediaType.APPLICATION_JSON)
							.param("kmId", "km-01")
							.param("farmerGroupId", "1").param("page", "1")
							.param("size", "1").param("sort", "moduleName")
							.param("direction", "asc"))
		.andExpect(status().isOk());
	}
	
	@Test
	public void testGetAllFarmerGroupsByKmId() throws Exception {
		Mockito.when(atSourceSurveyReviewService.getAllFarmerGroupsByKmId(Mockito.anyString(),Mockito.anyLong()))
		.thenReturn(null);
		
		mockMvc.perform(get("/atsource/reviews/getAllFarmerGroupsByKmId?kmId=KM-48").header("App-Id", 1)
				.header("Authorization", "Bearer " + tokenString)).andExpect(status().isOk());
	}

	@Test
	public void testGetAllFarmerGroupsByKmIdException() throws Exception {
		Mockito.when(atSourceSurveyReviewService.getAllFarmerGroupsByKmId(Mockito.anyString(), Mockito.anyLong()))
				.thenThrow(new CustomValidationException("Exception test"));
		mockMvc.perform(get("/atsource/reviews/getAllFarmerGroupsByKmId?kmId=KM-48").header("App-Id", 1)
				.header("Authorization", "Bearer " + tokenString)).andExpect(status().isOk());
	}

	@Test
	public void testGetAllFarmerModule() throws Exception {
		mockMvc.perform(get("/atsource/reviews/getFarmerModule?kmId=KM-49&farmerGroupId=11").header("App-Id", 1)
				.header("Authorization", "Bearer " + tokenString)).andExpect(status().isOk());
	}

	@Test
	public void testGetAllFarmerModuleCustomException() throws Exception {
		Mockito.when(atSourceSurveyReviewService.getFarmerModule(Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(),Mockito.anyInt(),Mockito.anyString(),Mockito.anyString()))
				.thenThrow(new CustomValidationException("Custom validation exception"));
		mockMvc.perform(get("/atsource/reviews/getFarmerModule?kmId=KM-49&farmerGroupId=11&page=1&size=20&sort=farmerName&direction=asc")
				.header("App-Id", 1).header("Authorization", "Bearer " + tokenString)).andExpect(status().isOk());
	}
	
	@Test
	public void testGetAllFarmerModuleException() throws Exception {
		
		Mockito.when(atSourceSurveyReviewService.getFarmerModule(Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(),Mockito.anyInt(),Mockito.anyString(),Mockito.anyString()))
		.thenThrow(new NullPointerException("Exception"));
		mockMvc.perform(get("/atsource/reviews/getFarmerModule?kmId=KM-49&farmerGroupId=11&page=1&size=20&sort=farmerName&direction=asc")
		.header("App-Id", 1).header("Authorization", "Bearer " + tokenString)).andExpect(status().isOk());
	}

	@Test
	public void testSaveAtsourceSurveyReview() throws Exception{
		Mockito.when(atSourceSurveyReviewService.saveAtsourceSurveyReviewResponses(any(AtsourceSurveyReviewDto.class), Mockito.anyLong()))
		.thenReturn(null);
	
		mockMvc.perform(post("/atsource/reviews/").header("app-id", 1)
				.header("Authorization", "Bearer " + tokenString)
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(getMockAtsourceSurveyReviewDto())))
				.andExpect(status().isOk());
	}
	
	private AtsourceSurveyReviewDto getMockAtsourceSurveyReviewDto() {
		AtsourceSurveyReviewDto surveyReviewDto = new AtsourceSurveyReviewDto();
		surveyReviewDto.setStatus(Status.REJECTED);
		return surveyReviewDto;
	}
	
	@Test
	public void testUpdateAtsourceSurveyReview() throws Exception{
		Mockito.when(atSourceSurveyReviewService.updateAtsourceSurveyReviewResponses(Mockito.anyLong(),any(AtsourceSurveyReviewDto.class), Mockito.anyLong()))
		.thenReturn(null);
	
		mockMvc.perform(put("/atsource/reviews/1").header("app-id", 1)
				.header("Authorization", "Bearer " + tokenString)
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(getMockAtsourceSurveyReviewDto())))
				.andExpect(status().isOk());
	}
	@Test
	public void testSaveSurveyReviewByKmIdAndFgId() throws Exception{
		Mockito.when(atSourceSurveyReviewService.saveSurveyReviewByKmIdAndFgId(any(KmFarmerGroupIdDto.class), Mockito.anyLong()))
		.thenReturn(null);
	
		mockMvc.perform(put("/atsource/reviews/saveSurveyReview").header("app-id", 1)
				.header("Authorization", "Bearer " + tokenString)
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(getKmFarmerGroupIdDto())))
				.andExpect(status().isOk());
	}
	
	private KmFarmerGroupIdDto getKmFarmerGroupIdDto() {
		KmFarmerGroupIdDto dto = new KmFarmerGroupIdDto();
		dto.setFarmerGroupId(1);
		dto.setKmId("km-01");
		return dto;
	}
	
	@Test
	public void testSubmitSurveyReviewByKmIdAndFgId() throws Exception{
		Mockito.when(atSourceSurveyReviewService.submitSurveyReviewByKmIdAndFgId(any(KmFarmerGroupIdDto.class), Mockito.anyLong()))
		.thenReturn(null);
	
		mockMvc.perform(put("/atsource/reviews/submitSurveyReview").header("app-id", 1)
				.header("Authorization", "Bearer " + tokenString)
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(getKmFarmerGroupIdDto())))
				.andExpect(status().isOk());
	}
}
