/*******************************************************************************
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 *******************************************************************************/

package com.olam.ofis.atsource.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.olam.ofis.atsource.dto.AtsourceModuleAssignmentDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.service.AtsourceModuleAssignmentService;
import com.olam.ofis.atsource.util.CommonUtil;

/**
 * Class - AtSourceModuleAssignmentControllerTest
 *
 * @author Mohammed Mahroof
 *
 */
public class AtSourceModuleAssignmentControllerTest {

	private MockMvc mockMvc;

	@Mock
	private HttpServletRequest request;
	
	@Mock
	AtsourceModuleAssignmentService atsourceModuleAssignmentService;

	@Mock
	CommonUtil commonUtil;
	
	@InjectMocks
	private AtsourceModuleAssignmentController atSourceModuleAssignmentController;

	private static String tokenString = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJsYW5ndWFnZUlTT0NvZGUiOiJlbiIsInRpbWV6b25lSXNvQ29kZSI6IldJQiIsI";

	ObjectMapper mapper = new ObjectMapper();
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(atSourceModuleAssignmentController).build();
	}

	@Test
	public void saveModuleAssignmentTest() throws Exception {
		AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
		MessageDto messageDto = new MessageDto();
		Mockito.when(atsourceModuleAssignmentService.saveModuleAssignment(any(AtsourceModuleAssignmentDto.class)))
				.thenReturn(messageDto);
		
		 when(request.getHeader(Mockito.anyString())).thenReturn("1");
		 
		mockMvc.perform(post("/atsource/assignments/moduleAssignments/save")
				.header("Authorization", "Bearer " + tokenString).header("App-Id", 1)
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(atsourceModuleAssignmentDto)))
				.andExpect(status().isOk());
	}

	@Test
	public void getModuleAssignmentTest() throws Exception {
		AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
		Mockito.when(atsourceModuleAssignmentService.getModuleAssignment(anyInt()))
				.thenReturn(atsourceModuleAssignmentDto);
		mockMvc.perform(get("/atsource/assignments/moduleAssignments/1")
				.header("Authorization", "Bearer " + tokenString).contentType(MediaType.APPLICATION_JSON))
				.andDo(print()).andExpect(status().isOk());
	}

	@Test
	public void getAllModuleAssignmentTest() throws CustomValidationException, Exception {
		List<AtsourceModuleAssignmentDto> moduleAssignmentDtos = new ArrayList<>();
		Mockito.when(atsourceModuleAssignmentService.getAllModuleAssignment()).thenReturn(moduleAssignmentDtos);
		mockMvc.perform(get("/atsource/assignments/moduleassignments/all")
				.header("Authorization", "Bearer " + tokenString).contentType(MediaType.APPLICATION_JSON))
				.andDo(print()).andExpect(status().isOk());
	}

}