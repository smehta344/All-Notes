/*******************************************************************************
 * Copyright (c) 2019 OLAM Limited
 * 
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited.
 ******************************************************************************/
package com.olam.ofis.atsource.service;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.olam.ofis.atsource.dto.AtSourceQuestionDto;
import com.olam.ofis.atsource.dto.AtSourceSurveyAnswerDto;
import com.olam.ofis.atsource.dto.AtsourceSubmittedmoduleDto;
import com.olam.ofis.atsource.dto.AtsourceSurveyResponseDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.SubModuleResullt;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.exception.ErrorCode;
import com.olam.ofis.atsource.model.AtSourceSurveyAnswer;
import com.olam.ofis.atsource.model.AtsourceModuleAssignment;
import com.olam.ofis.atsource.model.AtsourceSubmittedmodule;
import com.olam.ofis.atsource.model.AtsourceSurveylookupvalue;
import com.olam.ofis.atsource.model.AtsourceSurveyquestion;
import com.olam.ofis.atsource.model.FarmerGroup;
import com.olam.ofis.atsource.model.Module;
import com.olam.ofis.atsource.model.Status;
import com.olam.ofis.atsource.repository.AtSourceLookUpValueRepository;
import com.olam.ofis.atsource.repository.AtSourceSubmittedmoduleRepository;
import com.olam.ofis.atsource.repository.AtSourceSurveyAnswerRepository;
import com.olam.ofis.atsource.repository.AtSourceSurveyQuestionRepository;
import com.olam.ofis.atsource.repository.AtsourceModuleAssignmentRepository;
import com.olam.ofis.atsource.repository.CountryRepository;
import com.olam.ofis.atsource.repository.FarmerGroupRepository;
import com.olam.ofis.atsource.repository.ModuleRepository;
import com.olam.ofis.atsource.repository.ProductRepository;
import com.olam.ofis.atsource.repository.SubModuleRepository;
import com.olam.ofis.atsource.repository.UserRepository;
import com.olam.ofis.atsource.service.impl.AtSourceSurveyAnswerServiceImpl;
import com.olam.ofis.atsource.util.AtSourceConstants;
import com.olam.ofis.atsource.util.PaginationResult;

public class AtSourceSurveyAnswerServiceTest {

	@InjectMocks
	private AtSourceSurveyAnswerServiceImpl atSourceSurveyAnswerServiceImpl;

	@Mock
	private ModelMapper modelMapper;
	
	@Mock
	private AtSourceSurveyAnswerRepository atSourceSurveyAnswerRepo;

	@Mock
	private AtSourceSurveyQuestionRepository surveyQuestionRepository;

	@Mock
	private AtsourceModuleAssignmentRepository atsourceModuleAssignmentRepository;

	@Mock
	private FarmerGroupRepository farmerGroupRepository;

	@Mock
	private AtSourceSubmittedmoduleRepository atSourceSubmittedmoduleRepository;

	@Mock
	private ModuleRepository moduleRepository;

	@Mock
	private AtSourceLookUpValueRepository atSourceLookUpValueRepository;

	@Mock
	private AtSourceQuestionsService atSourceQuestionsService;
	
	@Mock
	UserRepository userRepository;
	
	@Mock
	ProductRepository productRepository;
	
	@Mock
	CountryRepository countryRepository;
	
	@Mock
	SubModuleRepository subModuleRepository;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		MockitoAnnotations.initMocks(this);	    
	}
	
	static final long ONE = 1;
	
	@Test
	public void findAll_testScenarios() {

		List<AtSourceSurveyAnswerDto> atSourceSurveyAnswers = null;

		/**
		 * Scenario 1 - Check list is empty.
		 */
		Mockito.when(atSourceSurveyAnswerRepo.findAll()).thenReturn(getMockEmptyList());
		atSourceSurveyAnswers = atSourceSurveyAnswerServiceImpl.findAll();
		Assert.assertTrue("Success", atSourceSurveyAnswers.isEmpty());

		/**
		 * Scenario 2 - Check list is not empty.
		 */
		Mockito.when(atSourceSurveyAnswerRepo.findAll()).thenReturn(getMockAtSourceSurveyAnswersList());
		atSourceSurveyAnswers = atSourceSurveyAnswerServiceImpl.findAll();
		Assert.assertTrue("Success", !atSourceSurveyAnswers.isEmpty());
	}

	@Test(expected = CustomValidationException.class)
	public void findById_emptyCheck() throws CustomValidationException {
		Mockito.when(atSourceSurveyAnswerRepo.findById(Mockito.anyInt())).thenReturn(getEmptyOptional());
		atSourceSurveyAnswerServiceImpl.findById(Mockito.anyLong());
	}

	@Test
	public void findById_validate() throws CustomValidationException {
		Mockito.when(atSourceSurveyAnswerRepo.findById(Mockito.anyInt())).thenReturn(getOptionalAtsourceAnswers());
		AtSourceSurveyAnswerDto surveyAnswer = atSourceSurveyAnswerServiceImpl.findById(Mockito.anyLong());
		Assert.assertEquals(10, surveyAnswer.getId().intValue());
	}

	private Optional<AtSourceSurveyAnswer> getOptionalAtsourceAnswers() {
		AtSourceSurveyAnswer surveyAnswer = getMockAtSourceSurveyAnswer();
		surveyAnswer.setId(1);
		return Optional.of(surveyAnswer);
	}

	private Optional<AtSourceSurveyAnswer> getEmptyOptional() {
		Optional<AtSourceSurveyAnswer> surveyAnswer = Optional.empty();
		return surveyAnswer;
	}

	private List<AtSourceSurveyAnswer> getMockEmptyList() {
		return new ArrayList<AtSourceSurveyAnswer>();
	}

	private List<AtSourceSurveyAnswer> getMockAtSourceSurveyAnswersList() {
		List<AtSourceSurveyAnswer> surveyAnswers = new ArrayList<>();
		surveyAnswers.add(getMockAtSourceSurveyAnswer());
		return surveyAnswers;
	}

	private AtSourceSurveyAnswer getMockAtSourceSurveyAnswer() {
		AtSourceSurveyAnswer surveyAnswer = new AtSourceSurveyAnswer();
		surveyAnswer.setAnswerBoolean(Boolean.TRUE);
		surveyAnswer.setAppId(1);
		surveyAnswer.setAnswerDate(new Date());
		surveyAnswer.setAnswerDecimal(new BigDecimal(10.6));
		surveyAnswer.setAnswerInt(10);
		surveyAnswer.setAnswerText("Test String");
		surveyAnswer.setId(10);
		AtsourceSurveyquestion asq = new AtsourceSurveyquestion();
		asq.setId(1);
		surveyAnswer.setAtsourceSurveyquestion(asq);
		return surveyAnswer;
	}

	@Test
	public void testCreateAnswer_Scenarios() throws CustomValidationException {
		AtsourceSubmittedmoduleDto inputSubmittedmoduleDto = null;
		AtsourceSubmittedmoduleDto responseSubmittedmoduleDto = null;

		when(modelMapper.map(any(AtsourceSubmittedmoduleDto.class),any()))
		.thenReturn(getMockSubmittedAtsourceSubmittedmodule());

		when(modelMapper.map(any(AtSourceSurveyAnswerDto.class),any()))
		.thenReturn(getMockAtSourceSurveyAnswer());
		
		when(modelMapper.map(any(AtSourceSurveyAnswer.class),any()))
		.thenReturn(getMockAtSourceSurveyAnswerDto());
		
		when(modelMapper.map(any(AtsourceSubmittedmodule.class),any()))
		.thenReturn(getMockAtsourceSubmittedmoduleDtoWithId());

		/**
		 * Negative Scenario - Submitted Module without Survey Answer
		 */
		inputSubmittedmoduleDto = getMockAtsourceSubmittedmoduleDtoWithOutAnswers();
		try {
			atSourceSurveyAnswerServiceImpl.createAnswer(inputSubmittedmoduleDto, ONE);
		} catch (CustomValidationException e) {
			Assert.assertTrue("Success", e.getMessage().equalsIgnoreCase("No Survey answers found."));
		}

		/**
		 * Negative Scenario - Submitted Module already exists
		 */
		Mockito.when(atSourceSubmittedmoduleRepository.findCurrentSurveyByFarmerGroupId(Mockito.anyInt()))
				.thenReturn(getMockAtsourceSubmittedmodule());

		inputSubmittedmoduleDto = getMockAtsourceSubmittedmoduleDtoWithAnswers();
		try {
			atSourceSurveyAnswerServiceImpl.createAnswer(inputSubmittedmoduleDto, ONE);
		} catch (CustomValidationException e) {
			Assert.assertTrue("Success", e.getMessage().equalsIgnoreCase("Submitted module exists for this farmer group."));
		}

		/**
		 * Negative Scenario - Invalid question Id
		 */
		Mockito.when(atSourceSubmittedmoduleRepository.findCurrentSurveyByFarmerGroupId(Mockito.anyInt()))
				.thenReturn(null);
		Mockito.when(atSourceSubmittedmoduleRepository.save(Mockito.any(AtsourceSubmittedmodule.class)))
				.thenReturn(getMockAtsourceSubmittedmodule());
		Mockito.when(surveyQuestionRepository.findById(Mockito.anyInt())).thenReturn(Optional.ofNullable(null));

		inputSubmittedmoduleDto = getMockAtsourceSubmittedmoduleDtoWithAnswers();
		try {
			atSourceSurveyAnswerServiceImpl.createAnswer(inputSubmittedmoduleDto, ONE);
		} catch (CustomValidationException e) {
			Assert.assertTrue("Success", e.getMessage().equalsIgnoreCase("Invalid Question Id."));
		}

		/**
		 * Positive Scenario - Create survey answer
		 */
		Mockito.when(atSourceSubmittedmoduleRepository.findCurrentSurveyByFarmerGroupId(Mockito.anyInt()))
				.thenReturn(null);
		Mockito.when(atSourceSubmittedmoduleRepository.save(Mockito.any(AtsourceSubmittedmodule.class)))
				.thenReturn(getMockAtsourceSubmittedmodule());
		Mockito.when(surveyQuestionRepository.findById(Mockito.anyInt())).thenReturn(getMockAtSourceSurveyQuestion());
		Mockito.when(atSourceSurveyAnswerRepo.save(Mockito.any(AtSourceSurveyAnswer.class))).thenReturn(null);
		Mockito.when(atSourceSurveyAnswerRepo.findBySubmittedmoduleId(Mockito.anyInt()))
				.thenReturn(getMockAtSourceSurveyAnswersList());

		inputSubmittedmoduleDto = getMockAtsourceSubmittedmoduleDtoWithAnswers();

		responseSubmittedmoduleDto = atSourceSurveyAnswerServiceImpl.createAnswer(inputSubmittedmoduleDto, ONE);
		Assert.assertTrue("Success", responseSubmittedmoduleDto.getId().equals(1));
	}

	private AtsourceSubmittedmoduleDto getMockAtsourceSubmittedmoduleDtoWithOutAnswers() {
		AtsourceSubmittedmoduleDto atsourceSubmittedmoduleDto = new AtsourceSubmittedmoduleDto();
		atsourceSubmittedmoduleDto.setAppId(1);
		atsourceSubmittedmoduleDto.setModuleId(58);
		return atsourceSubmittedmoduleDto;
	}

	private AtsourceSubmittedmoduleDto getMockAtsourceSubmittedmoduleDtoWithAnswers() {
		AtsourceSubmittedmoduleDto atsourceSubmittedmoduleDto = new AtsourceSubmittedmoduleDto();
		atsourceSubmittedmoduleDto.setAppId(1);
		atsourceSubmittedmoduleDto.setModuleId(58);
		atsourceSubmittedmoduleDto.setSurveyAnswers(getMockSurveyAnswerDtoList());
		atsourceSubmittedmoduleDto.setFarmerGroupId(1);
		atsourceSubmittedmoduleDto.setStatus(Status.SUBMTTED);
		return atsourceSubmittedmoduleDto;
	}

	private List<AtSourceSurveyAnswerDto> getMockSurveyAnswerDtoList() {
		List<AtSourceSurveyAnswerDto> atSourceSurveyAnswerDtoList = new ArrayList<>();
		atSourceSurveyAnswerDtoList.add(getMockAtSourceSurveyAnswerDto());
		return atSourceSurveyAnswerDtoList;
	}

	private AtsourceSubmittedmodule getMockAtsourceSubmittedmodule() {
		AtsourceSubmittedmodule atsourceSubmittedmodule = new AtsourceSubmittedmodule();
		atsourceSubmittedmodule.setId(1);
		atsourceSubmittedmodule.setStatus(Status.SAVED);
		atsourceSubmittedmodule.setFarmerGroupId(1);
		atsourceSubmittedmodule.setModuleId(1);
		return atsourceSubmittedmodule;
	}

	@Test
	public void testUpdateAnswer_scenarios() throws CustomValidationException {
		AtsourceSubmittedmoduleDto inputSubmittedmoduleDto = null;
		AtsourceSubmittedmoduleDto responseSubmittedmoduleDto = null;

		when(modelMapper.map(any(AtsourceSubmittedmoduleDto.class),any()))
		.thenReturn(getMockSubmittedAtsourceSubmittedmodule());

		when(modelMapper.map(any(AtSourceSurveyAnswerDto.class),any()))
		.thenReturn(getMockAtSourceSurveyAnswer());
		
		when(modelMapper.map(any(AtSourceSurveyAnswer.class),any()))
		.thenReturn(getMockAtSourceSurveyAnswerDto());
		
		when(modelMapper.map(any(AtsourceSubmittedmodule.class),any()))
		.thenReturn(getMockAtsourceSubmittedmoduleDtoWithId());

		/**
		 * Negative Scenario 1 - Submitted Module without id
		 */
		inputSubmittedmoduleDto = getMockAtsourceSubmittedmoduleDtoWithOutAnswers();
		try {
			atSourceSurveyAnswerServiceImpl.updateAnswer(ONE, inputSubmittedmoduleDto, ONE);
		} catch (CustomValidationException e) {
			Assert.assertTrue("Success", e.getMessage().equalsIgnoreCase("Submitted Module Id not found."));
		}

		/**
		 * Negative Scenario 2 - Submitted Module id not matched with path param
		 */
		inputSubmittedmoduleDto = getMockAtsourceSubmittedmoduleDtoWithId();
		try {
			atSourceSurveyAnswerServiceImpl.updateAnswer(2L, inputSubmittedmoduleDto, ONE);
		} catch (CustomValidationException e) {
			Assert.assertTrue("Success", e.getMessage().equalsIgnoreCase("Given ID mismatch with the path parameter."));
		}

		/**
		 * Negative Scenario 3 - Submitted Module not found
		 */
		Mockito.when(atSourceSubmittedmoduleRepository.findById(Mockito.anyInt())).thenReturn(Optional.ofNullable(null));

		inputSubmittedmoduleDto = getMockAtsourceSubmittedmoduleDtoWithId();
		try {
			atSourceSurveyAnswerServiceImpl.updateAnswer(ONE, inputSubmittedmoduleDto, ONE);
		} catch (CustomValidationException e) {
			Assert.assertTrue("Success", e.getMessage().equalsIgnoreCase("Submitted module not found."));
		}

		/**
		 * Negative Scenario 4 - Submitted Module already submitted
		 */
		Mockito.when(atSourceSubmittedmoduleRepository.findById(Mockito.anyInt()))
				.thenReturn(Optional.ofNullable(getMockSubmittedAtsourceSubmittedmodule()));

		inputSubmittedmoduleDto = getMockAtsourceSubmittedmoduleDtoWithId();
		try {
			atSourceSurveyAnswerServiceImpl.updateAnswer(ONE, inputSubmittedmoduleDto, ONE);
		} catch (CustomValidationException e) {
			Assert.assertTrue("Success", e.getMessage().equalsIgnoreCase("Submitted module already submitted."));
		}

		/**
		 * Positive Scenario
		 */
		Mockito.when(atSourceSubmittedmoduleRepository.findById(Mockito.anyInt()))
				.thenReturn(Optional.ofNullable(getMockAtsourceSubmittedmodule()));
		Mockito.when(surveyQuestionRepository.findById(Mockito.anyInt())).thenReturn(getMockAtSourceSurveyQuestion());
		Mockito.when(atSourceSurveyAnswerRepo.save(Mockito.any(AtSourceSurveyAnswer.class))).thenReturn(null);
		Mockito.when(atSourceSubmittedmoduleRepository.save(Mockito.any(AtsourceSubmittedmodule.class)))
				.thenReturn(getMockSubmittedAtsourceSubmittedmodule());
		Mockito.when(atSourceSurveyAnswerRepo.findBySubmittedmoduleId(Mockito.anyInt()))
				.thenReturn(getMockAtSourceSurveyAnswersList());

		inputSubmittedmoduleDto = getMockAtsourceSubmittedmoduleDtoWithId();
		responseSubmittedmoduleDto = atSourceSurveyAnswerServiceImpl.updateAnswer(ONE, inputSubmittedmoduleDto, ONE);
		Assert.assertTrue("Success", responseSubmittedmoduleDto.getId().equals(1));
	}

	private AtsourceSubmittedmoduleDto getMockAtsourceSubmittedmoduleDtoWithId() {
		AtsourceSubmittedmoduleDto atsourceSubmittedmoduleDto = new AtsourceSubmittedmoduleDto();
		atsourceSubmittedmoduleDto.setId(1);
		atsourceSubmittedmoduleDto.setAppId(1);
		atsourceSubmittedmoduleDto.setModuleId(58);
		atsourceSubmittedmoduleDto.setFarmerGroupId(1);
		atsourceSubmittedmoduleDto.setStatus(Status.SUBMTTED);
		atsourceSubmittedmoduleDto.setSurveyAnswers(getMockSurveyAnswerDtoList());
		return atsourceSubmittedmoduleDto;
	}

	private AtsourceSubmittedmodule getMockSubmittedAtsourceSubmittedmodule() {
		AtsourceSubmittedmodule atsourceSubmittedmodule = new AtsourceSubmittedmodule();
		atsourceSubmittedmodule.setId(1);
		atsourceSubmittedmodule.setStatus(Status.SUBMTTED);
		atsourceSubmittedmodule.setFarmerGroupId(1);
		return atsourceSubmittedmodule;
	}
	private AtsourceSubmittedmodule getMockApprovedAtsourceSubmittedmodule() {
		AtsourceSubmittedmodule atsourceSubmittedmodule = new AtsourceSubmittedmodule();
		atsourceSubmittedmodule.setId(1);
		atsourceSubmittedmodule.setStatus(Status.APPROVED);
		atsourceSubmittedmodule.setFarmerGroupId(1);
		return atsourceSubmittedmodule;
	}
	private AtsourceSubmittedmodule getMockRejectedAtsourceSubmittedmodule() {
		AtsourceSubmittedmodule atsourceSubmittedmodule = new AtsourceSubmittedmodule();
		atsourceSubmittedmodule.setId(1);
		atsourceSubmittedmodule.setStatus(Status.REJECTED);
		atsourceSubmittedmodule.setFarmerGroupId(1);
		return atsourceSubmittedmodule;
	}
	@Test(expected = CustomValidationException.class)
	public void testGetFarmerGroups_01() throws CustomValidationException {
		List<Long> moduleAssignments = new ArrayList<>();
		moduleAssignments.add(1L);
		
		/* Negative test case */
		Mockito.when(atsourceModuleAssignmentRepository.findByActive(Mockito.anyBoolean()))
				.thenReturn(getMockAtsourceAssignmentList("testMock"));
		Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(getMockAtsourceAssignment());
		Mockito.when(farmerGroupRepository.getFarmerGroupsByCountryIds(moduleAssignments)).thenReturn(getMockFarmerGroupList());
		atSourceSurveyAnswerServiceImpl.getFarmerGroups(Mockito.anyLong());
	}
	@Test(expected = CustomValidationException.class)
	public void testGetFarmerGroups_02() throws CustomValidationException {
		List<Long> moduleAssignments = new ArrayList<>();
		moduleAssignments.add(1L); 
		
		Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(getMockAtsourceAssignment());
		Mockito.when(farmerGroupRepository.getFarmerGroupsByCountryIds(moduleAssignments)).thenReturn(getMockFarmerGroupList());
		
		/* Positive test case */
		Mockito.when(atsourceModuleAssignmentRepository.findByActive(Mockito.anyBoolean()))
		.thenReturn(getMockAtsourceAssignmentList(AtSourceConstants.COUNTRY));
		Mockito.when(userRepository.getDataVisibilityObject(Mockito.anyLong()))
		.thenReturn(AtSourceConstants.COUNTRY);
		Mockito.when(productRepository.getProductsByUserId(Mockito.anyLong()))
		.thenReturn(Collections.emptyList());
		Mockito.when(countryRepository.getCountriesByUserId(Mockito.anyLong()))
		.thenReturn(Collections.emptyList());
		Mockito.when(farmerGroupRepository.getFGByCountriesAndProducts(Mockito.anyList(),Mockito.anyList()))
		.thenReturn(getMockFarmerGroupList());
		Mockito.when(subModuleRepository.getModuleDetails(Mockito.anyInt())).thenReturn(getMockSubModuleResulltList());
		when(modelMapper.map(any(List.class),any())).thenReturn(Collections.emptyList());
		Assert.assertNotNull(atSourceSurveyAnswerServiceImpl.getFarmerGroups(ONE));		
	}
	private List<FarmerGroup> getMockFarmerGroupList() {
		List<FarmerGroup> farmerGroupList = new ArrayList<>();
		FarmerGroup farmerGroup = new FarmerGroup();
		farmerGroup.setFarmerGroupId(1L);
		farmerGroup.setName("Test");
		return farmerGroupList;
	}

	private List<AtsourceModuleAssignment> getMockAtsourceAssignment() {
		List<AtsourceModuleAssignment> atsourceModuleAssignmentList = new ArrayList<>();
		AtsourceModuleAssignment atsourceModuleAssignment = new AtsourceModuleAssignment();
		atsourceModuleAssignment.setId(1);
		atsourceModuleAssignment.setModuleAssignmentId(1);
		atsourceModuleAssignment.setModuleAssignmentType("Product");
		atsourceModuleAssignment.setModuleId(getMockModule());
		atsourceModuleAssignmentList.add(atsourceModuleAssignment);
		return atsourceModuleAssignmentList;
	}	
	private List<AtsourceModuleAssignment> getMockAtsourceAssignmentList(String moduleAssignmentType) {
		List<AtsourceModuleAssignment> atsourceModuleAssignmentList = new ArrayList<>();
		AtsourceModuleAssignment atsourceModuleAssignment = new AtsourceModuleAssignment();
		atsourceModuleAssignment.setId(1);
		atsourceModuleAssignment.setModuleAssignmentId(1);
		atsourceModuleAssignment.setModuleAssignmentType(moduleAssignmentType);
		atsourceModuleAssignment.setModuleId(getMockModule());
		atsourceModuleAssignmentList.add(atsourceModuleAssignment);
		return atsourceModuleAssignmentList;
	}
	private Optional<AtsourceSurveyquestion> getMockAtSourceSurveyQuestion() {
		AtsourceSurveyquestion surveyquestion = new AtsourceSurveyquestion();
		surveyquestion.setId(1);
		return Optional.of(surveyquestion);
	}

	private AtSourceSurveyAnswerDto getMockAtSourceSurveyAnswerDto() {
		AtSourceSurveyAnswerDto surveyAnswerDto = new AtSourceSurveyAnswerDto();
		surveyAnswerDto.setAppId(1);
		surveyAnswerDto.setQuestionId(1);
		surveyAnswerDto.setFarmerGroupId(1);
		surveyAnswerDto.setSubmittedmoduleId(1);
		surveyAnswerDto.setAnswerBoolean(Boolean.TRUE);
		return surveyAnswerDto;
	}

	@SuppressWarnings("unused")
	private AtSourceSurveyAnswerDto getMockInvalidSurveyAnswerDtoWithoutQuestionId() {
		AtSourceSurveyAnswerDto surveyAnswerDto = new AtSourceSurveyAnswerDto();
		surveyAnswerDto.setAppId(1);
		surveyAnswerDto.setFarmerGroupId(1);
		surveyAnswerDto.setSubmittedmoduleId(1);
		surveyAnswerDto.setAnswerBoolean(Boolean.TRUE);
		return surveyAnswerDto;
	}

	@SuppressWarnings("unused")
	private AtSourceSurveyAnswerDto getMockSurveyAnswerDtoWithoutQuestionId() {
		AtSourceSurveyAnswerDto surveyAnswerDto = new AtSourceSurveyAnswerDto();
		surveyAnswerDto.setId(1);
		surveyAnswerDto.setAppId(1);
		surveyAnswerDto.setFarmerGroupId(1);
		surveyAnswerDto.setSubmittedmoduleId(1);
		surveyAnswerDto.setAnswerBoolean(Boolean.TRUE);
		return surveyAnswerDto;
	}

	@SuppressWarnings("unused")
	private AtSourceSurveyAnswerDto getMockInvalidSurveyAnswerDtoWithoutFarmerGroupId() {
		AtSourceSurveyAnswerDto surveyAnswerDto = new AtSourceSurveyAnswerDto();
		surveyAnswerDto.setAppId(1);
		surveyAnswerDto.setQuestionId(1);
		surveyAnswerDto.setSubmittedmoduleId(1);
		surveyAnswerDto.setAnswerBoolean(Boolean.TRUE);
		return surveyAnswerDto;
	}

	@SuppressWarnings("unused")
	private AtSourceSurveyAnswerDto getMockSurveyAnswerDtoWithoutFarmerGroupId() {
		AtSourceSurveyAnswerDto surveyAnswerDto = new AtSourceSurveyAnswerDto();
		surveyAnswerDto.setId(1);
		surveyAnswerDto.setAppId(1);
		surveyAnswerDto.setQuestionId(1);
		surveyAnswerDto.setSubmittedmoduleId(1);
		surveyAnswerDto.setAnswerBoolean(Boolean.TRUE);
		return surveyAnswerDto;
	}

	@SuppressWarnings("unused")
	private AtSourceSurveyAnswerDto getMockInvalidSurveyAnswerDtoWithoutSubModuleId() {
		AtSourceSurveyAnswerDto surveyAnswerDto = new AtSourceSurveyAnswerDto();
		surveyAnswerDto.setAppId(1);
		surveyAnswerDto.setQuestionId(1);
		surveyAnswerDto.setFarmerGroupId(1);
		surveyAnswerDto.setAnswerBoolean(Boolean.TRUE);
		return surveyAnswerDto;
	}

	@SuppressWarnings("unused")
	private AtSourceSurveyAnswerDto getMockSurveyAnswerDtoWithoutSubModuleId() {
		AtSourceSurveyAnswerDto surveyAnswerDto = new AtSourceSurveyAnswerDto();
		surveyAnswerDto.setId(1);
		surveyAnswerDto.setAppId(1);
		surveyAnswerDto.setQuestionId(1);
		surveyAnswerDto.setFarmerGroupId(1);
		surveyAnswerDto.setAnswerBoolean(Boolean.TRUE);
		return surveyAnswerDto;
	}

	@SuppressWarnings("unused")
	private AtSourceSurveyAnswerDto getMockInvalidSurveyAnswerDtoWithoutSubmittedFlag() {
		AtSourceSurveyAnswerDto surveyAnswerDto = new AtSourceSurveyAnswerDto();
		surveyAnswerDto.setAppId(1);
		surveyAnswerDto.setQuestionId(1);
		surveyAnswerDto.setFarmerGroupId(1);
		surveyAnswerDto.setSubmittedmoduleId(1);
		return surveyAnswerDto;
	}

	@SuppressWarnings("unused")
	private AtSourceSurveyAnswerDto getMockSurveyAnswerDtoWithoutSubmittedFlag() {
		AtSourceSurveyAnswerDto surveyAnswerDto = new AtSourceSurveyAnswerDto();
		surveyAnswerDto.setId(1);
		surveyAnswerDto.setAppId(1);
		surveyAnswerDto.setQuestionId(1);
		surveyAnswerDto.setFarmerGroupId(1);
		surveyAnswerDto.setSubmittedmoduleId(1);
		return surveyAnswerDto;
	}

	@SuppressWarnings("unused")
	private AtSourceSurveyAnswerDto getMockInvalidSurveyAnswerDtoWithoutSubmittedAnswer() {
		AtSourceSurveyAnswerDto surveyAnswerDto = new AtSourceSurveyAnswerDto();
		surveyAnswerDto.setAppId(1);
		surveyAnswerDto.setQuestionId(1);
		surveyAnswerDto.setFarmerGroupId(1);
		surveyAnswerDto.setSubmittedmoduleId(1);
		surveyAnswerDto.setAnswerBoolean(Boolean.TRUE);
		return surveyAnswerDto;
	}

	@SuppressWarnings("unused")
	private AtSourceSurveyAnswerDto getMockSurveyAnswerDtoWithoutSubmittedAnswer() {
		AtSourceSurveyAnswerDto surveyAnswerDto = new AtSourceSurveyAnswerDto();
		surveyAnswerDto.setId(1);
		surveyAnswerDto.setAppId(1);
		surveyAnswerDto.setQuestionId(1);
		surveyAnswerDto.setFarmerGroupId(1);
		surveyAnswerDto.setSubmittedmoduleId(1);
		surveyAnswerDto.setAnswerBoolean(Boolean.TRUE);
		return surveyAnswerDto;
	}

	@SuppressWarnings("unused")
	private AtSourceSurveyAnswerDto getMockSurveyAnswerDtoWithId() {
		AtSourceSurveyAnswerDto surveyAnswerDto = new AtSourceSurveyAnswerDto();
		surveyAnswerDto.setId(1);
		surveyAnswerDto.setAppId(1);
		surveyAnswerDto.setQuestionId(1);
		surveyAnswerDto.setFarmerGroupId(1);
		surveyAnswerDto.setSubmittedmoduleId(1);
		surveyAnswerDto.setAnswerBoolean(Boolean.TRUE);
		return surveyAnswerDto;
	}

	@SuppressWarnings("unused")
	private Optional<AtSourceSurveyAnswer> getMockSavedSurveyAnswer() {
		AtSourceSurveyAnswer surveyAnswer = new AtSourceSurveyAnswer();
		surveyAnswer.setAnswerBoolean(Boolean.TRUE);
		surveyAnswer.setAppId(1);
		surveyAnswer.setAnswerDate(new Date());
		surveyAnswer.setAnswerDecimal(new BigDecimal(10.6));
		surveyAnswer.setAnswerInt(10);
		surveyAnswer.setAnswerText("Test String");
		surveyAnswer.setId(10);
		return Optional.of(surveyAnswer);
	}

	@Test
	public void testGetAtSourceSurveyQuestions() throws CustomValidationException {
		Mockito.when(atsourceModuleAssignmentRepository.findByActive(Mockito.anyBoolean()))
				.thenReturn(getMockAtsourceAssignment());
		Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(Optional.ofNullable(getMockModule()));
		Mockito.when(surveyQuestionRepository.findAtsourceQuestionsBySubmodule())
				.thenReturn(getMockAtsourceSurveyquestionList());
		Mockito.when(atSourceLookUpValueRepository.findByActive()).thenReturn(getMockAtsourceSurveylookupvalueList());
		Mockito.when(surveyQuestionRepository.findSubQuestionsByParentId(Mockito.anyString()))
				.thenReturn(getMockAtsourceSurveyquestionList()); 
		Mockito.when(atSourceQuestionsService.getAtSourceQuestions()).thenReturn(getMockAtsourceSurveyquestionList());
		
		List<AtSourceQuestionDto> atSourceQuestionDtos = atSourceSurveyAnswerServiceImpl.getAtSourceSurveyQuestions();
		Assert.assertTrue("Success", atSourceQuestionDtos.size() == 1);
	}

	private Module getMockModule() {
		Module module = new Module();
		module.setId(1);
		module.setActive(true);
		return module;
	}

	private List<AtsourceSurveyquestion> getMockAtsourceSurveyquestionList() {
		List<AtsourceSurveyquestion> atsourceSurveyquestionList = new ArrayList<>();
		atsourceSurveyquestionList.add(getMockAtsourceSurveyquestion());
		return atsourceSurveyquestionList;
	}

	private AtsourceSurveyquestion getMockAtsourceSurveyquestion() {
		AtsourceSurveyquestion atsourceSurveyquestion = new AtsourceSurveyquestion();
		atsourceSurveyquestion.setId(1);
		atsourceSurveyquestion.setDisplayType(AtSourceConstants.PARENT_QUESTION_REPEATER);
		atsourceSurveyquestion.setAtsourceSurveyanswers(getMockAtSourceSurveyAnswersList());
		return atsourceSurveyquestion;
	}

	private List<AtsourceSurveylookupvalue> getMockAtsourceSurveylookupvalueList() {
		List<AtsourceSurveylookupvalue> atsourceSurveylookupvalueList = new ArrayList<>();
		atsourceSurveylookupvalueList.add(getMockAtsourceSurveylookupvalue());
		return atsourceSurveylookupvalueList;
	}

	private AtsourceSurveylookupvalue getMockAtsourceSurveylookupvalue() {
		AtsourceSurveylookupvalue atsourceSurveylookupvalue = new AtsourceSurveylookupvalue();
		atsourceSurveylookupvalue.setId(1);
		atsourceSurveylookupvalue.setQuestion(getMockAtsourceSurveyquestion());
		return atsourceSurveylookupvalue;
	}
	
	
	@Test
	public void testGetSurveyAnswersByFarmerGroupId() throws CustomValidationException {
		/* Empty List */
		Mockito.when(atSourceSurveyAnswerRepo.findByFarmerGroupId(Mockito.anyInt())).thenReturn(Collections.emptyList());
		List<AtSourceSurveyAnswerDto> result = atSourceSurveyAnswerServiceImpl.getSurveyAnswersByFarmerGroupId(1);
		Assert.assertEquals(Collections.emptyList(), result);
		
		/* with data */
		Mockito.when(atSourceSurveyAnswerRepo.findByFarmerGroupId(Mockito.anyInt())).thenReturn(getMockAtSourceSurveyAnswersList());
		result = atSourceSurveyAnswerServiceImpl.getSurveyAnswersByFarmerGroupId(1);
		Assert.assertEquals(1, result.size());
	}
	
	@Test
	public void testGetPaginatedSurveyAnswers() throws Exception{
		
		Pageable pageable = mock(Pageable.class);
		 Page<AtSourceSurveyAnswer> surveyAnswerPage = mock(Page.class);
		 when(surveyAnswerPage.getContent()).thenReturn(getMockAtSourceSurveyAnswersList());
		 when(surveyAnswerPage.getSize()).thenReturn(1);
		 when(surveyAnswerPage.getTotalPages()).thenReturn(1);
		// when(surveyAnswerPage.getPageable().getPageNumber()).thenReturn(1);
		 when(surveyAnswerPage.getTotalElements()).thenReturn(ONE);
		 Mockito.when(atSourceSurveyAnswerRepo.findAll(pageable)).thenReturn(surveyAnswerPage);
		PaginationResult<AtSourceSurveyAnswerDto> result = atSourceSurveyAnswerServiceImpl.getPaginatedSurveyAnswers(1,10,"farmerGroup","asc");
		Assert.assertNotNull(result);
	}
	
	@Test
	public void testFindByFarmerGroupId() throws Exception{
		Mockito.when(atSourceSurveyAnswerRepo.findBySubmittedmoduleId(Mockito.anyInt())).thenReturn(getMockAtSourceSurveyAnswersList());
		
		when(modelMapper.map(any(AtsourceSubmittedmodule.class),any())).thenReturn(getMockAtsourceSubmittedmoduleDtoWithAnswers());
		when(modelMapper.map(any(AtSourceSurveyAnswer.class),any())).thenReturn(getMockAtSourceSurveyAnswerDto());
		
		/* Status is Approved  */
		Mockito.when(atSourceSubmittedmoduleRepository.findCurrentSurveyByFarmerGroupId(Mockito.anyInt())).thenReturn(getMockApprovedAtsourceSubmittedmodule());
		Assert.assertNotNull(atSourceSurveyAnswerServiceImpl.findByFarmerGroupId(ONE));
		
		Mockito.when(atSourceSubmittedmoduleRepository.findCurrentSurveyByFarmerGroupId(Mockito.anyInt())).thenReturn(getMockSubmittedAtsourceSubmittedmodule());
		Assert.assertNotNull(atSourceSurveyAnswerServiceImpl.findByFarmerGroupId(ONE));
	}
	
	@Test
	public void testSaveAtsourceSurveyResponses_01() throws Exception{
		Mockito.when(atSourceSubmittedmoduleRepository.findAllById(Mockito.any())).thenReturn(getMockAtsourceSubmittedmoduleList());
		Mockito.when(atSourceSubmittedmoduleRepository.findMaxVersionNumberById(Mockito.anyInt())).thenReturn(5);
		Mockito.when(atSourceSubmittedmoduleRepository.saveAll(Mockito.any())).thenReturn(null);
		
		/* APPROVED status */
		MessageDto response = atSourceSurveyAnswerServiceImpl.saveAtsourceSurveyResponses(getMockAtsourceSurveyResponseDtoList(), ONE);
		Assert.assertEquals(response.getMessage(), AtSourceConstants.SUCCESS); 
	}
	@Test 
	public void testSaveAtsourceSurveyResponses_02() throws Exception{
		Mockito.when(atSourceSubmittedmoduleRepository.findAllById(Mockito.any())).thenReturn(getMockAtsourceSubmittedmoduleList());
		Mockito.when(atSourceSubmittedmoduleRepository.findMaxVersionNumberById(Mockito.anyInt())).thenReturn(5);
		Mockito.when(atSourceSubmittedmoduleRepository.saveAll(Mockito.anyObject())).thenReturn(null);
		
		/* NULL input */
		try {
			atSourceSurveyAnswerServiceImpl.saveAtsourceSurveyResponses(null, ONE);
		}
		catch(CustomValidationException e) {
			Assert.assertEquals(ErrorCode.OFIS_ATSOURCE_2031.getMessage(), e.getMessage());
		}	
	}
	@Test
	public void testSaveAtsourceSurveyResponses_03() throws Exception{
		Mockito.when(atSourceSubmittedmoduleRepository.findAllById(Mockito.any())).thenReturn(getMockAtsourceSubmittedmoduleList());
		Mockito.when(atSourceSubmittedmoduleRepository.findMaxVersionNumberById(Mockito.anyInt())).thenReturn(5);
		Mockito.when(atSourceSubmittedmoduleRepository.saveAll(Mockito.anyObject())).thenReturn(null);
		
		/* Missing Mandatory value */
		try {
			atSourceSurveyAnswerServiceImpl.saveAtsourceSurveyResponses(getMockMissingAtsourceSurveyResponseDtoList(), ONE);
		}
		catch(CustomValidationException e) {
			Assert.assertEquals(ErrorCode.OFIS_ATSOURCE_2032.getMessage(), e.getMessage());
		}	
	}

	private List<AtsourceSubmittedmodule> getMockAtsourceSubmittedmoduleList() {
		List<AtsourceSubmittedmodule> asmList = new ArrayList<AtsourceSubmittedmodule>();
		asmList.add(getMockSubmittedAtsourceSubmittedmodule());
		asmList.add(getMockApprovedAtsourceSubmittedmodule());
		asmList.add(getMockRejectedAtsourceSubmittedmodule());
		return asmList;
	}

	private List<AtsourceSurveyResponseDto> getMockAtsourceSurveyResponseDtoList() {
		List<AtsourceSurveyResponseDto> asrList = new ArrayList<AtsourceSurveyResponseDto>();
		asrList.add(getMockApprovedAtsourceSurveyResponseDto());
		asrList.add(getMockSubmittedAtsourceSurveyResponseDto());
		asrList.add(getMockRejectedAtsourceSurveyResponseDto());
		return asrList;
	}

	private AtsourceSurveyResponseDto getMockApprovedAtsourceSurveyResponseDto() {
		AtsourceSurveyResponseDto dto = new AtsourceSurveyResponseDto();
		dto.setFarmerGroupId(1);
		dto.setStatus(Status.APPROVED);
		dto.setSubmittedModuleId(1);
		return dto;
	}

	private AtsourceSurveyResponseDto getMockSubmittedAtsourceSurveyResponseDto() {
		AtsourceSurveyResponseDto dto = new AtsourceSurveyResponseDto();
		dto.setFarmerGroupId(1);
		dto.setStatus(Status.SUBMTTED);
		dto.setSubmittedModuleId(1);
		return dto;
	}

	private AtsourceSurveyResponseDto getMockRejectedAtsourceSurveyResponseDto() {
		AtsourceSurveyResponseDto dto = new AtsourceSurveyResponseDto();
		dto.setFarmerGroupId(1);
		dto.setStatus(Status.REJECTED);
		dto.setSubmittedModuleId(1);
		return dto;
	}
	private List<AtsourceSurveyResponseDto> getMockMissingAtsourceSurveyResponseDtoList() {
		List<AtsourceSurveyResponseDto> asrList = new ArrayList<AtsourceSurveyResponseDto>();

		AtsourceSurveyResponseDto dto = new AtsourceSurveyResponseDto();
		dto.setFarmerGroupId(null);
		dto.setStatus(Status.REJECTED);
		asrList.add(dto);
		return asrList;
	}
	private List<SubModuleResullt> getMockSubModuleResulltList()
	{
		List<SubModuleResullt> smrList = new ArrayList<SubModuleResullt>();
		return smrList;
	}
}