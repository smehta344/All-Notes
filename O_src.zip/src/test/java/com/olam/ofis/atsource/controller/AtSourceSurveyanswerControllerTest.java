/*******************************************************************************
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 *******************************************************************************/

package com.olam.ofis.atsource.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.gson.Gson;
import com.olam.ofis.atsource.dto.AtSourceQuestionDto;
import com.olam.ofis.atsource.dto.AtSourceSurveyAnswerDto;
import com.olam.ofis.atsource.dto.AtsourceSubmittedmoduleDto;
import com.olam.ofis.atsource.dto.AtsourceSurveyResponseDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.ModuleDto;
import com.olam.ofis.atsource.dto.UserDTO;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.service.AtSourceSurveyAnswerService;
import com.olam.ofis.atsource.util.PaginationResult;
import com.olam.ofis.atsource.util.RetrieveUserData;

/**
 * Class - AtSourceSurveyanswerControllerTest
 *
 * @author Mohammed Mahroof
 *
 */
public class AtSourceSurveyanswerControllerTest {

    MockMvc mockMvc;

    @Mock
    AtSourceSurveyAnswerService atSourceSurveyAnswerService;

    @Mock
    RetrieveUserData retrieveUserData;

    @InjectMocks
    private AtSourceSurveyanswerController atSourceSurveyanswerController;
    
    private static String tokenString
            = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJsYW5ndWFnZUlTT0NvZGUiOiJlbiIsInRpbWV6b25lSXNvQ29kZSI6IldJQiIsI";

    @Before
   	public void init() {
   		MockitoAnnotations.initMocks(this);
   		mockMvc = MockMvcBuilders.standaloneSetup(atSourceSurveyanswerController).build();
   	}
    
    @Test
    public void getAllAtsourceSubModulesTest() throws Exception {
        List<AtSourceSurveyAnswerDto> atSourceSurveyAnswerDtos = new ArrayList<>();
        Mockito.when(atSourceSurveyAnswerService.findAll()).thenReturn(atSourceSurveyAnswerDtos);
        this.mockMvc.perform(
                get("/atsource/answers/surveyAnswers")
                    .header("Authorization", "Bearer " + tokenString)
                    .contentType(MediaType.APPLICATION_JSON)).andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    public void getPaginatedSurveyAnswersTest() throws Exception {
        PaginationResult<AtSourceSurveyAnswerDto> paginationResult = new PaginationResult<>();
        Mockito.when(atSourceSurveyAnswerService.getPaginatedSurveyAnswers(anyInt(), anyInt(), anyString(), anyString()))
                .thenReturn(paginationResult);
        this.mockMvc.perform(
                get("/atsource/answers/surveyAnswer/paginated")
                    .header("Authorization", "Bearer " + tokenString)
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void getSurveyAnswersByIdTest() throws Exception {
        AtSourceSurveyAnswerDto atSourceSurveyAnswerDto = new AtSourceSurveyAnswerDto();
        Mockito.when(atSourceSurveyAnswerService.findById(anyLong())).thenReturn(atSourceSurveyAnswerDto);
        this.mockMvc.perform(
                get("/atsource/answers/surveyAnswer/1")
                    .header("Authorization", "Bearer " + tokenString)
                    .contentType(MediaType.APPLICATION_JSON)).andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    public void getSurveyAnswersByFarmerGroupIdTest() throws Exception {
        List<AtSourceSurveyAnswerDto> atSourceSurveyAnswerDtos = new ArrayList<>();
        Mockito.when(atSourceSurveyAnswerService.getSurveyAnswersByFarmerGroupId(anyInt()))
                .thenReturn(atSourceSurveyAnswerDtos);
        this.mockMvc.perform(
                get("/atsource/answers/surveyAnswerByFarmerGroup/1")
                    .header("Authorization", "Bearer " + tokenString)
                    .contentType(MediaType.APPLICATION_JSON)).andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    public void getSurveyQuestionsTest() throws Exception {
        List<AtSourceQuestionDto> atSourceSurveyAnswerDtos = new ArrayList<>();
        Mockito.when(atSourceSurveyAnswerService.getAtSourceSurveyQuestions()).thenReturn(atSourceSurveyAnswerDtos);
        this.mockMvc.perform(
                get("/atsource/answers/surveyQuestionswithLookupValues")
                    .header("Authorization", "Bearer " + tokenString)
                    .contentType(MediaType.APPLICATION_JSON)).andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    public void createAtSourceSurveyAnswerTest() throws CustomValidationException, Exception {
        AtsourceSubmittedmoduleDto atsourceSubmittedmoduleDto = new AtsourceSubmittedmoduleDto();
        UserDTO userDTO = new UserDTO();
        Mockito.when(retrieveUserData.getUserData(any())).thenReturn(userDTO);
        Mockito.when(atSourceSurveyAnswerService.createAnswer(any(AtsourceSubmittedmoduleDto.class), anyLong()))
                .thenReturn(atsourceSubmittedmoduleDto);
        this.mockMvc.perform(
                post("/atsource/answers/surveyAnswer")
                     .header("Authorization", "Bearer " + tokenString).header("App-Id", 1)
                     .contentType(MediaType.APPLICATION_JSON).content(new Gson().toJson(atsourceSubmittedmoduleDto)))
                .andExpect(status().isOk());
    }

    @Test
    public void updateAtSourceSurveyAnswerTest() throws CustomValidationException, Exception {
        AtsourceSubmittedmoduleDto atsourceSubmittedmoduleDto = new AtsourceSubmittedmoduleDto();
        UserDTO userDTO = new UserDTO();
        Mockito.when(retrieveUserData.getUserData(any())).thenReturn(userDTO);
        Mockito.when(atSourceSurveyAnswerService.updateAnswer(anyLong(), any(AtsourceSubmittedmoduleDto.class), anyLong()))
                .thenReturn(atsourceSubmittedmoduleDto);
        this.mockMvc.perform(
                put("/atsource/answers/surveyAnswer/1")
                    .header("Authorization", "Bearer " + tokenString).header("App-Id", 1)
                    .contentType(MediaType.APPLICATION_JSON).content(new Gson().toJson(atsourceSubmittedmoduleDto)))
                .andExpect(status().isOk());
    }

    @Test
    public void getFarmerGroupsTest() throws Exception {
        ModuleDto moduleDto = new ModuleDto();
        UserDTO userDTO = new UserDTO();
        Mockito.when(retrieveUserData.getUserData(any())).thenReturn(userDTO);
        Mockito.when(atSourceSurveyAnswerService.getFarmerGroups(anyLong())).thenReturn(moduleDto);
        this.mockMvc.perform(
                get("/atsource/answers/getFarmerGroups")
                    .header("Authorization", "Bearer " + tokenString)
                    .contentType(MediaType.APPLICATION_JSON)).andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    public void getSurveyAnswerByFarmerGroupIdTest() throws Exception {
        AtsourceSubmittedmoduleDto submittedmoduleDto = new AtsourceSubmittedmoduleDto();
        Mockito.when(atSourceSurveyAnswerService.findByFarmerGroupId(anyLong())).thenReturn(submittedmoduleDto);
        this.mockMvc.perform(
                get("/atsource/answers/surveyAnswerByFarmerGroup/1")
                    .header("Authorization", "Bearer " + tokenString)
                    .contentType(MediaType.APPLICATION_JSON)).andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    public void saveAtsourceSurveyResponsesTest() throws CustomValidationException, Exception {
        List<AtsourceSurveyResponseDto> atsourceSurveyResponseDtos = new ArrayList<>();
        MessageDto messageDto = new MessageDto();
        UserDTO userDTO = new UserDTO();
        Mockito.when(retrieveUserData.getUserData(any())).thenReturn(userDTO);
        Mockito.when(atSourceSurveyAnswerService.saveAtsourceSurveyResponses(anyList(), anyLong()))
                .thenReturn(messageDto);
        this.mockMvc.perform(
                put("/atsource/answers/atSourceSurveyResponse")
                    .header("Authorization", "Bearer " + tokenString).header("App-Id", 1)
                    .contentType(MediaType.APPLICATION_JSON).content(new Gson().toJson(atsourceSurveyResponseDtos)))
                .andExpect(status().isOk());
    }
    @Test
    public void testGetSurveyAnswersByFarmerGroupId() throws CustomValidationException, Exception {
    	  Mockito.when(atSourceSurveyAnswerService.getSurveyAnswersByFarmerGroupId(anyInt())).thenReturn(null);
    	this.mockMvc.perform(
                get("/atsource/answers/surveyAnswer/farmerGroup")
                .param("farmerGroupId", "1")
                    .header("Authorization", "Bearer " + tokenString).header("App-Id", 1)
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

}