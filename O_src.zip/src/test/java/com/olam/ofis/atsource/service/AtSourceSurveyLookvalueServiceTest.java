/*******************************************************************************
 * Copyright (c) 2019 OLAM Limited
 * 
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited.
 ******************************************************************************/
package com.olam.ofis.atsource.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.junit4.SpringRunner;

import com.olam.ofis.atsource.AtSourceApplication;
import com.olam.ofis.atsource.dto.AtsourceQuestionResult;
import com.olam.ofis.atsource.dto.AtsourceSurveyLookupvalueDto;
import com.olam.ofis.atsource.dto.AtsourceSurveyLookupvalueQueryResult;
import com.olam.ofis.atsource.dto.AtsourcelookupValueResult;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.model.AtsourceSurveylookupvalue;
import com.olam.ofis.atsource.repository.AtSourceLookUpValueRepository;
import com.olam.ofis.atsource.service.impl.AtsourceSurveyLookupvalueServiceImpl;
import com.olam.ofis.atsource.util.CommonUtil;
import com.olam.ofis.atsource.util.PaginationResult;

/**
 * Created by Ideas2it-Karthick on 8/4/19.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = AtSourceApplication.class)
public class AtSourceSurveyLookvalueServiceTest {

    @Autowired
    private AtsourceSurveyLookupvalueServiceImpl atsourceSurveyLookupvalueService;
    @MockBean
    private AtSourceLookUpValueRepository atSourceLookUpValueRepository;

    @Test
    public void testGetAllLookupValuesSuccess() {
        Pageable pageable = CommonUtil.getPageRequest(1,10,"desc","desc");
        when(atSourceLookUpValueRepository.findAllActiveLookupValue(pageable)).thenReturn(getPaginatedAtSourceLookupValueMock());
        PaginationResult<?> paginationResult = atsourceSurveyLookupvalueService.getAllLookupValues(1,10,"desc","desc");
        Assert.assertEquals(1, paginationResult.getContent().size());
    }

    @Test(expected=NullPointerException.class)
    public void testGetAllLookupValuesFail() {
        Pageable pageable = CommonUtil.getPageRequest(1,10,"desc","desc");
        when(atSourceLookUpValueRepository.findAllActiveLookupValue(pageable)).thenReturn(null);
        PaginationResult<?> paginationResult = atsourceSurveyLookupvalueService.getAllLookupValues(1,10,"desc","desc");
        Assert.assertEquals(1, paginationResult.getContent().size());
    }

    @Test
    public void testGetLookUpValueByIdSuccess() {
        when(atSourceLookUpValueRepository.getLookUpValueById(1)).thenReturn(getAtSourceLookupValueMock());
        AtsourceSurveyLookupvalueDto atsourceSurveyLookupvalueDto = atsourceSurveyLookupvalueService.getLookUpValueById(1);
        Assert.assertEquals(Integer.valueOf(1), atsourceSurveyLookupvalueDto.getId());
    }


    @Test
    public void testGetLookUpValueByIdFail() {
        when(atSourceLookUpValueRepository.getLookUpValueById(1)).thenReturn(null);
        AtsourceSurveyLookupvalueDto atsourceSurveyLookupvalueDto = atsourceSurveyLookupvalueService.getLookUpValueById(1);
        Assert.assertNull(atsourceSurveyLookupvalueDto.getId());
    }

    @Test
    public void testSaveLookUpValueSuccess() {
        MessageDto messageDto = null;
        try {
            when(atSourceLookUpValueRepository.save(getAtSourceLookupValueMock())).thenReturn(null);
            when(atSourceLookUpValueRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(getAtSourceLookupValueMock()));
            messageDto = atsourceSurveyLookupvalueService.saveLookUpValue(Mockito.anyLong(), getAtSourceLookupValueDTOMock());
        } catch (CustomValidationException e) {
            e.printStackTrace();
        }
        Assert.assertEquals("Success", messageDto.getMessage());
    }

    @Test
    public void testSaveLookUpValueFail() {
        MessageDto messageDto = null;
        try {
        	when(atSourceLookUpValueRepository.save(getAtSourceLookupValueMock())).thenReturn(null);
            when(atSourceLookUpValueRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(getAtSourceLookupValueMock()));
            messageDto = atsourceSurveyLookupvalueService.saveLookUpValue(Mockito.anyLong(), getAtSourceLookupValueDTOMock());
        } catch (CustomValidationException e) {
            e.printStackTrace();
        }
        Assert.assertEquals("Success", messageDto.getMessage());
    }

    private AtsourceSurveylookupvalue getAtSourceLookupValueMock() {
        AtsourceSurveylookupvalue atsourceSurveylookupvalue = new AtsourceSurveylookupvalue();
        atsourceSurveylookupvalue.setId(1);
        return atsourceSurveylookupvalue;
    }

    private AtsourceSurveyLookupvalueDto getAtSourceLookupValueDTOMock() {
        AtsourceSurveyLookupvalueDto atsourceSurveyLookupvalueDto = new AtsourceSurveyLookupvalueDto();
        atsourceSurveyLookupvalueDto.setId(1);
        atsourceSurveyLookupvalueDto.setQuestionId(1);
        return atsourceSurveyLookupvalueDto;
    }

    private Page<AtsourceSurveyLookupvalueQueryResult> getPaginatedAtSourceLookupValueMock() {
        return new Page<AtsourceSurveyLookupvalueQueryResult>() {
            @Override
            public int getTotalPages() {
                return 1;
            }

            @Override
            public long getTotalElements() {
                return 10;
            }

            @Override
            public <U> Page<U> map(Function<? super AtsourceSurveyLookupvalueQueryResult, ? extends U> function) {
                return null;
            }

            @Override
            public int getNumber() {
                return 0;
            }

            @Override
            public int getSize() {
                return 1;
            }

            @Override
            public int getNumberOfElements() {
                return 0;
            }

            @Override
            public List<AtsourceSurveyLookupvalueQueryResult> getContent() {
                return getAtsourceSurveyLookupvalueQueryResultMock();
            }

            @Override
            public boolean hasContent() {
                return false;
            }

            @Override
            public Sort getSort() {
                return null;
            }

            @Override
            public boolean isFirst() {
                return false;
            }

            @Override
            public boolean isLast() {
                return false;
            }

            @Override
            public boolean hasNext() {
                return false;
            }

            @Override
            public boolean hasPrevious() {
                return false;
            }

            @Override
            public Pageable nextPageable() {
                return null;
            }

            @Override
            public Pageable previousPageable() {
                return null;
            }

            @Override
            public Iterator<AtsourceSurveyLookupvalueQueryResult> iterator() {
                return null;
            }
        };
    }

    private List<AtsourceSurveyLookupvalueQueryResult> getAtsourceSurveyLookupvalueQueryResultMock() {
        List<AtsourceSurveyLookupvalueQueryResult> atsourceSurveyLookupvalueQueryResultList = new ArrayList<>();
        AtsourceSurveyLookupvalueQueryResult atsourceSurveyLookupvalueQueryResult = new AtsourceSurveyLookupvalueQueryResult() {
            @Override
            public AtsourcelookupValueResult getAtsourcelookupValueResult() {
                return new AtsourcelookupValueResult() {
                    @Override
                    public Integer getId() {
                        return 1;
                    }

                    @Override
                    public Integer getPosition() {
                        return 1;
                    }

                    @Override
                    public String getValue() {
                        return null;
                    }

                    @Override
                    public String getValueFr() {
                        return null;
                    }

                    @Override
                    public String getValueEs() {
                        return null;
                    }

                    @Override
                    public String getValueId() {
                        return null;
                    }

                    @Override
                    public String getValuePt() {
                        return null;
                    }

                    @Override
                    public String getValueTr() {
                        return null;
                    }

                    @Override
                    public String getValueLo() {
                        return null;
                    }

                    @Override
                    public String getValueVi() {
                        return null;
                    }

                    @Override
                    public String getValueTh() {
                        return null;
                    }

                    @Override
                    public Byte getActive() {
                        return null;
                    }
                };
            }

            @Override
            public AtsourceQuestionResult getQuestion() {
                return new AtsourceQuestionResult() {
                    @Override
                    public Integer getId() {
                        return 1;
                    }

                    @Override
                    public String getQuestion() {
                        return "Test";
                    }

                    @Override
                    public Integer getPosition() {
                        return null;
                    }

                    @Override
                    public Integer getAppId() {
                        return null;
                    }

                    @Override
                    public Byte getActive() {
                        return null;
                    }

                    @Override
                    public String getKmCode() {
                        return null;
                    }

                    @Override
                    public Long getMinValue() {
                        return null;
                    }

                    @Override
                    public Long getMaxValue() {
                        return null;
                    }
                };
            }
        };
        atsourceSurveyLookupvalueQueryResultList.add(atsourceSurveyLookupvalueQueryResult);
        return atsourceSurveyLookupvalueQueryResultList;
    }
}
