/*******************************************************************************

 * Copyright (c) 2019 OLAM Limited

 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited

 *******************************************************************************/
package com.olam.ofis.atsource.util;

import java.lang.reflect.Method;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

/**
 * @author Mohammed Mahroof
 */
public class TestObjectService {

    public static boolean testObject(Map<Class<?>, Object> classNameMap) {
        if (classNameMap != null && !classNameMap.isEmpty()) {
            Object object = null;
            try {
                for (Map.Entry<Class<?>, Object> entry : classNameMap.entrySet()) {

                    Class<?> dtoClassNm = entry.getKey();
                    object = entry.getValue();

                    Method[] methods = dtoClassNm.getDeclaredMethods();

                    // Run the setter and then the getter
                    for (Method method : methods) {
                        try {

                            // For Setter
                            if (StringUtils.startsWith(method.getName(), "set")) {
                                Class<?> parameterClass = method.getParameterTypes()[0];
                                if (parameterClass == String.class) {
                                    method.invoke(object, "stringVal");
                                }
                                if (parameterClass == Long.class) {
                                    method.invoke(object, 1L);
                                }
                                if (parameterClass == Double.class) {
                                    method.invoke(object, 0.00);
                                }
                                if (parameterClass == boolean.class) {
                                    method.invoke(object, true);
                                }
                                if (parameterClass == Integer.class) {
                                    method.invoke(object, 0);
                                }
                                if (parameterClass == LocalDate.class) {
                                    method.invoke(object, LocalDate.now());
                                }
                                if (parameterClass == Date.class) {
                                    method.invoke(object, new Date());
                                }
                                if (parameterClass == List.class) {
                                    method.invoke(object, new ArrayList<>());
                                }
                                if (parameterClass == Boolean.class) {
                                    method.invoke(object, Boolean.TRUE);
                                }
                                if (parameterClass == LocalDate.class) {
                                    method.invoke(object, LocalDate.now());
                                }
                                if (parameterClass == LocalDateTime.class) {
                                    method.invoke(object, LocalDateTime.now());
                                }
                                if (parameterClass == int.class) {
                                    method.invoke(object, 0);
                                }
                                if (parameterClass == Time.class) {
                                    method.invoke(object, new Time(1L));
                                }
                                if (parameterClass == char.class) {
                                    method.invoke(object, 'c');
                                }
                                if (parameterClass == Character.class) {
                                    method.invoke(object, 'c');
                                }
                                if (parameterClass == Object.class) {
                                    method.invoke(object, new Object());
                                }
                            }
                            // For ToString
                            if (StringUtils.startsWith(method.getName(), "toString")) {
                                method.invoke(object);
                            }
                            // For Getter methods starting with is
                            if (StringUtils.startsWith(method.getName(), "is")) {
                                method.invoke(object);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    for (Method method : methods) {
                        // For Getter
                        try {
                            if (StringUtils.startsWith(method.getName(), "get")) {
                                method.invoke(object);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return true;
    }
}
