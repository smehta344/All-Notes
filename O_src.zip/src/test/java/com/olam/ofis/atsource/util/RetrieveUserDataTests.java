/*
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 */
package com.olam.ofis.atsource.util;

import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

/**
 * @author LTI Developer
 *
 */
public class RetrieveUserDataTests {

	private String tokenString = "Bearer eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIzNTAiLCJuYmYiOjE1Njg4MDY0MTgsInVzZXJfbmFtZSI6IjcxOSIsInNjb3BlIjpbIioiXSwiaXNzIjoib2xhbUF1dGgiLCJsYW5ndWFnZV9pc29fY29kZSI6ImVuIiwiZXhwIjoxNTY5NDExMjE4LCJpYXQiOjE1Njg4MDY0MTgsImNsaWVudF9pZCI6IjMiLCJqdGkiOiJUeWViVC1HdkNjbDlaazVkc0ZFZkZEcVlKTTI3U21TaVpiLWE1b1IzZF9IdVpGbFBRX0duaTFBV0JpeGYyVS03YjBJYUc5eV9hRktOOEI3MERXRlZ3dFJCS3h1LWZuMmVNajVsVlpZZXZHQUJQVnItaVo1VjlaeEdjVWJjT19yUHQ0NElEZyJ9.nryEQZusJapDKn9LcZhxzq3DsCuYgoT7ar757Mr_0IWzn8JHwGXk5fgsbfdMHypYJeITmwo5Lmh3V9xsruJnv6RXWSsJFmsf8TAZwtheMjZLKTVdrE-DGmBMc4OJv5RXS-AKR5aAWTmxJdBj7f4cWeQnykBCbFyfxCHpTBfsqxiAsiGzKnju5aZsp_tqYaBz6N569ERQiOQSkw-SFuUbuUO3Xy9noGoB96-_mDfHTDIDtBL3Aa4YzCiln4peEgVyxGXEtf8ZpYoBxyJeyT-9xEvJEHaIiFFA2lNACj_cI5p6kKbmFmjzwO1AWsT7UYZ4Uz523mjt7GATu2Zd3PAdKKhSB1x2Oqs0oFiuN1dxhfdfHznkOybA1yZqpavHfvaskjuoWAUnIU5cUhLgzweDVUj0ajEe4oqD1zouGNFrsJGTWNw6T72ALFb-HUBmXMla-Qf3JxLhQFpvb4tujx0iDiqCjqkLi1dAk9o0P-2g4U-z_MBl59z7ZP3zAKxC9ljbA15EYmv2qMDeChSyf6VtgxyFNTyuPjPgFuAJgLboVttBj75ljRMEk78hXDHKBQ03ylf0m4c0JdedAGZzFDs8Wao4jBaxa01BEpi1PHPWSfX5iQCtFXe6ulZ1iRaESuAHXrXvz-esgvOFCh6kp3yXxjxDPZq7wVDkrGKq_n5TYyg";

	@Mock
	private HttpServletRequest request;

	@InjectMocks
	private RetrieveUserData retrieveUserData;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testRetrieveUserData() {
		when(request.getHeader(Mockito.anyString())).thenReturn(tokenString);
		Assert.assertNotNull(retrieveUserData.getUserData(request));
	}

}
