/*******************************************************************************
 * Copyright (c) 2019 OLAM Limited
 * 
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited.
 ******************************************************************************/
package com.olam.ofis.atsource.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.junit4.SpringRunner;

import com.olam.ofis.atsource.AtSourceApplication;
import com.olam.ofis.atsource.dto.AtSourceQuestionDto;
import com.olam.ofis.atsource.dto.AtsourceQuestionResult;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.SubModuleDto;
import com.olam.ofis.atsource.dto.SubModuleResult;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.model.AtsourceModuleAssignment;
import com.olam.ofis.atsource.model.AtsourceSurveyquestion;
import com.olam.ofis.atsource.model.Module;
import com.olam.ofis.atsource.model.SubModule;
import com.olam.ofis.atsource.repository.AtSourceSurveyQuestionRepository;
import com.olam.ofis.atsource.repository.AtsourceModuleAssignmentRepository;
import com.olam.ofis.atsource.repository.AtsourceSurveyquestionQueryResult;
import com.olam.ofis.atsource.repository.DataTypeResult;
import com.olam.ofis.atsource.repository.SubModuleRepository;
import com.olam.ofis.atsource.service.impl.AtSourceQuestionsServiceImpl;
import com.olam.ofis.atsource.util.CommonUtil;
import com.olam.ofis.atsource.util.PaginationResult;

/**
 * Created by Ideas2it-Karthick on 8/4/19.
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AtSourceApplication.class)
public class AtSourceQuestionServiceTest {

    @Autowired
    private AtSourceQuestionsServiceImpl atSourceQuestionsService;
    @MockBean
    private AtSourceSurveyQuestionRepository atSourceSurveyQuestionRepository;
    @MockBean
    private AtsourceModuleAssignmentRepository atsourceModuleAssignmentRepository;
    @MockBean
    private SubModuleRepository subModuleRepository;


    @Test
    public void testGetAllAtsourceQuestionsSuccess() {
        Pageable pageable = CommonUtil.getPageRequest(1,10,"desc","desc");
        when(atSourceSurveyQuestionRepository.findAllQuestionsResult(pageable)).thenReturn(getPaginatedAtSourceQuestionMock());
        PaginationResult<?> paginationResult = atSourceQuestionsService.getAllAtsourceQuestions(1,10,"desc","desc");
        Assert.assertEquals(1, paginationResult.getContent().size());
    }


    @Test(expected=NullPointerException.class)
    public void testGetAllAtsourceQuestionsFail() {
        Pageable pageable = CommonUtil.getPageRequest(1,10,"desc","desc");
        when(atSourceSurveyQuestionRepository.findAllActiveQuestions(pageable)).thenReturn(null);
        atSourceQuestionsService.getAllAtsourceQuestions(1,10,"desc","desc");
    }

    @Test
    public void testSaveAtsourceQuestionSuccess() {
        MessageDto messageDto = null;
        when(atSourceSurveyQuestionRepository.save(getAtSourceQuestionData().get(0))).thenReturn(getAtSourceQuestionData().get(0));
        try {
            messageDto = atSourceQuestionsService.saveQuestion(1L,getAtSourceQuestionMockDto());
        } catch (CustomValidationException e) {
            Assert.fail("Custom Validation Exception "+e.getErrorCode());
        }
        Assert.assertEquals("Success",messageDto.getMessage());
    }

    @Test
    public void testSaveAtsourceQuestionFail() {
        MessageDto messageDto = null;
        when(atSourceSurveyQuestionRepository.save(getAtSourceQuestionData().get(0))).thenReturn(null);
        try {
            messageDto = atSourceQuestionsService.saveQuestion(1L,null);
        } catch (CustomValidationException e) {
            Assert.fail("Custom Validation Exception "+e.getErrorCode());
        }
        Assert.assertNull(messageDto.getMessage());
    }

    @Test
    public void testGetQuestionByIdSuccess() {
        when(atSourceSurveyQuestionRepository.getQuestionById(1)).thenReturn(getAtSourceQuestionData().get(0));
        AtSourceQuestionDto atSourceQuestionDto = atSourceQuestionsService.getQuestionById(1);
        Assert.assertEquals(Integer.valueOf(1),atSourceQuestionDto.getId());
    }

    @Test
    public void testGetQuestionByIdFail() {
        when(atSourceSurveyQuestionRepository.getQuestionById(1)).thenReturn(null);
        AtSourceQuestionDto atSourceQuestionDto = atSourceQuestionsService.getQuestionById(1);
        Assert.assertNull(atSourceQuestionDto.getId());
    }

    @Test
    public void testGetAllSubModulesSuccess() {
        when(atsourceModuleAssignmentRepository.findAll()).thenReturn(getAtsourceModuleAssignmentMock());
        when(subModuleRepository.getAllSubmodulesByModuleId(1)).thenReturn(getAtsourceSubmoduleMock());
        List<SubModuleDto> subModuleDtoList = null;
        try {
            subModuleDtoList = atSourceQuestionsService.getAllSubModules();
        } catch (CustomValidationException e) {
            e.printStackTrace();
        }
        Assert.assertEquals(1,subModuleDtoList.size());
    }

    @Test
    public void testGetAllSubModulesFail() {
        when(atsourceModuleAssignmentRepository.findAll()).thenReturn(getAtsourceModuleAssignmentMock());
        when(subModuleRepository.getAllSubmodulesByModuleId(1)).thenReturn(null);
        List<SubModuleDto> subModuleDtoList = null;
        try {
            subModuleDtoList = atSourceQuestionsService.getAllSubModules();
        } catch (CustomValidationException e) {
            e.printStackTrace();
        }
        Assert.assertNull(subModuleDtoList);
    }

    private List<AtsourceModuleAssignment> getAtsourceModuleAssignmentMock() {
        List<AtsourceModuleAssignment> atsourceModuleAssignmentList = new ArrayList<>();
        AtsourceModuleAssignment atsourceModuleAssignment = new AtsourceModuleAssignment();
        Module module = new Module();
        module.setId(1);
        atsourceModuleAssignment.setId(1);
        atsourceModuleAssignment.setModuleId(module);
        atsourceModuleAssignmentList.add(atsourceModuleAssignment);
        return atsourceModuleAssignmentList;
    }

    private List<SubModule> getAtsourceSubmoduleMock() {
        List<SubModule> subModuleList = new ArrayList<>();
        SubModule subModule = new SubModule();
        subModule.setId(1);
        subModuleList.add(subModule);
        return subModuleList;
    }

    private AtSourceQuestionDto getAtSourceQuestionMockDto() {
        AtSourceQuestionDto atSourceQuestionDto = new AtSourceQuestionDto();
        atSourceQuestionDto.setAppId(1);
        atSourceQuestionDto.setQuestion("Test Question");
        atSourceQuestionDto.setDatatypeId(1);
        atSourceQuestionDto.setPosition(1);
        atSourceQuestionDto.setSubmoduleName("227");
        atSourceQuestionDto.setKmCode("abcd");
        atSourceQuestionDto.setDisplayType("Calculated");
        atSourceQuestionDto.setQuestionTh("Test Question");
        atSourceQuestionDto.setQuestionVi("Test Question");
        atSourceQuestionDto.setQuestionLo("Test Question");
        atSourceQuestionDto.setQuestionTr("Test Question");
        atSourceQuestionDto.setQuestionPt("Test Question");
        atSourceQuestionDto.setQuestionTr("Test Question");
        atSourceQuestionDto.setQuestionEs("Test Question");
        atSourceQuestionDto.setActive(Byte.parseByte("1"));
        return atSourceQuestionDto;
    }


    private Page<AtsourceSurveyquestionQueryResult> getPaginatedAtSourceQuestionMock() {
        return new Page<AtsourceSurveyquestionQueryResult>() {
            @Override
            public int getTotalPages() {
                return 1;
            }

            @Override
            public long getTotalElements() {
                return 0;
            }

            @Override
            public <U> Page<U> map(Function<? super AtsourceSurveyquestionQueryResult, ? extends U> function) {
                return null;
            }

            @Override
            public int getNumber() {
                return 0;
            }

            @Override
            public int getSize() {
                return 10;
            }

            @Override
            public int getNumberOfElements() {
                return 0;
            }

            @Override
            public List<AtsourceSurveyquestionQueryResult> getContent() {
                return getAtSourceSurveyquestionQueryResult();
            }

            @Override
            public boolean hasContent() {
                return false;
            }

            @Override
            public Sort getSort() {
                return null;
            }

            @Override
            public boolean isFirst() {
                return false;
            }

            @Override
            public boolean isLast() {
                return false;
            }

            @Override
            public boolean hasNext() {
                return false;
            }

            @Override
            public boolean hasPrevious() {
                return false;
            }

            @Override
            public Pageable nextPageable() {
                return null;
            }

            @Override
            public Pageable previousPageable() {
                return null;
            }

            @Override
            public Iterator<AtsourceSurveyquestionQueryResult> iterator() {
                return null;
            }
        };
    }

    private List<AtsourceSurveyquestionQueryResult> getAtSourceSurveyquestionQueryResult() {
        List<AtsourceSurveyquestionQueryResult> queryResultList = new ArrayList<>();
        AtsourceSurveyquestionQueryResult queryResult = new AtsourceSurveyquestionQueryResult() {
            @Override
            public AtsourceQuestionResult getAtsourceQuestionResult() {
                return getAtsourceQuestionResultData();
            }

            @Override
            public SubModuleResult getSubModuleResult() {
                return getSubModuleResultData();
            }

            @Override
            public DataTypeResult getDataTypeResult() {
                return getDataTypeResultData();
            }
        };
        queryResultList.add(queryResult);
        return queryResultList;
    }

    private AtsourceQuestionResult getAtsourceQuestionResultData() {
        return new AtsourceQuestionResult() {
            @Override
            public Integer getId() {
                return 1;
            }

            @Override
            public String getQuestion() {
                return "abc";
            }

            @Override
            public Integer getPosition() {
                return 1;
            }

            @Override
            public Integer getAppId() {
                return 1;
            }

            @Override
            public Byte getActive() {
                return 1;
            }

            @Override
            public String getKmCode() {
                return "abcd";
            }

            @Override
            public Long getMinValue() {
                return 1L;
            }

            @Override
            public Long getMaxValue() {
                return 1L;
            }
        };
    }

    private SubModuleResult getSubModuleResultData() {
        return new SubModuleResult() {
            @Override
            public Integer getId() {
                return 1;
            }

            @Override
            public String getName() {
                return null;
            }
        };
    }

    private DataTypeResult getDataTypeResultData() {
        return new DataTypeResult() {
            @Override
            public Integer getId() {
                return null;
            }

            @Override
            public String getName() {
                return null;
            }
        };
    }

    private List<AtsourceSurveyquestion> getAtSourceQuestionData() {
        List<AtsourceSurveyquestion> atsourceSurveyquestionList = new ArrayList<>();
        AtsourceSurveyquestion atsourceSurveyquestion = new AtsourceSurveyquestion();
        atsourceSurveyquestion.setId(1);
        atsourceSurveyquestion.setAppId(1);
        atsourceSurveyquestion.setKmCode("abcd");
        atsourceSurveyquestion.setMinValue(1L);
        atsourceSurveyquestion.setMaxValue(1L);
        atsourceSurveyquestion.setPosition(1);
        atsourceSurveyquestion.setActive((byte) 1);
        atsourceSurveyquestion.setQuestion("Test Question");
        atsourceSurveyquestionList.add(atsourceSurveyquestion);
        return atsourceSurveyquestionList;
    }


}
