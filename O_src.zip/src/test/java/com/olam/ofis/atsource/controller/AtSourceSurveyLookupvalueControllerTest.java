/*******************************************************************************
 *
 * Copyright (c) 2019 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 *******************************************************************************/

package com.olam.ofis.atsource.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.gson.Gson;
import com.olam.ofis.atsource.dto.AtsourceSurveyLookupvalueDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.UserDTO;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.service.AtsourceSurveyLookupvalueService;
import com.olam.ofis.atsource.util.PaginationResult;
import com.olam.ofis.atsource.util.RetrieveUserData;

/**
 * Class - AtSourceSurveyLookupvalueControllerTest
 *
 * @author Mohammed Mahroof
 *
 */
public class AtSourceSurveyLookupvalueControllerTest {

    private MockMvc mockMvc;

    @Mock
    AtsourceSurveyLookupvalueService atsourceSurveyLookupvalueService;

    @Mock
    RetrieveUserData retrieveUserData;

    @InjectMocks
    AtsourceSurveyLookupvalueController atSourceSurveyLookupvalueController;

    @Mock
	private HttpServletRequest request;
    
    private static String tokenString
            = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJsYW5ndWFnZUlTT0NvZGUiOiJlbiIsInRpbWV6b25lSXNvQ29kZSI6IldJQiIsI";

    @Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(atSourceSurveyLookupvalueController).build();
	}
    
    @Test
    public void getAllLookupValuesTest() throws Exception {
        PaginationResult<AtsourceSurveyLookupvalueDto> paginationResult = new PaginationResult<>();
        Mockito.when(atsourceSurveyLookupvalueService.getAllLookupValues(anyInt(), anyInt(), anyString(), anyString()))
                .thenReturn(paginationResult);
        this.mockMvc.perform(
                get("/atsource/lookupvalues/getAllLookupValues")
                    .header("Authorization", "Bearer " + tokenString)
                    .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void getLookUpValueByIdTest() throws Exception {
        AtsourceSurveyLookupvalueDto atsourceSurveyLookupvalueDto = new AtsourceSurveyLookupvalueDto();
        Mockito.when(atsourceSurveyLookupvalueService.getLookUpValueById(anyInt()))
                .thenReturn(atsourceSurveyLookupvalueDto);
        this.mockMvc.perform(
                get("/atsource/lookupvalues/1/edit")
                    .header("Authorization", "Bearer " + tokenString)
                    .contentType(MediaType.APPLICATION_JSON)).andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    public void saveLookUpValueTest() throws CustomValidationException, Exception {
        AtsourceSurveyLookupvalueDto atsourceSurveyLookupvalueDto = new AtsourceSurveyLookupvalueDto();
        MessageDto messageDto = new MessageDto();
        UserDTO userDTO = new UserDTO();
        Mockito.when(retrieveUserData.getUserData(any())).thenReturn(userDTO);
        when(request.getHeader(Mockito.anyString())).thenReturn("1");
        Mockito.when(atsourceSurveyLookupvalueService.saveLookUpValue(anyLong(), any(AtsourceSurveyLookupvalueDto.class)))
                .thenReturn(messageDto);
        this.mockMvc.perform(
                post("/atsource/lookupvalues/save")
                     .header("Authorization", "Bearer " + tokenString).header("App-Id", 1)
                     .contentType(MediaType.APPLICATION_JSON).content(new Gson().toJson(atsourceSurveyLookupvalueDto)))
                .andExpect(status().isCreated());
    }

}