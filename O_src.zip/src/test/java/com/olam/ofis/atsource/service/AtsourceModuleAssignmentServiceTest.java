/*******************************************************************************
 * Copyright (c) 2019 OLAM Limited
 * 
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited.
 ******************************************************************************/
package com.olam.ofis.atsource.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import com.olam.ofis.atsource.dto.AtsourceModuleAssignmentDto;
import com.olam.ofis.atsource.dto.MessageDto;
import com.olam.ofis.atsource.dto.SubModuleDto;
import com.olam.ofis.atsource.exception.CustomValidationException;
import com.olam.ofis.atsource.model.AtsourceModuleAssignment;
import com.olam.ofis.atsource.model.AtsourceModuleAssignmentData;
import com.olam.ofis.atsource.model.Country;
import com.olam.ofis.atsource.model.District;
import com.olam.ofis.atsource.model.FarmerGroup;
import com.olam.ofis.atsource.model.Module;
import com.olam.ofis.atsource.model.Partner;
import com.olam.ofis.atsource.model.Place;
import com.olam.ofis.atsource.model.Product;
import com.olam.ofis.atsource.model.Programme;
import com.olam.ofis.atsource.model.Region;
import com.olam.ofis.atsource.model.Section;
import com.olam.ofis.atsource.model.SubModule;
import com.olam.ofis.atsource.repository.AtsourceModuleAssignmentRepository;
import com.olam.ofis.atsource.repository.CountryRepository;
import com.olam.ofis.atsource.repository.DistrictRepository;
import com.olam.ofis.atsource.repository.FarmerGroupRepository;
import com.olam.ofis.atsource.repository.ModuleRepository;
import com.olam.ofis.atsource.repository.PartnerRepository;
import com.olam.ofis.atsource.repository.PlaceRepository;
import com.olam.ofis.atsource.repository.ProductRepository;
import com.olam.ofis.atsource.repository.ProgrammeRepository;
import com.olam.ofis.atsource.repository.RegionRepository;
import com.olam.ofis.atsource.repository.SectionRepository;
import com.olam.ofis.atsource.repository.SubModuleRepository;
import com.olam.ofis.atsource.service.impl.AtsourceModuleAssignmentServiceImpl;

public class AtsourceModuleAssignmentServiceTest {

    @InjectMocks
    private AtsourceModuleAssignmentServiceImpl atsourceModuleAssignmentService;

    @Mock
    private ModelMapper modelMapper;
    
    @Mock
    private ModuleRepository moduleRepository;

    @Mock
    private CountryRepository countryRepository;

    @Mock
    private PartnerRepository partnerRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private ProgrammeRepository programmeRepository;

    @Mock
    private SectionRepository sectionRepository;

    @Mock
    private FarmerGroupRepository farmerGroupRepository;

    @Mock
    private RegionRepository regionRepository;

    @Mock
    private DistrictRepository districtRepository;

    @Mock
    private PlaceRepository placeRepository;

    @Mock
    private AtsourceModuleAssignmentRepository atsourceModuleAssignmentRepository;

    @Mock
    private SubModuleRepository subModuleRepository;

    @Before
    public void init() {
    	MockitoAnnotations.initMocks(this);
    }
    @Test
    public void testSaveModuleAssignment_scenarios() throws Exception {

        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = null;
        MessageDto messageDto = null;

        /**
         * Scenario 1 - Positive Scenario with Assignment Type "Country"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(countryRepository.findById(Mockito.anyLong())).thenReturn(getMockCountry());
        Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(getMockModuleAssignmentList());
        Mockito.doNothing().when(atsourceModuleAssignmentRepository).deleteAll();
        Mockito.when(atsourceModuleAssignmentRepository.save(Mockito.any(AtsourceModuleAssignment.class))).thenReturn(null);

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeCountry();
        messageDto = atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        Assert.assertTrue("Success", messageDto.getMessage().equalsIgnoreCase("Success"));
               
        /**
         * Scenario 2 - Positive Scenario with Assignment Type "Partner"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(partnerRepository.findById(Mockito.anyLong())).thenReturn(getMockPartner());
        Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(new ArrayList<>());
        Mockito.when(atsourceModuleAssignmentRepository.save(Mockito.any(AtsourceModuleAssignment.class))).thenReturn(null);

        atsourceModuleAssignmentDto = getInputWithAssignmentTypePartner();
        messageDto = atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        Assert.assertTrue("Success", messageDto.getMessage().equalsIgnoreCase("Success"));

        /**
         * Scenario 3 - Positive Scenario with Assignment Type "Product"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(productRepository.findById(Mockito.anyLong())).thenReturn(getMockProduct());
        Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(new ArrayList<>());
        Mockito.when(atsourceModuleAssignmentRepository.save(Mockito.any(AtsourceModuleAssignment.class))).thenReturn(null);

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeProduct();
        messageDto = atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        Assert.assertTrue("Success", messageDto.getMessage().equalsIgnoreCase("Success"));

        /**
         * Scenario 4 - Positive Scenario with Assignment Type "Programme"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(programmeRepository.findById(Mockito.anyLong())).thenReturn(getMockProgramme());
        Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(new ArrayList<>());
        Mockito.when(atsourceModuleAssignmentRepository.save(Mockito.any(AtsourceModuleAssignment.class))).thenReturn(null);

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeProgramme();
        messageDto = atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        Assert.assertTrue("Success", messageDto.getMessage().equalsIgnoreCase("Success"));

        /**
         * Scenario 5 - Positive Scenario with Assignment Type "Section"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(sectionRepository.findById(Mockito.anyLong())).thenReturn(getMockSection());
        Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(new ArrayList<>());
        Mockito.when(atsourceModuleAssignmentRepository.save(Mockito.any(AtsourceModuleAssignment.class))).thenReturn(null);

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeSection();
        messageDto = atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        Assert.assertTrue("Success", messageDto.getMessage().equalsIgnoreCase("Success"));

        /**
         * Scenario 6 - Positive Scenario with Assignment Type "FarmerGroup"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(farmerGroupRepository.findById(Mockito.anyLong())).thenReturn(getMockFarmerGroup());
        Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(new ArrayList<>());
        Mockito.when(atsourceModuleAssignmentRepository.save(Mockito.any(AtsourceModuleAssignment.class))).thenReturn(null);

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeFarmerGroup();
        messageDto = atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        Assert.assertTrue("Success", messageDto.getMessage().equalsIgnoreCase("Success"));

        /**
         * Scenario 7 - Positive Scenario with Assignment Type "Region"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(regionRepository.findById(Mockito.anyLong())).thenReturn(getMockRegion());
        Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(new ArrayList<>());
        Mockito.when(atsourceModuleAssignmentRepository.save(Mockito.any(AtsourceModuleAssignment.class))).thenReturn(null);

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeRegion();
        messageDto = atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        Assert.assertTrue("Success", messageDto.getMessage().equalsIgnoreCase("Success"));

        /**
         * Scenario 8 - Positive Scenario with Assignment Type "District"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(districtRepository.findById(Mockito.anyLong())).thenReturn(getMockDistrict());
        Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(new ArrayList<>());
        Mockito.when(atsourceModuleAssignmentRepository.save(Mockito.any(AtsourceModuleAssignment.class))).thenReturn(null);

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeDistrict();
        messageDto = atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        Assert.assertTrue("Success", messageDto.getMessage().equalsIgnoreCase("Success"));

        /**
         * Scenario 9 - Positive Scenario with Assignment Type "Place"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(placeRepository.findById(Mockito.anyLong())).thenReturn(getMockPlace());
        Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(new ArrayList<>());
        Mockito.when(atsourceModuleAssignmentRepository.save(Mockito.any(AtsourceModuleAssignment.class))).thenReturn(null);

        atsourceModuleAssignmentDto = getInputWithAssignmentTypePlace();
        messageDto = atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        Assert.assertTrue("Success", messageDto.getMessage().equalsIgnoreCase("Success"));

        /**
         * Scenario 10 - Negative Scenario with Assignment Type "Country"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(countryRepository.findById(Mockito.anyLong())).thenReturn(Optional.ofNullable(null));

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeCountry();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (Exception e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 11 - Negative Scenario with Assignment Type "Partner"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(partnerRepository.findById(Mockito.anyLong())).thenReturn(Optional.ofNullable(null));

        atsourceModuleAssignmentDto = getInputWithAssignmentTypePartner();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (Exception e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 12 - Negative Scenario with Assignment Type "Product"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(productRepository.findById(Mockito.anyLong())).thenReturn(Optional.ofNullable(null));

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeProduct();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (Exception e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 13 - Negative Scenario with Assignment Type "Programme"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(programmeRepository.findById(Mockito.anyLong())).thenReturn(Optional.ofNullable(null));

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeProgramme();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (Exception e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 14 - Negative Scenario with Assignment Type "Section"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(sectionRepository.findById(Mockito.anyLong())).thenReturn(Optional.ofNullable(null));

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeSection();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (Exception e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 15 - Negative Scenario with Assignment Type "FarmerGroup"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(farmerGroupRepository.findById(Mockito.anyLong())).thenReturn(Optional.ofNullable(null));

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeFarmerGroup();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (Exception e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 16 - Negative Scenario with Assignment Type "Region"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(regionRepository.findById(Mockito.anyLong())).thenReturn(Optional.ofNullable(null));

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeRegion();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (Exception e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 17 - Negative Scenario with Assignment Type "District"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(districtRepository.findById(Mockito.anyLong())).thenReturn(Optional.ofNullable(null));

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeDistrict();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (Exception e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 18 - Negative Scenario with Assignment Type "Place"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(placeRepository.findById(Mockito.anyLong())).thenReturn(Optional.ofNullable(null));

        atsourceModuleAssignmentDto = getInputWithAssignmentTypePlace();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (Exception e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 19 - Negative Scenario without module id
         */
        atsourceModuleAssignmentDto = getInvalidInputWithoutModuleId();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (CustomValidationException e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 20 - Negative Scenario with invalid module id
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(Optional.ofNullable(null));

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeCountry();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (CustomValidationException e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 21 - Negative Scenario with inactive module id
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockInactiveModule());

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeCountry();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (CustomValidationException e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 22 - Negative Scenario with Invalid Assignment Type
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());

        atsourceModuleAssignmentDto = getInvalidInputWithInvalidAssignmentType();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (CustomValidationException e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 23 - Negative Scenario with Assignment Type "Partner"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(partnerRepository.findById(Mockito.anyLong())).thenReturn(getMockPartner());
        Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(new ArrayList<>());
        Mockito.when(atsourceModuleAssignmentRepository.save(Mockito.any(AtsourceModuleAssignment.class)))
                .thenThrow(new IllegalArgumentException("Error"));

        atsourceModuleAssignmentDto = getInputWithAssignmentTypePartner();
        try {
            atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        } catch (Exception e) {
            Assert.assertTrue("Success", !e.getMessage().isEmpty());
        }

        /**
         * Scenario 24 - Positive Scenario when atSource checkbox is false
         */
        Mockito.doNothing().when(atsourceModuleAssignmentRepository).deleteAll();

        atsourceModuleAssignmentDto = getInputWithAtsourceFalse();
        messageDto = atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        Assert.assertTrue("Success", messageDto.getMessage().equalsIgnoreCase("Module Assignment cleared"));

        /**
         * Scenario 25 - Positive Scenario with Assignment Type "Farmer Group"
         */
        Mockito.when(moduleRepository.findById(Mockito.anyInt())).thenReturn(getMockActiveModule());
        Mockito.when(farmerGroupRepository.findById(Mockito.anyLong())).thenReturn(getMockFarmerGroup());
        Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(new ArrayList<>());
        Mockito.when(atsourceModuleAssignmentRepository.save(Mockito.any(AtsourceModuleAssignment.class))).thenReturn(null);

        atsourceModuleAssignmentDto = getInputWithAssignmentTypeFarmerGroup();
        messageDto = atsourceModuleAssignmentService.saveModuleAssignment(atsourceModuleAssignmentDto);
        Assert.assertTrue("Success", messageDto.getMessage().equalsIgnoreCase("Success"));
    }

    private Optional<Module> getMockActiveModule() {
        Module module = new Module();
        module.setActive(true);
        return Optional.of(module);
    }

    private Optional<Module> getMockInactiveModule() {
        Module module = new Module();
        module.setActive(false);
        return Optional.of(module);
    }

    private Optional<Country> getMockCountry() {
        Country country = new Country();
        country.setActive(true);
        return Optional.of(country);
    }

    private Optional<Partner> getMockPartner() {
        Partner partner = new Partner();
        partner.setActive(true);
        return Optional.of(partner);
    }

    private Optional<Product> getMockProduct() {
        Product product = new Product();
        product.setActive(true);
        return Optional.of(product);
    }

    private Optional<Programme> getMockProgramme() {
        Programme programme = new Programme();
        programme.setActive(true);
        return Optional.of(programme);
    }

    private Optional<Section> getMockSection() {
        Section section = new Section();
        section.setActive(true);
        return Optional.of(section);
    }

    private Optional<FarmerGroup> getMockFarmerGroup() {
        FarmerGroup farmerGroup = new FarmerGroup();
        farmerGroup.setActive(true);
        return Optional.of(farmerGroup);
    }

    private Optional<Region> getMockRegion() {
        Region region = new Region();
        region.setIsActive(true);
        return Optional.of(region);
    }

    private Optional<District> getMockDistrict() {
        District district = new District();
        district.setIsActive(true);
        return Optional.of(district);
    }

    private Optional<Place> getMockPlace() {
        Place place = new Place();
        place.setActive(true);
        return Optional.of(place);
    }

    private List<AtsourceModuleAssignment> getMockModuleAssignmentList() {
        List<AtsourceModuleAssignment> atsourceModuleAssignments = new ArrayList<>();
        AtsourceModuleAssignment atsourceModuleAssignment = new AtsourceModuleAssignment();
        atsourceModuleAssignment.setAppId(1);
        atsourceModuleAssignments.add(atsourceModuleAssignment);
        return atsourceModuleAssignments;
    }

    private AtsourceModuleAssignmentDto getInputWithAssignmentTypeCountry() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setModuleAssignmentId("1,2,3");
        atsourceModuleAssignmentDto.setModuleAssignmentType("Country");
        atsourceModuleAssignmentDto.setModuleId(58);
        atsourceModuleAssignmentDto.setRecurrenceFrequency(1);
        atsourceModuleAssignmentDto.setRecurrenceType("Days");
        return atsourceModuleAssignmentDto;
    }

    private AtsourceModuleAssignmentDto getInputWithAssignmentTypePartner() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setModuleAssignmentId("1,2,3");
        atsourceModuleAssignmentDto.setModuleAssignmentType("Partner");
        atsourceModuleAssignmentDto.setModuleId(58);
        atsourceModuleAssignmentDto.setRecurrenceFrequency(1);
        atsourceModuleAssignmentDto.setRecurrenceType("Days");
        return atsourceModuleAssignmentDto;
    }

    private AtsourceModuleAssignmentDto getInputWithAssignmentTypeProduct() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setModuleAssignmentId("1,2,3");
        atsourceModuleAssignmentDto.setModuleAssignmentType("Product");
        atsourceModuleAssignmentDto.setModuleId(58);
        atsourceModuleAssignmentDto.setRecurrenceFrequency(1);
        atsourceModuleAssignmentDto.setRecurrenceType("Days");
        return atsourceModuleAssignmentDto;
    }

    private AtsourceModuleAssignmentDto getInputWithAssignmentTypeProgramme() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setModuleAssignmentId("1,2,3");
        atsourceModuleAssignmentDto.setModuleAssignmentType("Programme");
        atsourceModuleAssignmentDto.setModuleId(58);
        atsourceModuleAssignmentDto.setRecurrenceFrequency(1);
        atsourceModuleAssignmentDto.setRecurrenceType("Days");
        return atsourceModuleAssignmentDto;
    }

    private AtsourceModuleAssignmentDto getInputWithAssignmentTypeSection() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setModuleAssignmentId("1,2,3");
        atsourceModuleAssignmentDto.setModuleAssignmentType("Section");
        atsourceModuleAssignmentDto.setModuleId(58);
        atsourceModuleAssignmentDto.setRecurrenceFrequency(1);
        atsourceModuleAssignmentDto.setRecurrenceType("Days");
        return atsourceModuleAssignmentDto;
    }

    private AtsourceModuleAssignmentDto getInputWithAssignmentTypeFarmerGroup() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setModuleAssignmentId("1,2,3");
        atsourceModuleAssignmentDto.setModuleAssignmentType("FarmerGroup");
        atsourceModuleAssignmentDto.setModuleId(58);
        atsourceModuleAssignmentDto.setRecurrenceFrequency(1);
        atsourceModuleAssignmentDto.setRecurrenceType("Days");
        return atsourceModuleAssignmentDto;
    }

    private AtsourceModuleAssignmentDto getInputWithAssignmentTypeRegion() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setModuleAssignmentId("1,2,3");
        atsourceModuleAssignmentDto.setModuleAssignmentType("Region");
        atsourceModuleAssignmentDto.setModuleId(58);
        atsourceModuleAssignmentDto.setRecurrenceFrequency(1);
        atsourceModuleAssignmentDto.setRecurrenceType("Days");
        return atsourceModuleAssignmentDto;
    }

    private AtsourceModuleAssignmentDto getInputWithAssignmentTypeDistrict() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setModuleAssignmentId("1,2,3");
        atsourceModuleAssignmentDto.setModuleAssignmentType("District");
        atsourceModuleAssignmentDto.setModuleId(58);
        atsourceModuleAssignmentDto.setRecurrenceFrequency(1);
        atsourceModuleAssignmentDto.setRecurrenceType("Days");
        return atsourceModuleAssignmentDto;
    }

    private AtsourceModuleAssignmentDto getInputWithAssignmentTypePlace() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setModuleAssignmentId("1,2,3");
        atsourceModuleAssignmentDto.setModuleAssignmentType("Place");
        atsourceModuleAssignmentDto.setModuleId(58);
        atsourceModuleAssignmentDto.setRecurrenceFrequency(1);
        atsourceModuleAssignmentDto.setRecurrenceType("Days");
        return atsourceModuleAssignmentDto;
    }

    private AtsourceModuleAssignmentDto getInvalidInputWithInvalidAssignmentType() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setModuleAssignmentId("1,2,3");
        atsourceModuleAssignmentDto.setModuleAssignmentType("Places");
        atsourceModuleAssignmentDto.setModuleId(58);
        atsourceModuleAssignmentDto.setRecurrenceFrequency(1);
        atsourceModuleAssignmentDto.setRecurrenceType("Days");
        return atsourceModuleAssignmentDto;
    }

    private AtsourceModuleAssignmentDto getInvalidInputWithoutModuleId() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setModuleAssignmentId("1,2,3");
        atsourceModuleAssignmentDto.setModuleAssignmentType("Country");
        atsourceModuleAssignmentDto.setRecurrenceFrequency(1);
        atsourceModuleAssignmentDto.setRecurrenceType("Days");
        return atsourceModuleAssignmentDto;
    }

    private AtsourceModuleAssignmentDto getInputWithAtsourceFalse() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setAtsource(false);
        return atsourceModuleAssignmentDto;
    }

    private AtsourceModuleAssignmentDto getInputWithAssignmentTypeFarmerGroupWithSpace() {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = new AtsourceModuleAssignmentDto();
        atsourceModuleAssignmentDto.setAppId(1);
        atsourceModuleAssignmentDto.setModuleAssignmentId("1,2,3");
        atsourceModuleAssignmentDto.setModuleAssignmentType("Farmer Group");
        atsourceModuleAssignmentDto.setModuleId(58);
        atsourceModuleAssignmentDto.setRecurrenceFrequency(1);
        atsourceModuleAssignmentDto.setRecurrenceType("Days");
        return atsourceModuleAssignmentDto;
    }

    @Test
    public void testGetModuleAssignment_scenarios() throws CustomValidationException {
        AtsourceModuleAssignmentDto atsourceModuleAssignmentDto = null;
        int moduleId = 58;
        AtsourceModuleAssignmentDto assignmentDto = new AtsourceModuleAssignmentDto();
        when(modelMapper.map(Mockito.any(),Mockito.any()))
		.thenReturn(assignmentDto);
        
        /**
         * Negative Scenario - No Module assignments found
         */
        Mockito.when(atsourceModuleAssignmentRepository.findAllUniqueData()).thenReturn(null);

        try {
            atsourceModuleAssignmentService.getModuleAssignment(moduleId);
        } catch (CustomValidationException e) {
            Assert.assertTrue("Success", e.getMessage().equalsIgnoreCase("No module assignments found"));
        }

        /**
         * Positive Scenario - Module assignments found
         */
        Mockito.when(atsourceModuleAssignmentRepository.findAllUniqueData())
                .thenReturn(getMockAtsourceModuleAssignmentDataList());

        atsourceModuleAssignmentDto = atsourceModuleAssignmentService.getModuleAssignment(moduleId);
        Assert.assertTrue("Success", atsourceModuleAssignmentDto.getAtsource().equals(true));
    }

    private List<AtsourceModuleAssignmentData> getMockAtsourceModuleAssignmentDataList() {
        List<AtsourceModuleAssignmentData> atsourceModuleAssignmentDataList = new ArrayList<>();
        atsourceModuleAssignmentDataList.add(getMockAtsourceModuleAssignmentData());
        return atsourceModuleAssignmentDataList;
    }

    private AtsourceModuleAssignmentData getMockAtsourceModuleAssignmentData() {
        AtsourceModuleAssignmentData atsourceModuleAssignmentData = new AtsourceModuleAssignmentData(58,"1",
                "Country", 1, "Date", "1", 1, true);
        return atsourceModuleAssignmentData;
    }

    @Test
    public void testGetAtsourceModule() {
        AtsourceModuleAssignment atsourceModuleAssignment = null;

        Mockito.when(atsourceModuleAssignmentRepository.findAll()).thenReturn(getMockModuleAssignmentList());
        atsourceModuleAssignment = atsourceModuleAssignmentService.getAtSourceModule();
        Assert.assertTrue("Success", atsourceModuleAssignment.getAppId().equals(1));
    }

    @Test
    public void testGetAllSubmodulesByModuleId_scenarios() throws CustomValidationException {
        int moduleId = 58;
        List<SubModuleDto> subModuleDtos = null;

        /**
         * Negative Scenario - Invalid Module Id
         */
        Mockito.when(subModuleRepository.getAllSubmodulesByModuleId(Mockito.anyInt())).thenReturn(null);

        try {
            atsourceModuleAssignmentService.getAllSubmodulesByModuleId(moduleId);
        } catch (CustomValidationException e) {
            Assert.assertTrue("Success", e.getMessage().equalsIgnoreCase("Invalid Module Id."));
        }

        /**
         * Positive Scenario - Get SubModule list by moduleId
         */
        Mockito.when(subModuleRepository.getAllSubmodulesByModuleId(Mockito.anyInt()))
                .thenReturn(getMockSubModuleList());

        subModuleDtos = atsourceModuleAssignmentService.getAllSubmodulesByModuleId(moduleId);
        Assert.assertTrue("Success", subModuleDtos.get(0).getAppId().equals(1));
    }

    private List<SubModule> getMockSubModuleList() {
        List<SubModule> subModuleList = new ArrayList<>();
        subModuleList.add(getMockSubModule());
        return subModuleList;
    }

    private SubModule getMockSubModule() {
        SubModule subModule = new SubModule();
        subModule.setId(1);
        subModule.setAppId(1);
        Module module = new Module();
        module.setId(58);
        subModule.setModuleId(module);
        return subModule;
    }

    @Test
    public void testGetAllModuleAssignment_scenarios() throws CustomValidationException {
        List<AtsourceModuleAssignmentDto> atsourceModuleAssignmentDtos = null;
        AtsourceModuleAssignmentDto assignmentDto = new AtsourceModuleAssignmentDto();
        when(modelMapper.map(Mockito.any(),Mockito.any()))
		.thenReturn(assignmentDto);
				
        /**
         * Negative Scenario - No Module assignments found
         */
        Mockito.when(atsourceModuleAssignmentRepository.findAllUniqueData()).thenReturn(null);

        try {
            atsourceModuleAssignmentService.getAllModuleAssignment();
        } catch (CustomValidationException e) {
            Assert.assertTrue("Success", e.getMessage().equalsIgnoreCase("No module assignments found"));
        }

        /**
         * Positive Scenario - Module assignments found
         */
        Mockito.when(atsourceModuleAssignmentRepository.findAllUniqueData())
                .thenReturn(getMockAtsourceModuleAssignmentDataList());
        atsourceModuleAssignmentDtos = atsourceModuleAssignmentService.getAllModuleAssignment();
        Assert.assertTrue("Success", atsourceModuleAssignmentDtos.get(0).getAtsource().equals(true));
    }

}