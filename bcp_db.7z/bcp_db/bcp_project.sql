-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: bcp
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `account_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `team_size` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_acc_idx` (`account_id`),
  KEY `FK9975oodrdxilq6tsmgxlp02l5` (`location_id`),
  CONSTRAINT `FK9975oodrdxilq6tsmgxlp02l5` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `fk_acc` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES (1,'Citi Manager Transformation - Scrum Team 1 & 2',1,1,17),(2,'Citi - GRACE',1,1,14),(3,'Citi Manager Mobile',1,1,4),(4,'CCF',1,3,10),(5,'FileExport',1,3,7),(6,'CitiDirect Metis',1,3,37),(7,'Project Next',1,3,2),(8,'SCC',1,3,5),(9,'CC API',1,3,8),(10,'APIm',1,3,3),(11,'Russia IP',1,3,27),(12,'Front Running',1,3,5),(13,'BAMS / Decision Insights',1,3,7),(14,'PPP',1,1,10),(15,'Argentina Transformation',1,3,0),(16,'Citi Manager  -SP3',1,3,1),(17,'CitiFT',1,3,5),(18,'Drift - Testing',2,1,2),(19,'Privilege access/Change access ',2,1,14),(20,'Compliance UI ',2,1,5),(21,'Sitscape',2,1,6),(22,'Netdocs',2,1,2),(23,'AppEngine',2,1,2),(24,'CPP',2,1,4),(25,'Intelligence Portal',2,2,7),(26,'Infrastructure Dashboard',2,2,4),(27,'Drift Dev / Support',2,2,2),(28,'Drift',2,2,2),(29,'Green Field Migration tracker',2,3,1),(30,'CE Migration',4,2,6),(31,'Data Analysis for CE/UK',4,2,5),(32,'cruise control ETL',4,2,6),(33,'Key Financial Statements',4,2,6),(34,'Experian Batch, Andromeda',4,2,0),(35,'CC Risk monitoring',4,2,6),(36,'Platform Operations',4,2,4),(37,'GlobalRiskMI',4,2,1),(38,'UK Lead model',4,2,1),(39,'US Gen 4 Annual Validation ',4,2,0),(40,'SRE Engagement',5,1,5),(41,'Myloans',6,2,12),(42,'SCA-V',7,1,21),(43,'FordPass',7,1,8),(44,'EV - WALL BOX',7,1,6),(45,'OCPP',7,1,8),(46,'Relationship Map',8,2,1),(47,'GST',9,2,0),(48,'PROCESS INTEGRATION',9,2,0),(49,'GLOBAL SOLUTION MANAGER',9,2,0),(50,'MDM',9,2,0),(51,'BUSINESS PROCESS MANAGEMENT',9,2,0),(52,'COMPOSITE APPLICATION FRAMEWORK',9,2,0),(53,'SALESFORCE',9,2,11),(54,'QBDT CAMPS, QBN Obill',10,2,24),(55,'FACT_ERS_Re-platforming',10,2,5),(56,'SFDC Support',10,2,6),(57,'OFM Sync PIP',10,2,5),(58,'Data_Analytics_T4i_IT_Support_Team',10,2,2),(59,'ETL Dna',10,2,13),(60,'T4I_CSST_OINP_AWS_SREOps_XD',10,2,3),(61,'T4I_CSST_OINP_AWS_SREOps_XD',10,2,3),(62,'CG Data Engineering',10,2,7),(63,'CG_UI_Incremental',10,2,1),(64,'CG Engineering Canada',10,2,4),(65,'CG Engineering US ',10,2,3),(66,'Mint Support',10,2,5),(67,'EBS FACT Obill',10,2,9),(68,'FACT_Commerce Platform AWS_FY20',10,2,4),(69,'DG SSDLC',10,2,3),(70,'FACT_Commerce Platform PD_FY20',10,2,11),(71,'SBSEG_QBO_RoW_PD',10,2,7),(72,'SBSEG_CorePlatform_Tools_ALtimetrik_FY20-H2',10,2,0),(73,'eCommerce (Accountant Services)',10,2,2),(74,'Contact Center Technology, CRMS Engineering',10,2,13),(75,'fi partner rebuild',10,2,1),(76,'SFMC',10,2,3),(77,'EIS Functional, EBS FACT Acclerate QBN Retirement',10,2,14),(78,'TxE/Digicom/ERS',10,2,9),(79,'Others',10,2,0),(80,'EDW',11,3,34),(81,'Sales Force Migration',11,3,9),(82,'Surya',11,3,11),(83,'Culture Sense',12,1,9),(84,'Glassbox',12,1,1),(85,'RelFinder',12,1,6),(86,'Data Governance scrum ',12,1,9),(87,'Internal POCs, Ramp-up',12,1,20),(88,'Novartis DevOps Engagement',12,2,13),(89,'SFDC',14,2,11),(90,'Multiple Projects',14,2,4),(91,'App Support',15,2,20),(92,'MR Track',15,2,12),(93,'Client Master - BODS',15,2,3),(94,'UK Credit Cards service',15,2,3),(95,'SCUBA',15,2,15),(96,'DevOps',15,2,1),(97,'PSD2',15,2,6),(98,'PSD2 API',15,2,4),(99,'ODP',15,2,4),(100,'Multiple Projects',16,2,5),(101,'RST',17,2,3),(102,'SRE',17,2,6),(103,'LSI',17,2,6),(104,'Post Purchase',17,2,6),(105,'Sponsorship',17,2,6),(106,'VCP Cockpit',18,2,18),(107,'VetaHealth',19,2,9),(108,'VBS Reporting Project',20,1,6),(109,'Consumer EBR - Credit',21,2,5),(110,'Consumer EBR - Privacy',21,2,12),(111,'Consumer EBR - P2P',21,2,9),(112,'Merchant Automation',21,2,3),(113,'Merchant Billing Products',21,1,0),(114,'PayPal Enterprise Portal',21,1,3),(115,'Payments LiveOps',21,1,11),(116,'Hyperwallet',21,1,4),(117,'Risk Millennium Migration',21,1,3),(118,'Risk Vulnerabilities',21,1,3),(119,'Payments BatchOps',21,1,9),(120,'Pricing LiveOps',21,2,5),(121,'RPT Lights On',21,1,6),(122,'P2P Merchant Automation testing',21,1,6),(123,'Credit',21,1,9),(124,'Payments - Tokenization',21,1,6),(125,'Helix to raptor migration -SOW',21,2,15),(126,'Value added services for Frictionless check out (Hop Free/Rupay)',21,1,1),(127,'GPL - Switch and Settlement - FR&UK',21,1,5),(128,'Ancestry - Discovery',22,1,9),(129,'Ancestry - People',22,1,3),(130,'Navaratnas',22,1,10),(131,'Survey Engine',22,1,11),(132,'Team-42',22,1,6),(133,'PCOM',22,1,11),(134,'Skynet',22,1,10),(135,'EDM',22,1,12),(136,'CDV',22,1,10),(137,'Ultron',22,1,12),(138,'Wellness',22,1,11),(139,'Marauders',22,1,10),(140,'Commerce-Back End ',22,1,12),(141,'Commerce-Front End ',22,1,10),(142,'A-Team',22,1,10),(143,'Digi-Singapore',3,4,0),(144,'Digi-Taiwan',3,4,0),(145,'IWealth',3,4,0),(146,'PWEB',3,4,0),(147,'Sailor',3,4,0),(148,'Multiple teams',3,4,0),(149,'Simility DevOps Integration',21,4,0);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-24 21:09:11
